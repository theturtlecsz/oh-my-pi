# Reanalyzed OMP autonomy program — bounded intake exploration edition

This package supersedes `reanalyzed-omp-programs-v6.zip` without deleting or
renaming any v6 path. It preserves the complete PostgreSQL-first,
neuro-symbolic-intake, Native OMP Web and Fleet design, then adds one optional
user-facing capability: **Explore alternatives** for genuinely open intake
decisions. It is a bounded OMP-native adaptation of the useful divergent-
ideation pattern inspected in `UditAkhourii/adhd`; the upstream runtime is not
installed or placed in the authority path.

Native OMP Web is one product at the user level and several trust boundaries
underneath. Local interactive Chat, restricted remote session access,
Work/Intake and Fleet supervision share a visual shell, not credentials or
authority.

The central sequencing correction is:

```text
SQL-0: PROVEN
  -> NSI-1..NSI-6: typed neuro-symbolic intake qualified and cut over
  -> publish/rebaseline the Fleet program
  -> FLEET-1
```

Do not apply the neuro-symbolic or Fleet programs while SQL-0 remains active.
While the migration is in progress, only
`01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` may amend current SQL/WorkService
work. Independent fixture/design work for OMP Web may proceed in the separate
`omp-webui` repository if it neither changes OMP core nor touches WorkService,
Fleet authority or the active migration. Core packaging/live integration is
rebaselined after `SQL-0: PROVEN`.

For the shortest practical path, read `09_SOLO_DEVELOPER_USER_GUIDE.md` first.

## Evidence baseline and limits

The v5 intake/Fleet research was revalidated on 2026-08-22 against the fork at:

- `theturtlecsz/oh-my-pi`:
  `cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8`

The current intake skill and model bookend were inspected at that revision.
The v6 Web decision was additionally rebaselined on 2026-08-28 at:

- `theturtlecsz/oh-my-pi`:
  `5086e48160364e9f4e2736d7a54d8fbf90ec0545`
- `theturtlecsz/omp-webui`:
  `12f8c1e549b4bc4e07d769e409eb9bd662ce2175`
- `MoonshotAI/kimi-code`:
  `9d2304c23ca30c781b1a39540971dcaef085a500`

The bounded-exploration decision was revalidated on 2026-08-29 against:

- `UditAkhourii/adhd`:
  `53ab5576b77fb3d6e62739a1a285356261e5f568`

Every paste-ready intake still requires OMP to resolve the live repository HEAD,
WorkService API/schema version, configuration and published work before it
proposes anything. The commits above are evidence anchors, not future-state
assumptions.

Research claims are separated by evidence class in
`08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`. Peer-reviewed work, official
specifications, current repository evidence, preprints and a Reddit anecdote do
not receive equal weight. No external benchmark percentage is treated as a
local result until reproduced on the evaluation corpus.

## Final disposition of the earlier ideas

| Earlier work | Disposition |
| --- | --- |
| Model assignment and workflow bookends | Preserve CLI behavior and command/bookend semantics; add an official Web presentation without changing authority. Fable-high remains the owner-facing intake model; typed code replaces prompt-only readiness. K3 becomes a substantial but non-authoritative large-spec/ambiguity/fleet resource. |
| Current entity-graph intake | Keep its taxonomy, visible scan, tool-first questions and one-decision UX. Replace ephemeral model-owned graph/lint/readiness with versioned claims, provenance, deterministic rules, owner ratification and receipts. |
| Generic `/agents` or Agent Hub buildout | Do not build as a durable control plane. Use OMP task agents, isolation, Agent Hub and `/agents` inside bounded stages. |
| Linear-backed autonomous fleet | Discard. Imported Linear data is provenance only. PostgreSQL/WorkService is runtime authority. |
| Linear-to-PostgreSQL migration | Keep as SQL-0 and finish it first. Do not hide NSI or Fleet scope inside the migration. |
| PostgreSQL autonomous fleet | Keep, but require `published` intake state, a current owner-ratified `IntakeContract`, matching `ELIGIBLE_FOR_PUBLICATION` receipt and `IntakePublicationReceipt`. |
| `omp-webui` wrapper | Promote to official OMP Web: one install, `omp web`, `/web`, shared canonical sessions, coordinated releases and a polished desktop/mobile experience. It may remain a separate source repository and process. |
| Remote OMP Workbench | Add progressively behind a distinct, capability-restricted gateway: private read-only first, then Needs You replies and safe cancel. Never publish the broad local daemon remotely. |
| Remote Fleet Manager | Keep its separate least-privileged gateway/origin and typed WorkService contracts, but present it inside the same OMP Web product shell. It is never the scheduler. |
| ADHD divergent-ideation skill | Port the useful pattern, not the runtime: optional owner-triggered perspectives, isolated proposals and separate synthesis inside `/intake`, with one frozen manifest, deterministic screening, hard budgets, durable partial results and ordinary owner-decision admission. Do not copy its automatic anchor stripping, random frames, fixed model-score pruning or Claude-only execution path. |
| DeepSeek Harness | Discard, as requested. |
| Graph engineering | Keep portfolio, lifecycle, intake-claim, execution and resource graphs separate. Use bounded code-owned graphs with deterministic joins. |
| General neuro-symbolic platform | Reject. No Neo4j/RDF/OWL/PDDL/general theorem prover or solver-everything policy without a qualified concrete need. |

## Corrected architecture

PostgreSQL accessed through WorkService is the sole durable authority. The new
intake compiler sits in front of planning and autonomous eligibility:

```text
Owner request + repository/tool evidence
                  |
                  v
      Fable candidate typed claims
       (+ optional fresh K3 alternate)
                  |
                  v
      WorkService admission/provenance
                  |
                  v
  code-owned ontology, rules and constraints
                  |
          gaps / conflicts / witnesses
                  |
                  v
      one material owner question
          |               |
          |       optional Explore alternatives
          |       (budgeted advisory side run)
          |               |
          +-------<-------+
                  v
 typed ACs -> READY_FOR_RATIFICATION assessment
                  |
                  v
 owner ratifies semantic-closure hash
                  |
                  v
 server-generated current positive readiness receipt
                  |
                  v
       explicit publishIntake transition
                  |
          +-------+--------+
          |                |
          v                v
       /plan         Fleet eligibility
```

The browser architecture and later execution architecture are:

```text
OMP Web shell
  |-- local owner client ------> local session gateway --> isolated OMP RPC sessions
  |-- restricted remote client -> remote session gateway -> bounded session actions
  |-- Work/Intake pages -------> Work/Intake BFF --------> WorkService
  `-- Fleet pages -------------> Fleet gateway/BFF ------> WorkService
                                                               |
PostgreSQL <----------------------------------------------------+
                                                               |
                                           deterministic fleet controller
                                              |              |
                                  isolated stage runners      +--> GitHub broker
```

The surface can look unified. The local session, restricted remote session,
Work/Intake and Fleet gateways remain separate processes/protocols/origins and
service identities wherever their authority differs. OMP Web is a client of
WorkService/Fleet contracts, never their truth. Fleet remains safe and
restartable with every browser process offline.

Models produce interpretation proposals, questions, plans, code and semantic
judgment. The owner ratifies product meaning. The harness owns state,
provenance, evidence, permissions, execution boundaries and legal transitions.

A solver proves only relative to its explicit encoding. `SAT`, successful
compilation, model agreement or a round trip is never called proof that the
requirements captured the owner's intent. Unsupported semantic requirements
remain visible and owner/auditor reviewed.

## What the neuro-symbolic tranche changes

The current intake is already neuro-symbolic-shaped: it has a fixed taxonomy,
entity graph, constraint vocabulary, dangling-edge stop and lint. The missing
mechanical boundary is that one model constructs, interprets and lints that
state while Markdown remains the publication unit.

`NSI-1` through `NSI-6` add:

- exact source snapshots and evidence spans;
- atomic proposed/admitted/superseded claims with authority and provenance;
- a small versioned ontology derived from the current 11 categories;
- code-owned cardinality, exclusivity, graph, applicability, conflict,
  coverage and readiness rules;
- gap-directed questions selected by code and phrased by Fable;
- selective solver adapters only where ordinary rules are insufficient;
- explicit `UNKNOWN`, `NOT_FORMALIZABLE` and solver error outcomes;
- typed acceptance criteria linked to claims and test oracles;
- owner ratification of an exact canonical contract hash;
- server-generated readiness receipts and deterministic Markdown views;
- current-versus-revised intake evaluation, shadow rollout and fail-closed
  cutover.

The user experience stays small: run `/intake`, answer a material question when
needed, optionally choose **Explore alternatives** for a costly open choice,
review the interpreted contract and ratify it. Question count, branch count and
specification length are not success metrics.

`NSI-E1` through `NSI-E4` are an optional side extension. Each child starts
only after the core NSI dependencies listed in `PROGRAM_DEPENDENCIES.md`; N4
requires the integrated NSI-E4/NSI-6 qualification:

- code selects only eligible, genuinely open questions;
- the owner sees estimated time plus either a maximum dollar spend, a metered
  quota allowance or fixed call/token/time limits before authorizing;
- four initial Flash-medium branches receive the same frozen context under
  deterministic reviewed perspectives;
- code rejects malformed references, duplicates and known hard-constraint
  violations before a separate Sol-high synthesis;
- the owner may use or combine an option, write an answer, say none fit or
  decide later;
- only the owner's exact confirmed answer enters the ordinary NSI decision
  ledger; and
- K3 deepening is a separately authorized model action, never an automatic
  second round.

The extension never declares readiness, changes the rule bundle, ratifies
meaning or publishes work. Base NSI and Fleet do not depend on it.

## Model boundaries

- Fable-high: owner-facing interviewer and primary candidate claim extractor.
- Fresh K3-256K/full K3: optional large-spec/repository scout, alternate
  formalizer and ambiguity detector; never readiness or ratification authority.
- Flash-medium exploration branches: bounded, isolated alternative proposals
  under deterministic frames and an identical frozen manifest.
- Sol-high exploration critic/synthesizer: compares the code-screened proposal
  set into neutral owner-facing options; code re-screens its output and every
  model judgment remains advisory.
- K3-256K exploration deepener: separately authorized elaboration of one
  owner-selected option; never an automatic loop.
- Deterministic reasoner: admission, constraints, conflicts, gaps, coverage and
  readiness relative to the frozen rule bundle.
- Owner: semantic decisions, waivers and exact contract ratification.
- Sol: planning from the current ratified contract; it may not fill missing
  intake by assumption.
- Fleet workers/auditor/Engineering Manager: downstream consumers/proposers;
  none may impersonate the owner.

Vivace/K3 remains central to downstream Fleet work: K3-256K high is the initial
standard fresh-session candidate, full K3 high is the large-context/EM capacity
route, and max is a separately budgeted new attempt. The K3 routes remain
fresh-only until preserved-thinking resume/compaction behavior is qualified.

## Recommended execution order

1. Finish the active PostgreSQL migration and prove every gate in
   `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md`.
2. Stop and record `SQL-0: PROVEN`. Do not fold the remaining programs into the
   migration.
3. In a fresh OMP session with both repositories available, run
   `03A_NATIVE_OMP_WEB_INTAKE.md`. The first target is bundled loopback
   `omp web` plus exact `/web` session handoff. Fixture-only OMP Web design may
   have started earlier under the isolation rule above. After SQL-0, the local
   OMP Web track may proceed in parallel with steps 4–6 because it owns no NSI
   or Fleet authority.
4. In a fresh OMP session rooted in `oh-my-pi`, run
   `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md`.
5. Implement `NSI-1` through `NSI-6` in dependency order. Shadow the revised
   intake before cutover; preserve rollback and typed history.
6. Require zero false-ready results on the versioned seeded critical-omission
   corpus and complete provenance for every premise contributing to a
   `READY_FOR_RATIFICATION` assessment. Calibrate other
   thresholds from data.
7. Optionally implement `NSI-E1` through `NSI-E4` and promote
   each child only after its listed core dependencies. Promote
   `N4: OWNER_CONFIRMED_EXPLORATION` only after integrated NSI-E4 plus NSI-6
   qualification. This does not block step 8, FLEET-1 or ordinary
   `/intake`; automatic usage-consuming execution remains prohibited, including
   metered-quota and resource-only subscription routes.
8. Only after NSI-6 qualification/cutover, run
   `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` in a fresh `oh-my-pi` session.
9. Implement FLEET-1 first. It consumes—not redefines—the intake contracts and
   readiness predicate.
10. After FLEET-1 consumer contracts exist, run
   `05_REMOTE_FLEET_MANAGER_INTAKE.md` in a fresh `omp-webui` session. Its
   Fleet gateway stays distinct, while its pages join the OMP Web shell.
11. Promote OMP Web, Intake, Fleet and remote capability only through their
   explicit gates in
   `PROGRAM_DEPENDENCIES.md`; remote commands and external writes remain later
   canaries.

The first meaningful intake milestone is a normal `/intake` whose source claims,
questions, ACs, owner decision and current readiness can be replayed from
WorkService without trusting a transcript. The first meaningful autonomy
milestone remains one exact locally verified, independently audited candidate
with no external writes.

## What “without user intervention” means

The future Fleet needs no continuous babysitting for work that already has a
current owner-ratified contract and falls inside policy. It must not invent
missing product intent. `NEEDS_SPEC`, conflicts, stale receipts, unsupported
formal obligations or unsafe work block that item while other eligible work can
continue.

## Package files

| File | Purpose |
| --- | --- |
| `00_READ_ME_FIRST.md` | Architecture, evidence limits and exact sequence. |
| `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` | Use only to review active SQL-0; not a second migration intake. |
| `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md` | Paste-ready post-SQL/pre-Fleet NSI program intake. |
| `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md` | Typed authority, storage, API, rule, solver, security and qualification baseline. |
| `03A_NATIVE_OMP_WEB_INTAKE.md` | Paste-ready official Web client, local handoff, restricted remote and unified-shell program. |
| `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` | Optional NSI-E1–E4 implementation contract for owner-triggered alternatives, budgets, durability, Web UX and qualification. |
| `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` | Fleet program rebased on current intake contracts and receipts. |
| `05_REMOTE_FLEET_MANAGER_INTAKE.md` | Fleet mode of OMP Web, retaining a separate least-privileged gateway/origin. |
| `06_MODEL_AND_AGENT_OPERATING_POLICY.md` | Model, risk, evidence, containment, context and evaluation policy. |
| `07_HARNESS_RECOMMENDATION_CROSSWALK.md` | Already-built/adopted/adapted/deferred/rejected recommendation map. |
| `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md` | Source quality, factual corrections and research-to-design mapping. |
| `09_SOLO_DEVELOPER_USER_GUIDE.md` | Minimal daily interaction and staged application guide. |
| `PROGRAM_DEPENDENCIES.md` | Exact SQL, NSI, Fleet and Fleet Manager dependencies/gates. |
| `MANIFEST.md` | Package identity, order and file inventory. |
| `V5_BASELINE_SHA256SUMS` | Exact v5 baseline hashes, including the original generated checksum file. |
| `V5_TO_V6_PRESERVATION_AND_CHANGELOG.md` | Path-by-path and section-level preservation/disposition record. |
| `V6_BASELINE_SHA256SUMS` | Exact immutable v6 file hashes, including v6's generated checksum file. |
| `V6_TO_V7_PRESERVATION_AND_CHANGELOG.md` | Path-by-path v6 preservation proof and complete v7 semantic change record. |
| `SHA256SUMS` | Integrity hashes generated after final verification. |

## Primary anchors

- [Current fork](https://github.com/theturtlecsz/oh-my-pi)
- [Current omp-webui](https://github.com/theturtlecsz/omp-webui)
- [Kimi Code browser guide](https://www.kimi.com/code/docs/en/kimi-code-cli/guides/web.html)
- [Orca remote servers](https://www.onorca.dev/docs/remote-servers)
- [Agent Orchestrator architecture](https://aoagents.dev/docs/architecture/)
- [ADHD source at the inspected anchor](https://github.com/UditAkhourii/adhd/tree/53ab5576b77fb3d6e62739a1a285356261e5f568)
- [Tree of Thoughts](https://arxiv.org/abs/2305.10601)
- [Current intake skill at the research anchor](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/session-system/skills/intake/SKILL.md)
- [Current model bookends at the research anchor](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/session-system/extensions/model-bookends.ts)
- [Requirements-Sufficiency-Gated Automation](https://conf.researchr.org/details/RE-2026/RE-2026-Research-Papers/23/Requirements-Sufficiency-Gating-for-LLM-Assisted-Automation)
- [Logic-LM](https://aclanthology.org/2023.findings-emnlp.248/)
- [LLMs as ASP Programmers](https://aclanthology.org/2026.findings-acl.1151/)
- [AgentSpec](https://conf.researchr.org/details/icse-2026/icse-2026-research-track/29/AgentSpec-Customizable-Runtime-Enforcement-for-Safe-and-Reliable-LLM-Agents)
- [Z3 guide](https://microsoft.github.io/z3guide/docs/logic/propositional-logic/)

The full source register and caveats are in
`08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`.
