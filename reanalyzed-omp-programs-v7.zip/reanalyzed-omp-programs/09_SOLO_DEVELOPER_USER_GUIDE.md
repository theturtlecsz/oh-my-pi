# Solo developer user guide

## The 30-second explanation

OMP should feel like one application you can use from a terminal, desktop
browser or phone.

The target experience is:

1. Run `omp web`, or type `/web` to open the current session in a browser.
2. Give it work with `/intake` or **New Work**.
3. If OMP reaches a genuinely open design choice, optionally choose
   **Explore alternatives** and approve its estimated time plus either a
   maximum dollar spend, a metered quota allowance or fixed calls/tokens/time.
4. Use or combine an option, write your own answer, say none fit or decide
   later; only your confirmed answer—not model suggestions—becomes a requirement.
5. Leave it running and check **Needs You** only when OMP requires a decision
   or approval.
6. Review the exact diff and evidence when a candidate, failure or PR is ready.

The reliability system remains underneath: exact requirements, durable
state, deterministic checks, independent audit and candidate-bound receipts.
OMP Web makes it comfortable to use; it does not let a screen or model declare
work correct.

## Everyday use

Give OMP a new outcome from the relevant repository:

```text
/intake Add [capability]. The user outcome is [outcome].
```

Or choose **New Work** in OMP Web. Add constraints or evidence if you know
them; you do not need to design the solution. OMP inspects the code, asks one
material question at a time, shows the exact requirement it understood, and
asks you to approve it before planning or autonomous work can begin.

When a question has several genuinely good answers, you may choose **Explore
alternatives** or run:

```text
/explore
```

This first shows estimated time and one of three honest limits:

- a maximum dollar spend;
- a metered quota allowance; or
- fixed calls, tokens and time when a subscription exposes neither dollars nor
  quota.

No model call starts until you choose **Run exploration**. You then receive two
to four neutral options and can **Use this option**, **Combine options**,
**Write my own answer**, **None of these fit**, **Decide later**, or separately
authorize **Explore this option further**. Only the exact answer you confirm is
recorded as a requirement.

If `/explore` is not appropriate, OMP says `No eligible open intake decision
right now`, gives one plain reason, makes no model call, and continues
intake—for example, `This is a repository fact; OMP will inspect the code
instead.` `/intake --explore` also continues normally if no eligible question
appears.

If a provider result cannot be confirmed, the run becomes **Provider result
unknown**. Its options stay disabled. OMP shows known usage and the maximum
it is counting against your internal limit while the provider charge remains
unknown; you can write your own answer, keep waiting when lookup is possible,
or request a replacement through a fresh offer that warns about possible
duplicate currency charge, quota use or subscription use.

A normal day is: submit work, leave it running, check **Needs You**, answer a
product decision, then review the exact diff and evidence. You should not need
to choose agents or watch their transcripts.

## What this adds for one developer

The value is not “more agents.” It is less rework and safer unattended progress:

- your exact original words remain traceable instead of being silently
  rewritten by a model;
- repository facts, owner decisions and model guesses stay visibly different;
- contradictions and missing rollback/security/failure behavior block before
  implementation rather than appearing during final review;
- each acceptance criterion points back to the requirement/decision it proves;
- OMP asks one high-value question instead of generating a questionnaire for
  its own sake;
- for the occasional hard, open-ended choice, you can ask for several genuinely
  different approaches and their tradeoffs without starting agents manually;
- the alternatives are advice only: they cannot silently alter requirements or
  declare the intake ready, and calls cannot exceed the currency, metered-quota
  or fixed call/token/time limits you approved;
- a restart does not erase what was decided or why;
- the planner and Fleet cannot quietly invent missing intent;
- autonomous work proceeds only from a current contract you actually approved;
- you intervene for product choices, unusual risk and real failures—not routine
  orchestration;
- you install and version-match OMP Web with OMP, not as a second product;
- terminal and browser continue the same canonical session;
- you can check work from a phone without opening a remote shell;
- one Needs You list replaces watching agent transcripts;
- you can submit work and later review candidate-bound diffs remotely; and
- failures and blockers are shown in plain language with a legal next action.

The cost is additional machinery and an occasional semantic review step. That
cost is justified for ambiguous, multi-file, security, migration, concurrency
or unattended work. Small obvious edits should still take the shortest
qualified path; question count and specification size are not goals.

Alternative exploration is intentionally even narrower. Use it when choosing
an architecture, product behavior, migration strategy or boundary with several
plausible answers. Skip it for yes/no facts, repository questions, obvious bug
fixes, mechanical edits and decisions you have already made.

## Builder and maintainer appendix

Everything below explains how to build and qualify the target system. It is not
required for ordinary daily use.

### Current build status

You said the PostgreSQL migration is still active. Keep finishing it.

Do not run the neuro-symbolic or Fleet intakes until the migration produces
`SQL-0: PROVEN`. If useful, paste only the review block from
`01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` into the current migration
session. It checks authority, cutover, idempotency, evidence seams,
backup/restore and the complete interactive workflow without creating a second
migration program.

The repository anchors in this ZIP are historical evidence. Check live status
from the current migration records and code; do not infer completion merely
because PostgreSQL tables or a WorkService package exist.

### One-time build order

#### 1. Finish SQL-0

Required outcome:

- PostgreSQL through WorkService is the only work authority;
- Linear is imported provenance only and has no runtime fallback/writer;
- the owner workflow works end to end;
- service contracts, idempotency, events, reconciliation and restore are
  proven;
- agents have no direct SQL credential.

Stop at `SQL-0: PROVEN`.

#### Parallel product track: make omp-webui official OMP Web

Fixture/design work may proceed while SQL-0 finishes only if it stays in the
separate `omp-webui` repository and does not change OMP core, WorkService or
Fleet authority. After SQL-0, paste the fenced intake from
`03A_NATIVE_OMP_WEB_INTAKE.md` with both repositories available.

The first useful release is deliberately small:

- `omp web` launches the bundled matching Web client;
- `/web` opens the exact current supported session;
- terminal and browser show the same sessions, models and settings;
- current rich local Chat/tool/file/Git behavior is preserved;
- reconnect and cross-session isolation are proven; and
- it works cleanly at phone widths.

Do not connect this early track directly to PostgreSQL/Fleet state and do not
publish the broad local daemon remotely. Restricted remote access is a later,
separate gateway milestone.

#### 2. Publish and build the Intake Compiler

Start a fresh OMP session in `theturtlecsz/oh-my-pi`, open
`02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md`, and paste the fenced `/intake`
block exactly once.

The session will inspect the live implementation, ask material architecture
questions, and—after your ratification—publish `NSI-1` through `NSI-6`.

Build them in this order:

```text
NSI-1 contracts/ontology
  -> NSI-2 claim/provenance ledger
  -> NSI-3 deterministic reasoner
  -> NSI-4 gap-directed questions
  -> NSI-5 acceptance/ratification/readiness
  -> NSI-6 evaluation/shadow cutover
```

`NSI-2` and `NSI-3` may proceed after NSI-1; `NSI-4` and `NSI-5` require both.

The important stopping point is not “a solver runs.” It is:

- current `/intake` UX preserved;
- every premise contributing to `READY_FOR_RATIFICATION` traceable;
- critical-omission fixtures produce zero false-ready outcomes;
- owner ratification and readiness remain separate, hash-bound receipts;
- Markdown is only a rendered view;
- rollback/shadow comparison is proven.

As each listed core intake dependency stabilizes, `NSI-E1` through `NSI-E4`
may add **Explore alternatives** as an optional side extension:

```text
NSI-E1 contracts, policy, reviewed perspectives and shared job controls
  -> NSI-E2 durable runner, screening and comparison
  -> NSI-E3 owner decision, CLI and local Web
  -> NSI-E4 evaluation, offer-only shadow and promotion
  -> N4: OWNER_CONFIRMED_EXPLORATION
```

This extension is not a prerequisite for `NSI-6`, FLEET-1 or normal intake.
Build it when the core contracts it consumes are stable; qualify it separately
instead of delaying the useful base workflow.

#### 3. Publish and build the Fleet Kernel

Only after `NSI-6: QUALIFIED_AND_CUT_OVER`, start a fresh OMP session in
`oh-my-pi` and paste the fenced block from
`04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md`.

Implement `FLEET-1` first. The useful milestones are intentionally gradual:

1. Typed authority/contracts and intake eligibility.
2. Harness package/CI, WorkService FleetControl, risk/context and containment.
3. Deterministic verification and a mechanically isolated audit.
4. One local item, one writer, zero external writes.
5. Fault/evaluation qualification.
6. Draft-PR canary with manual merge.
7. Exact-SHA CI/integration and bounded scheduler.
8. Engineering Manager recommendations, then only qualified reversible
   authority.
9. Unattended eligible-backlog drain.

Do not jump straight to a fleet of writers. The first valuable autonomous
result is one item that can survive process death, reproduce its context and
evidence, and stop honestly when it needs you.

#### 4. Extend OMP Web with Intake and Fleet pages

OWEB-7 may add New Work after NSI-6 and the OWEB-5/6 remote identity/gateway
prerequisites are qualified. After FLEET-1 consumer contracts exist, start a
fresh session in `omp-webui` and paste the fenced block from
`05_REMOTE_FLEET_MANAGER_INTAKE.md` for the Fleet-specific pages/gateway.

This is no longer a second product. Add pages to the common OMP Web shell while
keeping the Fleet gateway/origin separate:

- after NSI-6: New Work, intake questions, ratification and publication;
- after FLEET-8/WFM-7: read-only runs, evidence and exception views; and
- after FLEET-12 and matching WFM handlers: candidate feedback and typed
  controls.

Do not expose the broad local Chat daemon as the remote Fleet control surface.

### Detailed interaction reference

#### A new idea

From the relevant repository:

```text
/intake Add [desired capability]. The user outcome is [outcome].
```

Give the outcome and any known constraints. You do not need to pre-write a
complete issue. OMP inspects the repository and asks only material decisions
that code cannot discover.

In OMP Web, **New Work** asks for repository, desired outcome, known
constraints and optional evidence. It creates a collecting `IntakeDraft`, not
eligible Fleet work. The same NSI questions, exact-hash ratification and
publication gate still apply. It uses the separate least-privileged Work/Intake
gateway—not the remote session gateway or Fleet gateway.

#### An existing issue or draft

```text
/intake Existing plan/draft — [paste or reference the issue/draft].
```

The system treats the draft as candidate input, not automatically ratified
truth. It will preserve existing decisions, identify contradictions/gaps and
ask you to confirm or overturn only what matters.

#### A finished typed blueprint

Use the current supported publish/import entry seam after NSI cutover. It may
skip conversational interviewing, but it cannot bypass evidence admission,
machine checks or owner ratification. A Markdown file alone cannot become
Fleet-eligible.

#### A backlog

Create or import each item through the same typed intake boundary. Once items
are `published` with current positive receipts, the deterministic scheduler
selects those whose dependencies, locks, budgets, risk and policy allow execution. The Engineering
Manager may propose decomposition and priority, but cannot invent or ratify
product intent.

### What one intake feels like

1. You state the desired outcome.
2. Fable and tools inspect relevant source and propose typed interpretations.
3. The server records facts, decisions and sources in their proper roles.
4. Code checks for important missing information or contradictions.
5. If needed, you see one question with the deciding evidence and consequence.
6. For an eligible open choice, you may answer directly or choose **Explore
   alternatives**. OMP first shows estimated time plus either a
   broker-enforced price ceiling, a metered quota allowance or fixed
   calls/tokens/time for a resource-only subscription.
7. You use or combine an option, write an answer, say none fit or decide later.
   OMP shows the exact answer it will record, and you confirm it.
8. Your exact answer is stored; nontrivial interpretation is confirmed.
9. OMP drafts acceptance checks tied to the requirements.
10. You review your original wording, OMP's interpretation, assumptions,
    non-goals and anything still unresolved.
11. You approve this exact requirement version; OMP records its hash.
12. The server rechecks it and records whether it is eligible. A failed recheck
    returns it for correction instead of quietly continuing.
13. You publish that exact eligible intake through the supported owner command.
14. Only the `published` run may now be consumed by `/plan` or Fleet.

If a question budget ends while a critical premise is missing, the item becomes
`NEEDS_SPEC`; it never becomes ready merely because the interview got long.

### Explore alternatives: detailed behavior

Use it only when you would otherwise pause and brainstorm or ask several people
for competing approaches.

In the terminal, the qualified command is:

```text
/explore
```

To request an offer when starting intake, use `/intake --explore <request>`.
Neither command pre-authorizes model calls; both still lead to the time and
currency-or-resource confirmation.

While a run is active:

```text
/explore status
/explore cancel
```

`/explore status` also presents **Keep waiting** or **Authorize a replacement
call** when either is legal. Replacement only opens a fresh offer and limits
confirmation; it never retries immediately.

After intake is published, `/explore approaches` requests a separately
authorized advisory comparison for `/plan`; it cannot change requirements.

In OMP Web, choose **Explore alternatives** beside the current eligible
question. Before any exploration model call, OMP leads with something like this (the actual
figures are generated for your run):

```text
About 1–3 min · estimated $X–$Y · maximum $Z
```

Metered quota says `Uses quota · maximum Q units · N calls / M tokens / T
minutes`. A resource-only subscription says `Uses subscription · dollar and
quota limits unavailable · maximum N calls / M tokens / T minutes`. Details
show why the question is eligible, frozen sources/constraints, provider
account/destination/region, what data classes are sent, training use,
cache mode/duration, retention duration, deletion support, models, calls and
tokens. You must confirm **Run exploration** in every mode.

The initial experiment creates four bounded, isolated perspectives, checks
their typed references and explicit known constraints, rechecks the final
comparison, and uses a separate synthesizer to present two to four neutral
options. You can:

- **Use this option**;
- **Combine options**;
- **Write my own answer**;
- choose **None of these fit**; or
- **Decide later**.

No option is automatically accepted. Numeric model confidence is not shown as
truth, and the UI does not preselect or star a recommendation. If one option
deserves more detail, **Explore this option further** starts a separate child
run for one option, with its own currency-or-resource preview and enforceable limits;
it never starts automatically.

If a provider fails, OMP keeps clearly labeled successful branches when safe
and tells you what is missing. If the question, constraints, repository
snapshot or policy changes, the result becomes **Outdated** and cannot be
submitted. You may read completed ideas as incomplete notes, but cannot use an
option until comparison and screening finish. Answer directly or choose **Run
exploration again**, which always shows a fresh offer and requires new limits
confirmation.
Cancel stops new calls; calls already sent may still finish and consume money,
quota or subscription usage. The
same Needs You question stays open. Raw private model reasoning is neither
requested nor displayed.

If OMP cannot determine whether a provider accepted or completed a call, it
shows **Checking provider result**, then **Provider result unknown** at the
reconciliation deadline. Uncertain output is never selectable. Known
provider-reported usage is separate from a mode-specific warning: `$Z` remains
counted against a currency limit, `Q units` remain counted against a quota
limit, or the authorized calls/tokens/time remain reserved for a resource-only
subscription. **Keep waiting** is offered only while lookup can still succeed;
any replacement call requires a fresh offer and warns of possible duplicate
currency, quota or subscription use.

After intake is published, the same mechanism may create an advisory planning
handoff. That artifact can help `/plan` compare implementation approaches, but
it is outside the ratified semantic contract and cannot change product intent.

### Who does what

| Participant | Job | Cannot do |
| --- | --- | --- |
| Fable-high | Talk with you, extract candidate meaning, render questions/ACs | Admit claims, declare readiness, ratify |
| K3-256K/full K3 | Large-spec/repository alternate interpretation or formalization; downstream Fleet planning/implementation | Vote on truth, answer for you, self-audit |
| Flash-medium exploration branches | Produce isolated alternatives under code-selected perspectives | See other branches, use tools, authorize spend or create a decision |
| Sol-high exploration synthesizer | Turn screened alternatives into a small neutral tradeoff set | Ratify meaning, hide hard-constraint failures or declare a winner |
| K3-256K exploration deepener | Elaborate one selected option after separate owner approval | Start automatically or change the owner's answer |
| Deterministic intake reasoner | Validate schemas/rules, find gaps/conflicts, compute the pre-ratification assessment | Decide your intended product meaning or mint a receipt |
| You | Make material product decisions, approve waivers, ratify exact meaning | Babysit ordinary tool calls |
| Sol | Plan from the ratified contract; high-risk challenge/escalation | Rewrite intake by assumption |
| Flash | Fast trivial/local work and bounded scouts | Bypass risk or receipts |
| Terra | High-risk implementation lane | Authorize lifecycle/external effects |
| Opus auditor | Fresh independent final semantic/evidence audit | Repair its own finding or mutate candidate |
| Engineering Manager (K3) | Propose ordering, decomposition, risk and exceptions | Ratify, merge, change policy or mint a positive receipt |
| WorkService | Admit provenance, revalidate the ratified hash, mint positive receipts and publish | Invent product intent or accept caller-asserted authority |
| Fleet controller | Claims, leases, execution gates, evidence, transitions and recovery | Invent product intent or mint intake receipts |

Formal solvers are tools under the deterministic reasoner, not additional
managers. Z3 is used only when bounded hard constraints justify it. ASP and LTL
remain off until a concrete, evaluated need exists. `UNKNOWN` and
`NOT_FORMALIZABLE` stay visible.

### When you must intervene

#### `NEEDS_SPEC`

A named owner premise is missing. The UI/CLI should show the exact blocked
rule/claim, relevant evidence and one question. Answer it or explicitly defer;
the system should not guess.

#### `CONFLICTED`

Two supported meanings cannot both stand. Review source evidence and choose or
revise. Last-write-wins must not hide the disagreement.

#### `STALE`

A repository source, Work revision, ontology/rule bundle or contract changed.
Rebaseline and ratify the new hash; do not reuse the old receipt.

#### Formal `UNKNOWN`, `NOT_FORMALIZABLE` or `SOLVER_ERROR`

The formal layer cannot establish a required property. If policy requires it,
the item blocks. Otherwise it remains an explicit semantic/manual verification
obligation. A model may explain it but cannot convert it into PASS.

#### `BLOCKED` or `QUARANTINED`

A dependency, provider, budget, containment, verification, policy or repeated
repair problem prevents safe continuation. Resolve the external condition or
approve a new bounded attempt.

#### Audit `NEEDS_FIX` or `BLOCKED`

Review evidence-backed findings. A repair creates a new candidate, verification
and fresh auditor; no old PASS survives mutation.

#### Unknown external result

The GitHub broker or another external operation may have succeeded before a
timeout. Reconcile actual external state before retry. Never click/retry blindly.

### A normal day with OMP Web

1. From desktop or phone, choose **New Work** and describe the outcome.
2. OMP inspects the repository and asks only material product questions.
3. On a hard open choice, you optionally run **Explore alternatives**, approve
   its limits and choose or combine an option.
4. You leave; the work continues on the OMP host.
5. A Needs You notification links to one blocked decision.
6. You answer it, and the qualified workflow continues.
7. Candidate Ready opens the exact diff, tests and audit.
8. You approve a draft PR or send candidate-bound feedback.

You spend time on intent and review, not choosing agents or watching commands.

### Local versus remote OMP Web

It is one interface, but remote access deliberately has fewer powers.

| Local browser on the development machine | Remote browser or phone |
| --- | --- |
| Full OMP conversation and approved tools | Monitor sessions and runs |
| Files, Git views and optional local terminal | Answer explicit Needs You questions |
| Models, providers and local settings | Submit an intake and safe cancel/pause |
| Existing interactive approvals | Review candidate-bound diffs/evidence |
| Manual local canary during NSI-E4; normal local use after N4 | Private remote canary only after N4 plus OWEB-7, with the same explicit limits and no general agent controls |
| Normal local OMP policy | No general terminal, credentials or unrestricted files/Git |

The server decides which actions work. A stolen phone session must not become a
remote shell into the development machine.

### Remote use progressively

1. Native loopback OMP Web.
2. Private read-only remote sessions.
3. Needs You notifications, bounded answers and safe cancel.
4. Typed New Work/ratification after NSI-6.
5. Owner-confirmed Explore alternatives after N4 plus OWEB-7.
6. Fleet run/evidence/diff review after FLEET-8/WFM-7.
7. Fenced typed controls after exact candidate and command contracts.

The WebUI never creates readiness, schedules agents, holds provider/GitHub
credentials or opens a general remote PTY.

### What not to do

- Do not apply NSI/Fleet while SQL-0 is still active.
- Do not call the current prompt graph “mechanically verified” before NSI.
- Do not add a solver or graph database merely for the neuro-symbolic label.
- Do not treat SAT, proof, model consensus or a long spec as correct intent.
- Do not run alternative exploration for every question, let a model-generated
  score delete an option, or confuse more calls with a better decision.
- Do not allow automatic anchor rewriting, random unrecorded frames, hidden
  cost overruns or automatic K3 deepening.
- Do not make K3, Fable or the Engineering Manager the owner.
- Do not let Markdown or transcript prose advance lifecycle state.
- Do not start with multiple writer agents or unattended critical work.
- Do not expose the broad-authority local Chat daemon remotely. Use the
  dedicated authenticated, capability-restricted gateway.
- Do not bypass a stale/missing receipt to keep utilization high.

### Package quick reference

| File | When to use it |
| --- | --- |
| `00_READ_ME_FIRST.md` | Read for architecture and sequencing. |
| `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` | Use now only if SQL-0 still needs a review pass. |
| `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md` | Paste after SQL-0 is PROVEN. |
| `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md` | Implementation contract/reference for NSI-1–NSI-6. |
| `03A_NATIVE_OMP_WEB_INTAKE.md` | Paste after SQL-0 for native local Web, then promote remote/Intake/Fleet pieces at their gates. |
| `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` | Build the optional NSI-E1–E4 Explore alternatives extension and N4 gate. |
| `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` | Paste after NSI-6 qualifies/cuts over. |
| `05_REMOTE_FLEET_MANAGER_INTAKE.md` | Paste after FLEET-1 consumer contracts exist. |
| `06_MODEL_AND_AGENT_OPERATING_POLICY.md` | Configure and reason about model/risk/agent roles. |
| `07_HARNESS_RECOMMENDATION_CROSSWALK.md` | See what is adopted, adapted, deferred or rejected. |
| `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md` | Inspect source quality and design rationale. |
| `PROGRAM_DEPENDENCIES.md` | Check exact dependencies and promotion gates. |

### Your next action

Finish SQL-0. The isolated fixture/design portion of OMP Web may proceed now if
it does not touch the migration or OMP core. When SQL-0 reports `PROVEN`, start
fresh sessions for `03A_NATIVE_OMP_WEB_INTAKE.md` and
`02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md`; keep their repositories and
authority scopes separate. Do not paste the Fleet intake before NSI-6. Add
NSI-E1–E4 only after the core contracts they consume are stable; they do not
need to delay FLEET-1.
