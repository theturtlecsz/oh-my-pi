# Paste-ready intake: Fleet mode of Native OMP Web

Run this in a fresh OMP session rooted in the `theturtlecsz/omp-webui` checkout
after NSI-6 has qualified the typed intake contracts and FLEET-1 has ratified
the Fleet authority and consumer contracts. This retained WFM program builds
the Fleet-facing backend and pages of official OMP Web; it does not duplicate
the local/remote session work owned by `03A_NATIVE_OMP_WEB_INTAKE.md`. WFM-1
through WFM-5 may proceed against deterministic fixtures while live fleet
services are built.

```text
/intake Existing plan/draft — program-level intake.

PROGRAM TITLE

OMP Web Fleet Manager for the PostgreSQL-backed Autonomous OMP Fleet

CONTEXT AND PROCESS

This intake concerns:

- https://github.com/theturtlecsz/omp-webui
- https://github.com/theturtlecsz/oh-my-pi
- the live PostgreSQL/WorkService program;
- the qualified neuro-symbolic intake schemas, projections, ratification and
  readiness receipts;
- the Autonomous Fleet Kernel program and its versioned consumer contracts.

Begin by resolving and recording the actual HEAD and release/version of both
repositories. Inspect the current omp-webui charter, architecture, protocol,
security model, tests and deployment; the live WorkService and NSI schemas/
contracts; and the Fleet Kernel parent/children. Do not assume that commits,
OMP protocol
versions or architecture descriptions in this prompt remain current.

Run this as an Existing plan/draft intake. Do not implement anything and do not
publish automatically. Complete the visible scan, consumer-capability crosswalk,
threat-model pass, operator-workflow pass and Socratic pass first. Ask only
questions that materially affect identity, authority, deployment, privacy,
availability, risk or scope.

Query WorkService for related work. Reuse/link existing backend children instead
of duplicating WorkService, controller, GitHub broker, policy, receipt or event
work. Classify required capabilities as PRESENT_AND_PROVEN,
PRESENT_NOT_PROVEN, MISSING or NOT_APPLICABLE. The WebUI program owns consumer
requirements and UI/gateway implementation; backend gaps are linked to the
appropriate Fleet child and created here only when inspection proves no owner.

After owner ratification, publish one parent and dependency-linked children
through WorkService using stable idempotency keys. If WorkService publication
is unavailable, do not fall back to Linear or any SQLite database. Produce a
deterministic publication-ready manifest and stop.

OWNER-RATIFIED OUTCOME

Extend official OMP Web with a remote supervisory Fleet Manager for the
autonomous OMP coding fleet while preserving the local Chat workbench and the
restricted Remote Workbench specified by OWEB-1..9.

The Fleet Manager must let an authenticated owner or observer understand work,
intake claims/evidence, unresolved product decisions, contract ratification,
readiness and invalidation,
dependencies, runs, stages, attempts, agents, Engineering Manager proposals,
execution graphs, models, budgets, receipts, evidence, incidents and health;
and later submit
typed, auditable fleet commands. It must never become the work ledger,
scheduler, model worker, shell gateway, GitHub writer or source of truth.

Fleet execution continues safely while the browser and every Fleet Manager
process are stopped, disconnected, upgrading, stale or compromised.

CRITICAL PRODUCT, AUTHORITY AND PROCESS SEPARATION

The current omp-webui is a strong local-first OMP session workbench: React ->
Bun daemon -> one OMP RPC worker per session, with SQLite indexing/replay and a
single bidirectional WebSocket for prompts, steering, approvals, workspace/file/
Git access, provider configuration and optional PTY. Those are intentional
local-trust choices and must not become the remote fleet security model.

Create one user-facing OMP Web product with four mechanically distinct trust
surfaces. The common shell and visual language do not create shared authority:

1. LOCAL OMP WEB (`LOCAL_OWNER`)
   - Keep the existing local daemon, OMP worker supervision, JSONL/session
     behavior and local SQLite index/replay where useful.
   - Keep it loopback/local-trust by default.
   - Fleet migration does not require removing this SQLite database.
   - It is owned by OWEB-1..4, not by this WFM program.

2. REMOTE OMP WORKBENCH (`REMOTE_RESTRICTED`)
   - Use the separate session gateway, identity, device and bounded-action
     contracts owned by OWEB-5..6.
   - Do not reuse the broad local protocol merely behind a flag or route.
   - It may show/answer exact Needs You items but cannot mutate Fleet state.

3. WORK/INTAKE (`WORK_OWNER`)
   - Use the separate least-privileged Work/Intake BFF, service identity and
     origin owned by OWEB-7 after NSI-6.
   - It may reuse reviewed identity/presentation components, but not Remote
     Session or Fleet credentials/routes.
   - It cannot reach local OMP RPC, Fleet control or GitHub.

4. REMOTE FLEET MANAGER (`FLEET_SUPERVISORY`)
   - Add a separate least-privileged Fleet gateway process and separate Fleet
     entry point/origin behind the OMP Web navigation shell.
   - Share presentation components and generated types only where safe.
   - Do not import or expose local worker, terminal, workspace, provider, Git,
     session-file, OMP-home or Chat SQLite authority modules.

Do not add fleet commands to the current browser protocol v1 and do not expose
the current all-powerful session daemon remotely. A configuration flag, route
prefix or hidden control on one daemon is not sufficient isolation.

“One product” means one install, product name, navigation and coordinated
release. It does not mean one origin, process, credential, route registry or
state store. The Fleet gateway remains independently deployable and removable.

AUTHORITY BOUNDARY

ARCHITECTURE DIAGRAM

remote browser
    |
    | HTTPS queries / typed commands; read-only SSE
    v
Fleet gateway / BFF
    |
    | authenticated, authorized, versioned service calls
    v
WorkService <--> PostgreSQL
    |
    +--> deterministic fleet controller --> isolated OMP stage runners
    |
    +--> controller-owned GitHub broker --> GitHub / CI

END ARCHITECTURE DIAGRAM

- PostgreSQL through WorkService remains sole fleet authority.
- The Fleet gateway is a BFF and policy-enforcing consumer, not a scheduler,
  controller, ledger, broker, worker supervisor or database client.
- In Fleet mode, the browser never reaches PostgreSQL, OMP RPC, worktrees,
  shells, provider credentials or GitHub credentials. Local interactive OMP
  Web reaches only its separately authorized local-session APIs; the restricted
  remote workbench reaches only its narrow session projection/action gateway.
- The browser controls logical work/run/stage aggregates, never PIDs, raw OMP
  sessions, paths or agents.
- Event delivery is notification, not authority. On reconnect or cursor gaps,
  re-read WorkService state.
- A WorkService outage prevents new commands/external effects; stale browser
  state never authorizes a transition.

REMOTE PROTOCOL

Create a new versioned fleet API, not an extension of the Chat WebSocket:

1. HTTPS read projections with bounded pagination/filtering and an
   `as_of_cursor` snapshot identity.

2. HTTPS typed asynchronous commands. The browser sends:
   - an `Idempotency-Key` header;
   - expected aggregate revision/`If-Match`;
   - expected policy/manifest identity where required;
   - logical target and typed payload;
   - reason for consequential actions.

   WorkService creates the canonical `operation_id`. Same key/same request
   returns the original operation; same key/different request is rejected.
   Commands return an operation resource, normally `202 Accepted`; the UI
   distinguishes submitted, accepted, pending, achieved, rejected, failed,
   cancelled and ambiguous/reconciling.

3. Server-Sent Events for a read-only, durable event stream with opaque cursor,
   resume, deduplication, gap detection, backpressure and version negotiation.
   Use a read-only WebSocket only if evidence proves SSE cannot meet a specific
   requirement. Never put access tokens in a URL.

4. Generated OpenAPI/JSON Schema contracts and generated TypeScript clients.
   Include API/feature negotiation, consistent typed errors and deterministic
   fixtures. Consumer-driven tests prevent either side from drifting.

5. WorkService returns resource-scoped `allowed_actions` for usability. The
   gateway still authorizes every request and the UI never treats a visible or
   hidden button as enforcement.

IDENTITY, AUTHORIZATION AND REMOTE DEPLOYMENT

Use a provider-neutral BFF design:

- private-network-first deployment through a trusted identity-aware proxy,
  WireGuard/Tailscale or an OIDC provider;
- OIDC Authorization Code + PKCE where applicable;
- access/refresh tokens retained server-side;
- opaque server-side session;
- `__Host-`, Secure, HttpOnly, SameSite cookie;
- exact Host and Origin validation plus CSRF protection on every mutation;
- session rotation, revocation and immediate live-stream closure;
- authentication-assurance/step-up abstraction satisfied by IdP MFA or
  WebAuthn for consequential actions;
- resource/action/risk-scoped capabilities, not scattered role-name checks;
- initial `owner` and `observer` profiles; later `operator` and `approver`
  bundles must not require redesign;
- per-principal immutable audit with actor derived server-side;
- rate, request-size, connection and stream limits;
- service-to-service identity between gateway and WorkService.

Do not require a custom passkey system before the deployment identity provider
is known. Direct Internet exposure is a later promotion, not an MVP default.

Apply restrictive CSP, HSTS, frame denial, `nosniff`, referrer and permissions
policies. No third-party scripts, ads or analytics on the privileged Fleet
origin. Store no access token, fleet state or configurable backend endpoint in
browser local/session storage, query strings or fragments.

UNTRUSTED CONTENT AND ARTIFACTS

Work text, model output, diffs, repository files, test logs, artifacts, links
and Engineering Manager proposals are untrusted display content.

- Sanitize and bound all rendered Markdown, ANSI, code, diff and logs.
- Never render active HTML/SVG with Fleet authority.
- Serve risky artifacts as forced downloads or sanitized previews, preferably
  from a cookie-less origin.
- Prevent script execution, navigation abuse, credentialed cross-origin fetch,
  tabnabbing, oversized rendering and terminal escape behavior.
- Agent-generated content cannot create an action, approval, hidden field or
  trusted instruction. Commands originate only from typed UI controls and are
  revalidated by gateway and WorkService.
- Redact secrets and sensitive environment data at production and display
  boundaries. Authorization applies to every projection, artifact and event,
  not merely the page that links to it.

REMOTE OPERATOR EXPERIENCE

Build an exception-first Fleet information architecture:

- global safety strip: mode, stop/pause/drain state, policy/manifest versions,
  provider/GitHub/DB health and active incidents;
- overview: eligible/running/blocked/quarantined, throughput, failure and repair
  rate, cost/budget, SLO and alert summaries;
- work/dependency explorer with exact “why not running” explanations;
- intake contract view with exact source evidence, proposed/admitted/rejected/
  superseded claims, owner decisions, unresolved gaps/conflicts, rule failures,
  formal-result scope/counterexamples, AC traceability, contract/snapshot/rule
  hashes, ratification and current/stale readiness identity;
- per-attempt execution graph showing frozen graph epoch/hash, node kind/state,
  required artifact inputs, expected join cardinality, resource waits, retries,
  invalidated descendants and critical path without exposing raw prompts;
- run/stage/attempt timeline with requested/resolved model/provider/effort,
  fallback reason, model-history/resume policy, fresh-attempt reason, computed
  TaskRisk/reasons, ContextManifest/policy version, usage/cost, containment
  profile, lease/fence, base/candidate identity and terminal outcome;
- evidence: validated typed EvidenceManifest and AuditResult, acceptance
  contract, plan, bounded diff, deterministic verification, unverified claims,
  evidence references, CI and merge receipts tied to exact hashes;
- Engineering Manager: proposal, inputs/version, controller validation, accepted/
  rejected decision and reason;
- incidents/operations: dead letters, ambiguity, stale leases, reconciliation,
  emergency events and runbooks;
- policy/budgets/model routing and capability rollout history;
- approvals/exceptions, added only after immutable challenge semantics exist;
- health/version/lag, backup status and deployment compatibility.

Do not expose prompt steering, raw OMP approval/question dialogs, a generic tool
call, provider settings, arbitrary file browser, workspace opener, Git operation
or PTY in Fleet mode. This does not prohibit ordinary full local OMP Chat or
revision-bound replies through the separately qualified Remote Workbench.
Existing Chat components may be reused visually only.

A future Take Over feature is out of initial scope. If ever added, it must first
durably pause and fence the run, issue an expiring intervention lease, constrain
tools, audit every action, create a new candidate, and force deterministic
verification plus a fresh independent audit before resumption.

COMMAND AND EMERGENCY SEMANTICS

Ordinary commands may eventually include:

- pause new claims;
- drain active work;
- cancel a run/stage at a safe boundary;
- retry as a new attempt;
- block or quarantine;
- reconcile an ambiguous operation;
- reprioritize within policy;
- decide an immutable approval/exception challenge;
- open the OWEB-7 owner flow for one typed intake clarification, exact-hash
  ratification or publication after NSI-6. These are WorkService owner actions,
  not generic Fleet commands, and do not enter through the Fleet gateway.

The UI submits intent and displays actual progress; it never optimistically
claims the effect occurred.

An intake answer/ratification/publication is a product-authority action, not an
Engineering Manager or generic operator decision. Bind it to the exact intake/
work revision, question/contract/receipt hash, evidence view and authentication assurance. Any
relevant source/claim/rule/contract change invalidates the challenge. The
browser/gateway never calculates or uploads its own readiness result.

Emergency stop is distinct:

- the normal path durably increments a WorkService stop epoch;
- controller claims, transitions, broker dispatch, merge and closeout recheck
  the epoch/fence before effect;
- an independent restricted host/CLI break-glass path can terminate workers and
  block external effects when Fleet Manager or WorkService is unavailable, then
  records/reconciles an incident afterward;
- stop must be fast and idempotent and must not wait for a new step-up ceremony;
- resume requires owner capability, recent high assurance, reason, exact scope
  and review of ambiguous effects.

APPROVALS, POLICY AND BUDGETS

Do not reuse OMP's generic `confirmed: boolean` interaction as fleet approval.
Fleet approvals are immutable, expiring, single-use challenges bound to exact
work/revision, plan, candidate/diff, receipts, policy, requested action and
challenge hash. Any relevant mutation invalidates them.

Present semantic policy diffs, budget/concurrency changes, role-to-model and
fallback routes, risk ceilings and promotion capability changes. Consequential
mutations require server-enforced capability, recent authentication assurance,
expected revisions, reason and audit.

REUSE AND CURRENT-APP BOUNDARIES

Reuse where safe:

- React design system, layouts and accessible components;
- normalized transcript/tool/evidence presentation;
- replay/deduplication lessons;
- bounded rendering, path/security and test patterns;
- generated TypeScript contracts and deterministic fixtures.

Do not reuse as Fleet authority:

- the shared bearer token or `?token=` WebSocket authentication;
- a missing/loose Origin policy;
- global event broadcast;
- workspace/file/provider/Git/PTY/session-worker endpoints;
- browser-configurable daemon URL;
- local Chat SQLite or OMP JSONL;
- current worker process environment or direct OMP supervision.

Rebaseline omp-webui against the live OMP version before sharing protocol types.
Record current local-Chat defects such as cross-session broadcast, worker
resume/version drift, environment leakage or nonportable tests if reproduced,
but do not turn unrelated Chat maintenance into Fleet authority work. Create
separate maintenance items only when required for a reused component.

REQUIRED PROGRAM CHILDREN

Publish exactly one parent and these children unless the crosswalk proves a
capability is already owned. Link backend dependencies to the corresponding
Fleet/WorkService child rather than duplicating them.

WFM-1 — Fleet-supervisory authority delta, threat model and operator UX

Deliver:
- consume and freeze the current OWEB-1/2 product charter, trust surfaces and
  compatibility contract; do not create a second OMP Web charter;
- Fleet-supervisory authority/data-flow delta and separate Fleet deployment
  boundary;
- Fleet-specific threat model and action-risk taxonomy;
- owner/observer capability model extensible to operator/approver;
- multi-repository, work, run, stage, attempt, agent, operation and incident
  information architecture, including the separate portfolio DAG, lifecycle
  state machine, per-attempt computation DAG and resource constraints;
- operator journeys, empty/degraded/stale/ambiguous states and non-goals;
- integration/deep-link journey to the separate OWEB-7 Work/Intake owner flow,
  plus read-only visibility of resulting readiness/invalidation;
- sanitization/evidence policy;
- Fleet rollout gates and compatibility constraints against OWEB-2;
- live OMP/WebUI version rebaseline.

May start after OWEB-1/2, NSI-6 and FLEET-1 contracts are available.

WFM-2 — Isolated Fleet deployment and process authority

Create a separate Fleet web entry point, build/deployment and least-privileged
gateway process/origin. Acceptance proves Fleet deployment cannot:
- start or steer OMP workers;
- open arbitrary workspaces or host files;
- invoke Git directly;
- read OMP homes, transcripts or local Chat SQLite;
- manage provider credentials;
- start a shell/terminal;
- connect directly to PostgreSQL.

Depends on: WFM-1.

WFM-3 — Versioned consumer contracts and deterministic fixtures

Define and generate contracts for:
- snapshots, pagination and `as_of_cursor`;
- work and dependencies;
- IntakeSnapshot, typed claim/evidence/decision/conflict/gap projections,
  IntakeContract, IntakeReadinessAssessment, RatificationReceipt,
  RatifiedFormalBinding, positive IntakeReadinessReceipt,
  IntakePublicationReceipt, published state and
  currentness/invalidation reasons;
- runs/stages/attempts/agents and model-resolution/cost data;
- ExecutionGraphManifest, GraphEpoch, NodeSpec/NodeResult, ArtifactEdge,
  JoinPolicy, ResourceClaim and node-attempt projections;
- TaskRisk, ContextManifest, RunManifest, EvidenceManifest, VerificationReceipt,
  AuditResult, receipts and sanitized artifacts;
- health/incidents;
- policies, budgets and approvals;
- `allowed_actions`, commands, operations and typed errors;
- durable SSE envelope/cursor;
- API/feature version negotiation.

Build hostile, enormous, stale, partial and degraded fixtures plus
consumer-driven tests. Include forged PASS text, unknown schema versions,
mismatched candidate/manifest/evidence hashes, dangling artifact references and
enormous typed results. Include forged owner claims/ratification/readiness, an
unpublished receipt, stale contract/rule/source hashes and a solver result presented beyond its
formalized scope. Canonical Markdown is a rendered view, never authority.
Reconcile/freeze against live WorkService; do not invent a second backend.

Depends on: NSI-6, WFM-1 and FLEET-1. May proceed in parallel with WFM-2.

WFM-4 — Remote identity, sessions, authorization and browser security

Deliver the provider-neutral BFF/session/capability model above, including Host/
Origin/CSRF enforcement, session revocation, step-up abstraction, service
identity, rate limits, headers/CSP and immutable audit propagation. Test every
route, artifact and SSE subscription for cross-principal/resource access, stale
session, CSRF, replay and revocation.

Depends on: WFM-1 and WFM-2.

WFM-5 — Fixture-driven read-only Fleet experience

Build the safety strip, exception-first overview, dependency explorer, run/stage
timeline, immutable execution-graph and join views, agent/EM views,
intake/readiness/ratification, receipts/evidence, incident and policy/budget
read views against WFM-3 fixtures.
Meet responsive accessibility and bounded hostile-content rendering
requirements.

Fixtures and live projections must represent K3 fresh-only/no-resume state,
authenticated context tier and provider quota/rate-limit pressure without
exposing credentials or raw reasoning.

Depends on: WFM-2 and WFM-3.

WFM-6 — WorkService projections, artifacts and durable event stream

Link to or add only proven backend gaps for:
- scoped FleetRead projections;
- scoped intake/claim/provenance/question/contract/assessment/ratification/
  positive-readiness/published projections and their durable invalidation
  events;
- graph/node/join/resource-wait projections bound to graph epoch and candidate;
- sanitized/content-addressed artifact retrieval;
- snapshot plus `as_of_cursor`;
- durable SSE replay, duplicate/gap/reconnect/backpressure behavior;
- authorization and revocation per projection/artifact/subscription;
- service/API version negotiation.

Depends on: SQL-0, NSI-6, FLEET-3, FLEET-7, WFM-3 and WFM-4.

WFM-7 — Live read-only Fleet integration

Connect WFM-5 to live WFM-6/controller evidence. Show actual lifecycle, risk
route, admitted intake claims, owner decisions, current contract/readiness
identity, unresolved gaps/conflicts, compiled-context provenance,
requested/resolved model/fallback,
containment, leases/fencing, exact git identities, validated typed verification/
audit/CI receipts, frozen execution graph, missing/failed/stale join inputs,
resource waits and EM proposal versus controller decision. No agent steering,
topology editing or fleet mutation. Unknown or inconsistent schemas fail closed
rather than falling back to persuasive prose.

This is the first remotely deployable **Fleet** milestone and remains
private-network only. Restricted remote session access may have shipped earlier
through OWEB-5/6 and cannot be used to bypass this Fleet boundary.

Depends on: WFM-5, WFM-6 and live controller event/artifact contracts.

WFM-8 — Asynchronous command plane and ordinary operator controls

Add typed pause/drain/cancel/retry/block/quarantine/reconcile controls only where
WorkService/controller handlers already exist. Enforce idempotency, expected
revision/policy/manifest, reason, server actor and immutable request hash. Show
operation state and ambiguous reconciliation honestly. Never infer success from
an accepted HTTP response.

Depends on: WFM-4, WFM-6, WFM-7 and the corresponding Fleet command handlers.

WFM-9 — Emergency stop and independent break-glass

Add the stop-epoch UI and status plus the separately deployed restricted host/
CLI path described above. Exercise stop/restart/reconcile at every fleet stage
and external-effect boundary. Resume is separately authorized and audited.

Depends on: WFM-8 and Fleet stop/fencing semantics.

WFM-10 — Fleet approvals, policies, budgets and model routing

Deliver immutable Fleet challenge queues, semantic diffs, budgets/concurrency,
role-to-model/fallback policy and rollout capability activation with recent-auth
and mutation invalidation. Typed intake answers, exact-hash ratification and
publication are owned by OWEB-7 after NSI-6; this surface may reuse their
generated projection but may not reimplement it. Require step-up, current
revision, deciding evidence and immutable receipts. The WebUI, gateway and
Engineering Manager cannot admit claims or mint readiness. Reuse existing
dialogs only as visual components.

Depends on: WFM-4, WFM-6, WFM-8 and the Fleet policy/approval engine.

WFM-11 — GitHub, CI, merge and closeout views/controls

Expose exact-SHA PR/check/integration state, broker ambiguity/reconciliation,
stale receipt rejection and guarded closeout. No browser/gateway GitHub
credential and no generic Git tool. Controls exist only for controller-owned
typed operations.

Depends on: WFM-7, WFM-8, WFM-10 and FLEET-12.

WFM-12 — Operations, adversarial hardening and staged rollout

Deliver:
- health, leases, locks, dead letters, lag, costs, alerts and audit;
- private-network deployment, non-root isolation and service auth;
- backup/restore and event-cursor recovery drills;
- load/backpressure, browser/gateway upgrade and version-skew tests;
- hostile content, authz, CSRF, session theft/revocation and dependency tests;
- security/incident runbooks and capability rollback;
- public-exposure decision gate;
- proof Fleet continues safely with WebUI offline.

Depends on: WFM-9, WFM-10 and WFM-11. Unattended activation also requires
FLEET-15.

DEPENDENCY GRAPH

OWEB-1 + OWEB-2 + NSI-6 + FLEET-1 -> WFM-1
WFM-1 + NSI-6 + FLEET-1 -> WFM-3
WFM-1 -> WFM-2
WFM-1 + WFM-2 -> WFM-4
WFM-2 + WFM-3 -> WFM-5
SQL-0 + NSI-6 + FLEET-3 + FLEET-7 + WFM-3 + WFM-4 -> WFM-6
WFM-5 + WFM-6 + FLEET-8/controller contracts -> WFM-7
WFM-4 + WFM-6 + WFM-7 + Fleet commands -> WFM-8
WFM-8 + Fleet stop/fencing -> WFM-9
WFM-4 + WFM-6 + WFM-8 + Fleet policy -> WFM-10
WFM-7 + WFM-8 + WFM-10 + FLEET-12 -> WFM-11
WFM-9 + WFM-10 + WFM-11 -> WFM-12
FLEET-15 + WFM-12 -> unattended Fleet Manager activation
OWEB-4 + WFM-3 + WFM-5 -> shared-shell Fleet fixtures
OWEB-8 + WFM-7 + FLEET-8 -> shared-shell live read-only Fleet

DEPLOYMENT GATES

1. FIXTURE_ONLY — WFM-1 through WFM-5. No live authority.
2. PRIVATE_READ_ONLY — WFM-6 and WFM-7.
3. SINGLE_REPOSITORY_OPERATOR_CANARY — WFM-8 and WFM-9.
4. POLICY_AND_APPROVAL_CANARY — WFM-10.
5. GITHUB_MUTATION_CANARY — WFM-11 plus Fleet qualification.
6. UNATTENDED_OPERATION — WFM-12 and FLEET-15.
7. PUBLIC_EXPOSURE — separate threat/evidence decision after private operation;
   never implied by unattended fleet readiness.

MANDATORY TEST CASES

- cross-principal, cross-repository and cross-resource reads/commands/events;
- observer/operator/Engineering Manager attempting an owner intake answer,
  waiver or ratification; forged/stale contract and readiness displays;
- intake question or ratification submitted after source, claim, ontology, rule
  or contract revision changed;
- missing/forged Origin, CSRF, cookie fixation/theft, session rotation/revocation;
- stale `allowed_actions`, stale revision, repeated idempotency key with same and
  different body, double click and lost command response;
- SSE duplicate/gap/out-of-order/reconnect/backpressure and revoked session;
- XSS via work/model/Markdown/ANSI/diff/log/HTML/SVG/filename/link/artifact;
- enormous payload, decompression/rendering bomb and malicious download;
- gateway restart during accepted operation and version skew during deployment;
- WorkService/controller/GitHub/DB outage and stale UI cache;
- emergency stop while gateway is unavailable and resume after ambiguity;
- policy/approval bound to stale plan/SHA/receipt;
- missing/duplicated graph inputs, stale graph epoch, invalidated descendants,
  attempted in-flight topology mutation and ambiguous join completion;
- proof the Fleet origin cannot call Chat worker/file/provider/Git/PTY routes;
- proof controller operation is unaffected when all Fleet UI/gateway processes
  are terminated.

PUBLICATION REQUIREMENTS

For the parent and each child publish stable key/idempotency key, repository
owner, problem, outcome, scope/non-goals, backend dependencies, AC IDs,
threat/risk class, deterministic verification, rollout/rollback/observability,
stop conditions and unresolved owner decisions. Return exact created IDs and
edges plus a manifest reconciliation. On partial/ambiguous publication, read by
idempotency key before retrying.

EXPLICIT NON-GOALS

- no shared remotely exposed Fleet/Chat daemon, credential or origin;
- no PostgreSQL, OMP RPC, worktree, shell, provider or GitHub access from the
  Fleet browser/gateway;
- no Fleet authority in omp-webui SQLite, JSONL, WebSocket or local storage;
- no controller, scheduler, GitHub broker or worker supervision in the gateway;
- no arbitrary graph editor, live sibling-agent state channel or direct node
  completion control in the browser;
- no generic prompt steering, approval forwarding, tool execution, workspace,
  file, Git, provider or PTY feature in Fleet mode; this does not remove
  qualified local OMP Web features or bounded Remote Workbench replies;
- no reimplementation of WorkService/Fleet backend work;
- no optimistic state transition based on UI state or event delivery;
- no home-grown enterprise IAM or passkey platform before requirements exist;
- no public Internet exposure, remote takeover, deployment/release control or
  unattended merge in the first milestones.

END-OF-INTAKE OUTPUT

Return:
1. live repository/service versions and current-state crosswalk;
2. threat model and corrected Fleet/Chat authority boundary;
3. material questions and owner answers;
4. ratified API/security/operator contracts;
5. exact parent/child manifest and cross-program DAG;
6. publication result or precise BLOCKED reason;
7. the safe parallel starting set, normally WFM-1, WFM-2, WFM-3, WFM-4 and
   WFM-5 subject to their internal dependencies;
8. the first Fleet deployment target, which must be PRIVATE_READ_ONLY WFM-7.
```
