# Neuro-symbolic intake technical contract

Status: implementation baseline for `NSI-1` through `NSI-6` after `SQL-0:
PROVEN`. The program intake in
`02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md` remains the owner-ratification
entry point. This document supplies concrete contracts; it does not authorize
implementation or override repository evidence discovered during intake.

The optional `NSI-E1` through `NSI-E4` **Explore alternatives** extension is
specified in `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`. It is additive,
advisory and separately promoted; base intake publication and Fleet eligibility
must not depend on it.

## 1. Claim boundary

This design makes only the following guarantee:

> For one frozen source snapshot, a versioned deterministic engine can establish
> whether an owner-ratified typed contract satisfies a named ontology and rule
> bundle, and can return traceable gaps, conflicts, witnesses or unknowns.

It does not establish universal requirements completeness or prove that a
formalization matches the owner's meaning. The owner ratifies that mapping.

## 2. Authority and data flow

```text
owner/repository/tool artifacts
            |
            v
Fable candidate extraction ---- optional fresh K3 alternate proposal
            |                                  |
            +---------------+------------------+
                            v
               WorkService proposal admission
                            |
                            v
          versioned ontology + code-owned rule evaluator
                            |
             +--------------+--------------+
             |                             |
             v                             v
       gaps/conflicts              selective formal adapter
             |                      (bounded, non-authoritative)
             +--------------+--------------+
                            v
                one typed owner question at a time
                            |
                 +----------+----------+
                 |                     |
                 v                     v
          answer directly       optional owner-confirmed
                                  bounded exploration
                 |                     |
                 +----------+----------+
                            v
                one owner decision at a time
                            |
                            v
        typed acceptance criteria + semantic review
                            |
                            v
        machine assessment: ready for ratification
                            |
                            v
              owner ratifies exact contract hash
                            |
                            v
 WorkService revalidates, binds verified formal properties
              and issues positive receipt
                            |
                            v
              publishIntake -> published state
                            |
                            v
         Markdown/planner/Fleet projections and events
```

Authority table:

| Fact or action | Authority |
| --- | --- |
| Product intent and semantic interpretation | Owner decision/ratification |
| Repository state | Exact tool receipt bound to commit/artifact |
| Candidate extraction or alternate interpretation | Model proposal only |
| Exploration candidate, comparison, watch-out or recommendation | Model proposal only; deterministic code may mark explicit constraint conflicts |
| Exploration start/cancel/deepen budget | Authenticated owner under server policy and hard limits |
| Ontology, rules, schemas and formal compiler | Reviewed source/versioned release |
| Admission, derivation, conflict, coverage and readiness | WorkService plus deterministic engine |
| Formal satisfiability/witness/counterexample | Named solver relative to exact compiled input |
| Lifecycle mutation and publication | WorkService typed command under actor policy |
| Human-readable blueprint | Deterministic renderer; never canonical authority |

## 3. Stable identities and hashing

Use repository-standard UUID/content-hash facilities after inspection. The
semantic contract requires:

- immutable IDs for source artifacts, evidence spans, claims, decisions,
  derivations, questions, clauses, criteria and receipts;
- monotonic Work/intake revisions for optimistic concurrency;
- canonical serialization before hashing; JSON property order or Markdown
  whitespace must not change semantic identity;
- content hashes for source bytes, normalized claim payloads, contracts,
  ontology/rule bundles, compiled formal inputs and result artifacts;
- separate `contractHash`, `snapshotHash`, `derivationHash` and renderer hash;
- `contractHash` over the canonical transitive semantic closure, never a list of
  mutable IDs. The closure contains immutable `{id, contentHash}` references for
  every admitted claim, clause/formalization, acceptance criterion, owner
  decision or waiver, assumption and non-goal reachable from the contract;
- evidence identity and semantic-mapping hashes in that closure wherever they
  affect meaning. Any semantic edit mints a new immutable object/hash and a new
  contract hash; display order, timestamps and renderer fields are excluded;
- no hash that includes nondeterministic timestamps, database IDs assigned
  after content construction or vendor-specific prose.
- exploration policy, input manifest, selected frames, prompts, invocations,
  branches, candidates, deterministic screenings, synthesis and usage each have
  separate canonical identities. Exploration is not added to `IntakeContract`.
  When the owner uses it, a separate `OwnerDecisionExplorationLink` may retain
  exact non-authoritative provenance outside `OwnerDecision.contentHash` and
  semantic closure; the exact confirmed owner answer and subsequently admitted
  claims remain the semantic authority.
- post-publication planning exploration is outside semantic closure,
  ratification and readiness hashes and is discarded from planner context when
  its contract/publication/snapshot binding is stale.

Canonicalization and hash algorithms are selected and versioned by `NSI-1`
after inspecting current WorkService conventions. Cross-version hash changes
must produce a new schema/canonicalization version, never silent drift.

## 4. Normative TypeScript domain

The exact module names may follow repository conventions. Field semantics and
authority boundaries are normative.

Ontology version one preserves the current eleven intake dimensions rather than
inventing a universal ontology:

```ts
type IntakeCategory =
  | "functional_scope_and_behavior"
  | "domain_and_data_model"
  | "interaction_and_ux_flow"
  | "non_functional_qualities"
  | "integrations_and_external_dependencies"
  | "edge_cases_and_failure_handling"
  | "constraints_and_tradeoffs"
  | "terminology"
  | "completion_signals"
  | "placeholders_and_ambiguities"
  | "scope_boundaries";
```

Live NSI-1 must map these labels to the exact current skill wording and assign
stable IDs without changing meaning silently.

```ts
type IntakeId = string;
type ClaimId = string;
type RuleId = string;
type ArtifactId = string;
type DecisionId = string;
type ContractHash = string;

interface IntakeSnapshot {
  workItemId: string;
  workRevision: number;
  ownerRequestArtifactId: ArtifactId;
  repositoryCommits: Record<string, string>;
  sourceArtifactHashes: string[];
  workServiceApiVersion: string;
  workServiceSchemaVersion: string;
  ontologyVersion: string;
  ruleBundleHash: string;
  engineVersion: string;
  extractionRunId: string;
  snapshotHash: string;
}

type IntakeRunState =
  | "collecting"
  | "reasoning"
  | "needs_spec"
  | "conflicted"
  | "ready_for_ratification"
  | "ratified"
  | "published"
  | "stale"
  | "invalid"
  | "superseded";

interface IntakeRun {
  id: IntakeId;
  workItemId: string;
  revision: number;
  state: IntakeRunState;
  snapshotHash: string;
  currentContractHash?: ContractHash;
  createdBy: ActorRef;
  createdAt: string;
  supersedesIntakeId?: IntakeId;
}

interface ActorRef {
  id: string;
  kind: "owner" | "service" | "model" | "tool" | "rule_engine";
}

interface EntityRef {
  id: string;
  type: string;
}

type TypedScalar = string | number | boolean | null;
interface TypedValue {
  type: string;
  value: TypedScalar | TypedScalar[] | Record<string, unknown>;
}

interface EvidenceArtifact {
  id: ArtifactId;
  kind:
    | "owner_request"
    | "owner_answer"
    | "policy_bundle"
    | "repository_file"
    | "tool_output"
    | "external_source"
    | "model_output"
    | "solver_input"
    | "solver_output";
  sha256: string;
  mediaType: string;
  byteLength: number;
  repositoryCommit?: string;
  uri: string;
  generatedBy?: ActorRef;
}

interface EvidenceSpan {
  id: string;
  artifactId: ArtifactId;
  artifactSha256: string;
  locator: {
    repositoryCommit?: string;
    path?: string;
    lineRange?: [number, number];
    byteRange?: [number, number];
    jsonPointer?: string;
    transcriptRange?: [number, number];
  };
  spanHash: string;
  exactTextHash?: string;
}

type ClaimOrigin =
  | "owner_statement"
  | "policy_rule"
  | "repository_observation"
  | "tool_receipt"
  | "model_proposal"
  | "rule_derivation";

type ClaimState = "proposed" | "admitted" | "rejected" | "superseded";
type ClaimModality =
  | "observed"
  | "desired"
  | "required"
  | "prohibited"
  | "possible"
  | "unknown";

interface IntakeClaim {
  id: ClaimId;
  intakeId: IntakeId;
  subject: EntityRef;
  predicate: string;
  object: TypedValue | EntityRef;
  polarity: "positive" | "negative";
  modality: ClaimModality;
  origin: ClaimOrigin;
  state: ClaimState;
  scope?: EntityRef;
  evidenceSpanIds: string[];
  authorityActor?: ActorRef;
  derivationId?: string;
  supersedesClaimIds: ClaimId[];
  revision: number;
  contentHash: string;
}

interface PredicateDefinition {
  id: string;
  subjectTypes: string[];
  objectTypes: string[];
  cardinality?: { min?: number; max?: number };
  exclusiveGroup?: string;
  transitive?: boolean;
  ownerAuthorityRequired?: boolean;
  repositoryEvidenceRequired?: boolean;
}

interface RequirementDimensionDefinition {
  id: string;
  title: string;
  appliesWhenRuleIds: RuleId[];
  requiredPremiseIds: string[];
  materiality:
    | "product_semantics"
    | "scope"
    | "safety"
    | "security"
    | "data"
    | "compatibility"
    | "dependency";
  waiverPolicy: "never" | "owner_with_reason";
}

interface IntakeOntology {
  id: string;
  version: string;
  categoryIds: string[];
  entityTypes: string[];
  predicates: PredicateDefinition[];
  dimensions: RequirementDimensionDefinition[];
  canonicalHash: string;
}

interface DerivationReceipt {
  id: string;
  outputClaimId: ClaimId;
  inputClaimIds: ClaimId[];
  ruleId: RuleId;
  ruleBundleHash: string;
  engineVersion: string;
  evaluatedSnapshotHash: string;
  evaluatedAt: string;
  contentHash: string;
}

interface Gap {
  id: string;
  dimensionId: string;
  ruleId: RuleId;
  premiseId: string;
  requiredAuthority: "owner" | "repository" | "tool" | "policy";
  materiality: RequirementDimensionDefinition["materiality"];
  toolDiscoverable: boolean;
  downstreamRuleIds: RuleId[];
  supportingClaimIds: ClaimId[];
  contentHash: string;
}

interface Conflict {
  id: string;
  ruleId: RuleId;
  claimIds: ClaimId[];
  kind:
    | "polarity"
    | "cardinality"
    | "exclusive_value"
    | "authority"
    | "formal_unsat"
    | "acceptance_non_goal";
  evidenceSpanIds: string[];
  formalResultId?: string;
  contentHash: string;
}

interface OwnerDecision {
  id: DecisionId;
  intakeId: IntakeId;
  questionId: string;
  actor: ActorRef & { kind: "owner" };
  exactAnswerArtifactId: ArtifactId;
  exactAnswerArtifactHash: string;
  admittedClaimIds: ClaimId[];
  rejectedInterpretationClaimIds: ClaimId[];
  expectedPriorRevision: number;
  revision: number;
  contentHash: string;
  decidedAt: string;
}

interface ClarificationQuestion {
  id: string;
  intakeId: IntakeId;
  blockedPremises: Array<{ ruleId: RuleId; premiseId: string }>;
  gapIds: string[];
  materiality: RequirementDimensionDefinition["materiality"];
  expectedAnswerSchema: Record<string, unknown>;
  interpretationOptions?: Array<{
    id: string;
    label: string;
    consequence: string;
    proposedClaimIds: ClaimId[];
  }>;
  evidenceSpanIds: string[];
  renderedText: string;
  status: "queued" | "asked" | "answered" | "superseded";
  contentHash: string;
}

type ExecutableFormalProfile = "smt" | "temporal" | "runtime_policy";

type FormalProfile =
  | "structural"
  | "test_oracle"
  | "semantic_only"
  | ExecutableFormalProfile;

interface RequirementClause {
  id: string;
  intakeId: IntakeId;
  originalEvidenceSpanIds: string[];
  normalizedText: string;
  kind:
    | "goal"
    | "invariant"
    | "event_response"
    | "state_constraint"
    | "data_constraint"
    | "assumption"
    | "non_goal"
    | "quality";
  sourceClaimIds: ClaimId[];
  subject?: EntityRef;
  scope?: EntityRef;
  trigger?: Record<string, unknown>;
  guard?: Record<string, unknown>;
  response?: Record<string, unknown>;
  timing?: Record<string, unknown>;
  exceptionClaimIds: ClaimId[];
  formalProfile: FormalProfile;
  semanticRatification: "pending" | "accepted" | "rejected";
  revision: number;
  contentHash: string;
}

interface AcceptanceCriterion {
  id: string;
  intakeId: IntakeId;
  statement: string;
  sourceClaimIds: ClaimId[];
  observableOutcome: string;
  oracle:
    | "automated_test"
    | "static_check"
    | "manual_inspection"
    | "external_receipt";
  negativeOrBoundaryCases: string[];
  waiverDecisionId?: DecisionId;
  revision: number;
  contentHash: string;
}

interface Formalization {
  id: string;
  intakeId: IntakeId;
  propertyId: string;
  sourceClauseIds: string[];
  profile: ExecutableFormalProfile;
  semanticMappingEvidenceSpanIds: string[];
  typedIrArtifactId: ArtifactId;
  typedIrArtifactHash: string;
  assumptions: string[];
  bounds: Record<string, unknown>;
  revision: number;
  contentHash: string;
}

type FormalCheckVerdict =
  | "HOLDS_RELATIVE_TO_DRAFT_FORMAL_MODEL"
  | "COUNTEREXAMPLE"
  | "UNSAT"
  | "UNKNOWN"
  | "NOT_FORMALIZABLE"
  | "NEEDS_OWNER_DECISION"
  | "SOLVER_ERROR";

interface FormalCheckResult {
  id: string;
  propertyId: string;
  formalizationId: string;
  profile: ExecutableFormalProfile;
  verdict: FormalCheckVerdict;
  formalizationHash: string;
  compilerId: string;
  compilerVersion: string;
  solverId?: string;
  solverVersion?: string;
  inputArtifactId: ArtifactId;
  inputHash: string;
  outputArtifactId?: ArtifactId;
  claimIds: ClaimId[];
  witnessEvidenceSpanIds: string[];
  conflictClaimIds: ClaimId[];
  timeoutMs: number;
  resourceReceiptId: string;
  contentHash: string;
}

interface RatifiedFormalBinding {
  id: string;
  propertyId: string;
  contractHash: ContractHash;
  formalizationId: string;
  formalizationHash: string;
  draftFormalCheckResultId: string;
  draftFormalCheckResultHash: string;
  ratificationReceiptId: string;
  result: "VERIFIED_RELATIVE_TO_RATIFIED_MODEL";
  issuedAt: string;
  contentHash: string;
}

interface ContentRef<
  TKind extends
    | "claim"
    | "clause"
    | "formalization"
    | "acceptance_criterion"
    | "owner_decision"
    | "assumption"
    | "non_goal"
    | "unresolved_gap",
> {
  kind: TKind;
  id: string;
  contentHash: string;
}

interface IntakeContract {
  intakeId: IntakeId;
  intakeRevision: number;
  snapshotHash: string;
  ontologyVersion: string;
  ruleBundleHash: string;
  semanticClosure: Array<
    ContentRef<
      | "claim"
      | "clause"
      | "formalization"
      | "acceptance_criterion"
      | "owner_decision"
      | "assumption"
      | "non_goal"
      | "unresolved_gap"
    >
  >;
  semanticClosureHash: string;
  contractHash: ContractHash;
}

interface RatificationReceipt {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  contractHash: ContractHash;
  semanticClosureHash: string;
  assessmentHash: string;
  ownerActor: ActorRef & { kind: "owner" };
  exactConfirmationArtifactId: ArtifactId;
  exactConfirmationArtifactHash: string;
  ratifiedAt: string;
}

type IntakeAssessmentVerdict =
  | "READY_FOR_RATIFICATION"
  | "NEEDS_SPEC"
  | "CONFLICTED"
  | "STALE"
  | "INVALID";

interface IntakeReadinessAssessmentBase {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  snapshotHash: string;
  ontologyVersion: string;
  ruleBundleHash: string;
  engineVersion: string;
  satisfiedRuleIds: RuleId[];
  missingGaps: Array<{ id: string; contentHash: string }>;
  conflicts: Array<{ id: string; contentHash: string }>;
  formalResults: Array<{ id: string; contentHash: string }>;
  derivationHash: string;
  assessmentHash: string;
  issuedAt: string;
}

type IntakeReadinessAssessment =
  | (IntakeReadinessAssessmentBase & {
      verdict: "READY_FOR_RATIFICATION";
      contractHash: ContractHash;
      semanticClosureHash: string;
    })
  | (IntakeReadinessAssessmentBase & {
      verdict: Exclude<IntakeAssessmentVerdict, "READY_FOR_RATIFICATION">;
      contractHash?: ContractHash;
      semanticClosureHash?: string;
    });

interface IntakeReadinessReceipt {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  contractHash: ContractHash;
  semanticClosureHash: string;
  snapshotHash: string;
  ontologyVersion: string;
  ruleBundleHash: string;
  engineVersion: string;
  assessmentHash: string;
  ratificationReceiptId: string;
  result: "ELIGIBLE_FOR_PUBLICATION";
  satisfiedRuleIds: RuleId[];
  requiredFormalPropertyIds: string[];
  ratifiedFormalBindings: Array<{
    id: string;
    contentHash: string;
  }>;
  semanticOnlyClauseIds: string[];
  derivationHash: string;
  issuedAt: string;
}

interface IntakePublicationReceipt {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  contractHash: ContractHash;
  snapshotHash: string;
  readinessReceiptId: string;
  readinessReceiptHash: string;
  publicationPolicyHash: string;
  publishedBy: ActorRef & { kind: "owner" };
  publishedAt: string;
  contentHash: string;
}
```

The optional exploration domain—`ExplorationPolicy`, eligibility,
offer/authorization, `ExplorationInputManifest`, frame registry/selection,
durable budget policy/ledger/reservation, provider data-handling/egress/ingress,
authorization-consumption, stage-attempt/invocation-intent/reconciliation and
run/branch/deepening records, candidate/option/assertion screening, synthesis,
usage, `OwnerDecisionExplorationLink` provenance and
`PlanningExplorationArtifact`—is normative in
`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`. Exploration provenance is a
separate append-only audit link; it is excluded from `OwnerDecision.contentHash`,
`semanticClosureHash` and `contractHash`. The candidate body, model rationale,
unselected options and post-publication planning artifact do not become new
semantic-closure kinds.

`READY_FOR_RATIFICATION` is a pre-ratification assessment only. It is never a
readiness receipt and grants no publication or downstream capability. After
owner ratification, WorkService revalidates the exact hash-bound bundle and may
issue the positive-only `IntakeReadinessReceipt`. Failed revalidation creates a
new assessment/state transition, never a negative readiness receipt. Only the
positive assessment branch requires a complete contract/semantic-closure hash;
failure branches may identify a partial preview but cannot be ratified.

`semanticClosure` is sorted by `(kind, id, contentHash)` before hashing. Every
referenced body is immutable and content-addressed. Object content hashes cover
all semantic and authority-bearing fields, including exact evidence/artifact
hashes and server-derived owner identity where relevant; they exclude display
ordering, audit timestamps and renderer data.

`Formalization` bodies and formal results are immutable. The contract closure
contains every in-scope formalization content hash, so the owner ratifies the
exact semantic-to-formal mapping—not a profile label or replaceable ID.
`HOLDS_RELATIVE_TO_DRAFT_FORMAL_MODEL` is a pre-ratification result only. After
the owner ratifies that exact mapping, WorkService may create
an immutable per-property `RatifiedFormalBinding` with
`VERIFIED_RELATIVE_TO_RATIFIED_MODEL`. Properties that are semantic-only or
legally `NOT_FORMALIZABLE` get no such binding and remain explicit on the
governance receipt. The overall receipt says `ELIGIBLE_FOR_PUBLICATION`; it does
not claim that the entire contract was formally proved.

## 5. WorkService persistence domains

Use PostgreSQL relational tables for authority and joins. JSONB is appropriate
only for schema-versioned typed payloads whose fields are validated at the API
boundary. Do not introduce a generic graph database.

Minimum logical domains:

1. `intake_runs` and immutable snapshot revisions.
2. `intake_entities` and predicate/type registries.
3. `intake_claims`, claim supersession and claim/evidence joins.
4. `evidence_artifacts` and `evidence_spans` using the existing artifact seam.
5. `owner_decisions` and exact answer artifacts.
6. `derivations`, rule identities and input/output claim joins.
7. `intake_gaps`, `intake_conflicts` and resolution links.
8. `clarification_questions` and answer/revision links.
9. `requirement_clauses`, `acceptance_criteria` and trace links.
10. `formal_checks`, ratified formal bindings and content-addressed input/
    output/resource receipts.
11. `intake_contracts`, readiness assessments, ratification, positive readiness
    receipts and publication receipts.
12. Append-only lifecycle/events plus deterministic human projections.
13. Optional exploration offers/authorizations, manifests, frame selections,
    durable runs/stage attempts, branch artifacts, candidates/screenings,
    syntheses, planning artifacts, reservations and usage receipts. These are
    proposal/execution domains, never a second claim or readiness ledger.

Database-enforced invariants should include referential integrity, uniqueness
of current revision where applicable, immutable receipt bodies, same-run
bindings, valid supersession targets and owner identity on ratification. Complex
readiness remains in the versioned service engine, not database triggers that
hide policy.

Claims, owner decisions, clauses, acceptance criteria and gaps referenced by a
contract are append-only immutable bodies. A change mints a new identity or
revision and content hash; WorkService must reject an attempt to update semantic
content behind an existing `{id, contentHash}` reference. A `policy_bundle`
artifact is the provenance source for `policy_rule` claims and policy-authority
gaps; policy is versioned source, not a caller-asserted actor.

## 6. Narrow API surface

Exact routes follow current WorkService conventions. Preserve these operation
semantics even if implemented as RPC methods rather than HTTP paths:

| Operation | Required behavior |
| --- | --- |
| `beginIntake` | Expected Work revision; freezes snapshot/rules; idempotent |
| `submitEvidence` | Stores artifact/span hashes; validates source binding |
| `submitClaimProposals` | Model/tool proposals only; schema and authority admission |
| `evaluateIntake` | Deterministic `IntakeReadinessAssessment` with gaps/conflicts/derivations |
| `nextClarification` | Returns one code-selected typed question or terminal status |
| `recordOwnerDecision` | Owner-authenticated, exact answer artifact, expected revision |
| `proposeAcceptanceCriteria` | Candidate criteria; never self-admitted owner intent |
| `validateAcceptanceCriteria` | Traceability, oracle, coverage and conflict results |
| `buildContractPreview` | Canonical contract plus deterministic human rendering |
| `ratifyContract` | Owner-only exact contract hash and expected revision |
| `bindRatifiedFormalResults` | Server-only binding of exact draft result/formalization hashes to the matching ratification; never creates a binding for semantic-only or unverified properties |
| `issueReadinessReceipt` | Post-ratification server revalidation; emits only the positive result and never trusts a caller verdict |
| `publishIntake` | Requires `ELIGIBLE_FOR_PUBLICATION`, a server-calculated current receipt, matching assessment/ratification and expected revision; atomically emits `IntakePublicationReceipt` and transitions to `published` |
| `getIntakeProjection` | Typed state plus renderer output and current event cursor |
| `supersedeIntake` | Creates new revision/run; preserves history and invalidates dependents |

Optional owner/client exploration operations are `getExplorationOffer`,
`requestIntakeExploration`, `cancelIntakeExploration`,
`getIntakeExplorationProjection`, `requestExplorationDeepening` and
`getCurrentPlanningExploration`. Controller-only fenced operations lease and
complete stage attempts, record invocations/screenings, finalize synthesis and
mark currentness. Their exact semantics are in `03B_...`; they use the same
mutation envelope and never expose a mutation API to a model.

Every mutation carries:

```ts
interface MutationEnvelope<T> {
  idempotencyKey: string;
  canonicalRequestHash: string;
  expectedRevision: number;
  payload: T;
}
```

Same key/same body replays the original result. Same key/different body is
rejected. Timeout/unknown outcome is reconciled with a read before retry.
The authenticated principal and capabilities come from server-controlled
request context and are written by WorkService into audit, decision and
ratification records. They are never accepted from the mutation body; a payload
field attempting to assert authoritative actor identity is rejected.

## 7. State machine and legal transitions

```text
collecting <------------------------------+
   |                                      |
   v                                      |
reasoning --missing--> needs_spec --------+
   |  \--conflict--> conflicted ----------+
   |  \--invalid-----------------------> invalid
   v
ready_for_ratification (current assessment) --owner rejects--> collecting
   |
   +--owner ratifies exact hash----------> ratified
                                              |
                                              +--post-ratification revalidation
                                                 + positive receipt
                                                 + publishIntake--> published

Any material source/rule/schema/contract change -> stale
stale -> new/superseding revision -> collecting
```

The interaction budget can stop a run in `needs_spec`. It cannot create the
`ready_for_ratification` transition. Renderer success is not a transition
precondition; typed contract and receipt validation is.

Exploration has an independent state machine. No exploration transition changes
`IntakeRunState`. A direct owner answer supersedes any active optional run, and
stale/partial/cancelled/failed exploration cannot block or advance intake.

## 8. Deterministic reasoning contract

The first engine is a small reviewed TypeScript rule evaluator plus graph
algorithms, not an LLM and not a universal logic platform.

Every rule must declare:

```ts
interface HarnessRule {
  id: RuleId;
  version: string;
  appliesToArchetypes: string[];
  requiredPredicateIds: string[];
  enforcement: "schema" | "database" | "reasoner" | "formal_adapter" | "owner";
  sourceDecisionId?: DecisionId;
  evaluationFixtureIds: string[];
}
```

Every evaluation returns reason IDs and claim/evidence references. Given the
same canonical snapshot and rule bundle it must produce the same semantic
result independent of claim insertion order or renderer layout.

Initial rule families:

- predicate subject/object type and namespace validity;
- cardinality, exactly-one, exclusivity and allowed values;
- transitive prerequisite closure, cycles and dangling references;
- archetype/dimension applicability;
- owner/repository/tool authority requirements;
- supported positive/negative claim conflict;
- required rollback, failure behavior, security boundary, compatibility or
  data-decision gaps when corresponding typed triggers exist;
- AC source traceability, observable oracle, non-goal conflict and admitted
  behavior coverage;
- current snapshot/rule/contract bindings.

Do not use closed-world negation for unknown intake facts. If a premise is not
supported, emit a gap or `unknown`; do not derive its negation.

## 9. Gap selection and question contract

The engine, not the language model, owns question necessity and priority:

1. Evaluate the readiness predicate.
2. Collect missing/conflicting premises.
3. Route repository/tool-authority premises to bounded investigation.
4. Group duplicates that represent one owner decision.
5. Rank remaining gaps by materiality, safety and downstream fan-out.
6. Return one `ClarificationQuestion` with reason/evidence IDs.
7. If deterministic policy finds the current owner question eligible, attach a
   no-model-call `ExplorationOffer`; never start usage-consuming work
   automatically.
8. Let Fable render neutral text and bounded options where truly exhaustive.
9. If the owner authorizes exploration, run the separately budgeted `03B`
   pipeline and return to this same question without resolving it.
10. Store the exact owner answer; confirm nontrivial interpretation.
11. Re-evaluate from typed state.

The question renderer must never omit the deciding evidence or consequence.
The service rejects an answer submitted for a superseded question/revision.

## 10. Formal-adapter interface

Formal methods are optional plugins beneath deterministic policy:

```ts
interface CompiledFormalInput {
  profile: ExecutableFormalProfile;
  formalizationId: string;
  formalizationHash: string;
  compilerId: string;
  compilerVersion: string;
  sourceClauseIds: string[];
  artifactId: ArtifactId;
  contentHash: string;
  assumptions: string[];
  bounds: Record<string, unknown>;
}

interface FormalAdapter {
  readonly id: string;
  readonly version: string;
  readonly profiles: ExecutableFormalProfile[];
  supports(
    formalization: Formalization,
    clauses: RequirementClause[],
  ): { supported: boolean; reasons: string[] };
  compile(
    formalization: Formalization,
    clauses: RequirementClause[],
    snapshot: IntakeSnapshot,
  ): CompiledFormalInput;
  execute(input: CompiledFormalInput, limits: SolverLimits): Promise<FormalCheckResult>;
}

interface SolverLimits {
  timeoutMs: number;
  memoryBytes: number;
  cpuMillis: number;
  network: "denied";
}
```

Adapters run with pinned binary/image/version and content-addressed I/O. A
reviewed deterministic compiler emits solver input; a model cannot supply a
shell command or executable solver program. The service preserves SAT witness,
counterexample, conflict core, `unknown`, timeout and stderr artifacts.
`structural` remains in the built-in reasoner, `test_oracle` remains in the
verification layer and `semantic_only` remains with owner/auditor judgment;
none can be routed into a formal adapter.

Promotion order:

1. Typed schemas/rules/graph algorithms.
2. Z3 only for demonstrated bounded hard constraints.
3. ASP only for demonstrated defaults/exceptions that explicit precedence
   cannot manage cleanly.
4. Temporal/model checking only for high-risk event/lifecycle models.

Unsupported clauses remain `NOT_FORMALIZABLE` and continue through owner and
semantic audit. No adapter is required for ordinary low-risk issues.

## 11. Model contracts

Fable-high candidate extractor output must be schema-valid proposals with exact
evidence references. It may say `unknown`; it cannot set admitted/ratified/
ready state.

Fresh K3 long-context use is conditional. When invoked, it receives a bounded
snapshot and returns one of:

- alternate candidate claims;
- materially divergent interpretations with source references;
- repository observations to verify with tools;
- proposed formal-profile assignments with reasons.

K3 output remains proposed. Agreement with Fable does not increase authority.
Disagreement becomes an ambiguity signal only when the resulting behavior
differs materially.

Question wording, acceptance wording and explanations are presentation-layer
model outputs. Their typed IDs and source bindings come from WorkService.

Optional exploration initially uses fresh Flash-medium generator branches, a
fresh Sol-high synthesizer and separately owner-requested fresh K3-256K-high
deepening, subject to `NSI-E4` qualification. Fable remains the owner-facing
interviewer; Web/CLI render typed options deterministically without another
model call. All roles receive brokered, immutable artifacts; they cannot admit
claims or mutate intake. Routes stay outside `cycleOrder`; the initial canary
has no automatic cross-model fallback, and later preauthorized fallbacks are
recorded new attempts. Numeric/model consensus is never authority.

## 12. Security and containment

- Intake models and formal workers have no SQL credential or generic lifecycle
  mutation tool.
- Provider credentials are brokered without exposure to repository processes.
- Solver workers are network-denied, resource-bounded and receive only compiled
  artifacts.
- Repository text cannot add system rules or change model/tool policy.
- Exact source quotes are data and may be redacted in projections according to
  policy without changing their stored content hash.
- Owner authentication/authorization is required for decisions, waivers and
  ratification; an Engineering Manager or Fleet agent is not an owner actor.
- Audit logs record proposal/admission/decision distinctions and every rejected
  authority escalation.
- Large or malformed typed payloads are bounded before parsing/storage.
- Secret scanning/redaction applies to evidence and rendered projections.
- Exploration receives a least-context, secret-scanned manifest through the OMP
  broker. Generator, synthesizer and deepening stages are fresh, tool-free and
  have no ambient filesystem, shell, SQL, WorkService, GitHub, deployment,
  provider-account or unrestricted network capability.
- Every exploration dispatch is bounded by owner authorization plus hard per-
  call/cumulative call, token, wall-clock, concurrency, retry and enforceable
  currency ceiling or fixed call/token/time limits, plus metered quota when
  available. Each invocation binds a provider/stage-specific
  payload, destination, redaction, egress and retention receipt. Explicit
  invocation cannot override repository/provider egress policy.
- Preserve concise options/rationales and exact receipts, not hidden reasoning.

## 13. Renderer and compatibility

The blueprint Markdown must be generated from typed state and include:

- source request and evidence anchors;
- normalized problem/outcome;
- entities, relationships, constraints and requirement dimensions;
- assumptions, non-goals and rejected/superseded interpretations;
- owner decisions and question provenance;
- acceptance criteria with claim/oracle references;
- formal checks with the full relative-to-model status;
- unresolved/semantic-only clauses;
- contract/snapshot/ontology/rule hashes and receipt IDs.

When exploration exists, the intake projection may show its current status,
estimate/actual usage, neutral synthesized options, evidence/assumption labels,
watch-outs and exact answer-source link. Expanded branch summaries are
non-authoritative and sanitized. It never renders private reasoning or a model
score as confidence. Planning exploration appears only in a separately labeled
advisory section.

Editing the rendered file does not edit the contract. Compatibility with the
current headed Markdown path is time-bounded and tested during NSI-6 shadow
cutover. Never reparse Markdown into authoritative records.

## 14. Qualification and promotion

Deterministic test groups:

- schema evolution and canonicalization compatibility;
- type/namespace/cardinality/exclusivity/allowed-value properties;
- graph closure, cycles, dangling references and order invariance;
- unknown versus false, conflict versus uncertainty;
- supersession and stale-source/rule invalidation;
- actor authority, model-proposal isolation and prompt injection;
- evidence span/hash tampering and derivation provenance;
- question-to-gap mapping, duplicate suppression and tool-first routing;
- AC traceability, oracle and non-goal/coverage rules;
- idempotency, optimistic concurrency, partial publication and unknown outcome;
- solver timeout/unknown/malformed/resource and semantic-gap cases;
- restart/resume with a durable question agenda and exact revision checks.

When the optional exploration extension is enabled, additional deterministic,
fault, security and UI tests cover:

- exploration eligibility/authorization, deterministic frame replay, identical
  frozen branch inputs, sibling isolation, candidate/option/deepening schema and
  reference screening, explicit hard-constraint handling and critic full-context tests;
- all-settled branch failure, provider timeout/429/refusal/unknown outcome,
  synthesis/deepening failure, reservations/caps, cancellation/late results,
  reconciliation/outcome-unknown conservative accounting, warned fresh-offer
  replacement, process death, duplicate start, serialized direct-answer race
  and stale-input tests;
- exact-answer confirmation, unselected-option neutrality, planning-artifact
  exclusion, separate provenance-link semantic-hash exclusion, hostile
  rendering, secret/egress controls and mobile/accessibility.

Outcome experiment:

| Arm | Configuration |
| --- | --- |
| A | Current `/intake` |
| B | Practitioner requirements interviewer plus decisions log |
| C | Typed claims/provenance plus code-owned rules |
| D | C plus selectively qualified formal adapters |

Use the same frozen tasks and model/context conditions. Include real historical
work and seeded critical omissions, contradictions, ambiguity, stale evidence,
security/rollback/concurrency gaps and injection. Measure false-ready first,
then critical omissions, AC coverage, material/redundant questions, owner
corrections, key-question efficiency, plan deviations caused by intake,
downstream audit findings, provenance completeness, tokens and time.

Promotion requires:

- zero false-ready results on the seeded critical-omission corpus;
- complete provenance for every premise used in a
  `READY_FOR_RATIFICATION` assessment;
- deterministic replay and all authority/security/fault tests passing;
- owner review of semantic mappings and rollback readiness.

Do not invent numeric thresholds for the other metrics before baseline data
exists. Preserve raw results and promotion decision provenance.

Run the separate X-A, X-B, X-C0, X-C and X-D `NSI-E4` experiment from `03B`
after base NSI qualification. It compares no alternatives, one-pass
alternatives, equal-width unframed and framed branches plus the same synthesis
route, prompt and limits,
and a randomized deepening offer at reported/equalized compute. Tune on a pilot
and judge a frozen holdout. Promotion requires zero authority, containment,
secret/egress, currentness, fencing, idempotency or limit-enforcement
violations; zero critical conflicts presented as compliant, exposed as
selectable or admitted into owner/semantic state; zero option submission after
staleness; preregistered non-inferiority on false-ready, critical omissions,
provenance closure and owner-correction burden; stable material benefit over
X-A and an equal-compute control; owner-confirmed currency/resource limit
compliance; and proven rollback.
Base NSI promotion does not depend on exploration success.

## 15. Downstream consumer contract

After NSI-6 promotion, `/plan` and the Fleet Kernel may accept a Work item only
when all are true:

```text
intake.state == "published"
assessment.verdict == "READY_FOR_RATIFICATION"
readiness.result == "ELIGIBLE_FOR_PUBLICATION"
WorkService.isCurrent(assessment.id) == true
WorkService.isCurrent(ratification.id) == true
WorkService.isCurrent(readiness.id) == true
WorkService.isCurrent(publication.id) == true
readiness.ratificationReceiptId == ratification.id
ratification.assessmentHash == assessment.assessmentHash
readiness.assessmentHash == assessment.assessmentHash
publication.readinessReceiptId == readiness.id
publication.contractHash == intakeContract.contractHash
assessment.contractHash == intakeContract.contractHash
ratification.contractHash == intakeContract.contractHash
readiness.contractHash == intakeContract.contractHash
assessment.semanticClosureHash == intakeContract.semanticClosureHash
ratification.semanticClosureHash == intakeContract.semanticClosureHash
readiness.semanticClosureHash == intakeContract.semanticClosureHash
readiness.snapshotHash == currentSnapshot.snapshotHash
readiness.ontologyVersion == activeOntology.version
readiness.ruleBundleHash == activeRuleBundle.hash
every readiness.requiredFormalPropertyId has exactly one current binding
every receipt binding ref resolves to an immutable matching content hash
every required binding matches readiness.ratificationReceiptId, contractHash,
  formalizationHash and draftFormalCheckResultHash
readiness.semanticOnlyClauseIds exactly names policy-permitted non-formal clauses
no material gap or conflict is current
consumer supports every schema version
```

Publication itself requires the current positive receipt. `/plan` and Fleet
additionally require the successful `published` state; possessing an
unpublished or superseded receipt grants no downstream capability.

The Fleet risk router derives from admitted claims and rule reasons, not raw
issue prose. Its context compiler includes only admitted claims and referenced
evidence, while preserving the owner's source words in a data section. The
Engineering Manager may propose claims/questions but cannot admit owner intent
or ratify. The Fleet Manager may display state and submit owner-authenticated
commands; it does not mint receipts client-side.

A current post-publication `PlanningExplorationArtifact` may be included in a
separate `advisory_planning_context` section for `/plan`. It cannot fill a
missing acceptance premise, alter risk, authorize graph topology or survive a
contract/publication/snapshot change. Owner-decision exploration contributes
downstream only through the ordinary admitted owner decision and resulting
ratified contract.

## 16. Decisions deliberately left to NSI-1

These are repository-dependent choices and must be resolved from current code,
not guessed in this package:

- exact TypeScript schema library and generated-client mechanism;
- table/module/route names and event-envelope shape;
- canonical JSON/hash implementation already used by WorkService;
- exact owner authentication actor mapping;
- artifact-store URI scheme and retention policy;
- initial rule-bundle file format;
- whether the historical corpus justifies any solver adapter in the first
  release;
- calibrated interaction budget and noncritical promotion thresholds.

Each decision must preserve the authority and semantic boundaries above.

## 17. Optional exploration controlling reference

`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` is the controlling additive
contract for `NSI-E1` through `NSI-E4` and the `N4` gate. Implementations must
not infer a broader capability from the word “exploration.” In particular,
ordinary intake, direct answers, ratification, publication, `/plan` and Fleet
remain fully functional with the extension absent, disabled, failed or rolled
back.

The repository-dependent exploration profiles, reviewed frame wording and
selector, provider pricing/usage sources, minimum branch diversity,
data-egress/retention bindings and non-safety promotion thresholds are resolved
by `NSI-E1`/`NSI-E4`, not core NSI-1.
