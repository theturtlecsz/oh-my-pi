# PostgreSQL migration review supplement

This is not a second migration intake. Paste it into the active migration
session before final ratification or, if work was already published, ask OMP to
create only the missing acceptance criteria or child work. While SQL-0 is in
progress, this is the only file in the package that should affect active work;
the Neuro-symbolic Intake Compiler, Fleet, K3 execution and Fleet Manager
programs remain downstream. Do not add an ontology, reasoner or solver to
SQL-0 merely to anticipate the next program.

```text
Rebaseline the active PostgreSQL/WorkService migration program against the
following completion gates. This is a review and deduplication pass, not a new
program and not permission to implement. Inspect the current repository and
the already-published WorkService work first. For every item below report one
of:

- PRESENT_AND_PROVEN: identify the existing work item and its evidence;
- PRESENT_NOT_PROVEN: identify the work item and missing proof;
- MISSING: propose the smallest amendment or additional child;
- NOT_APPLICABLE: justify concretely.

Do not duplicate ratified work. Do not silently broaden a child. Preserve the
current dependency graph and add only genuine gaps. Ask the owner only when a
choice materially changes authority, data loss risk, deployment, or product
semantics.

AUTHORITY AND NAMING

1. PostgreSQL accessed through a typed WorkService is the sole post-cutover
   authority for work records and lifecycle facts. Model-facing commands and
   repository markers use backend-neutral names such as Work, Workspace and
   WorkService, not Linear, SQL or Postgres.

2. Preserve imported Linear IDs, URLs, timestamps and source revisions as
   provenance/aliases. They are not post-cutover authority.

3. No model, task subagent, repository code, browser or shell receives a
   PostgreSQL credential or direct SQL tool. Interactive OMP uses narrow typed
   WorkService operations. Service identities and capabilities are explicit.

4. Do not migrate unrelated SQLite databases. In particular, omp-webui's
   SQLite session index/replay cache and OMP credential/session stores are not
   the work ledger.

CURRENT SEMANTIC INVENTORY

5. Inventory and preserve or intentionally retire every Linear-backed
   interactive semantic, including:
   - NOW ownership and clearing;
   - parent/child/dependency trees and cycle prevention;
   - project health and waiting/blocked views;
   - acceptance criteria and owner-ratified intent;
   - typed evidence, handoff and review records;
   - approved-plan hashes/stamps and the fail-closed plan gate;
   - `/intake` publication and partial-publication recovery;
   - `/summary` independent-audit forwarding and verdict;
   - `/done` closeout and its required preconditions;
   - batch publication, optimistic concurrency and local cache behavior;
   - `.linear-*` markers, credentials, installers, documentation and tests.

6. Prove the complete owner workflow after cutover:

   `/intake -> publish -> /plan -> approve -> implement -> /summary -> /done`

   Publication, plan approval, audit/review forwarding and lifecycle mutation
   fail closed when WorkService is unavailable. Read-only orientation may
   degrade honestly, but it may not invent current state.

7. Inspect Robomp's SQLite authority separately. Do not mechanically port its
   legacy queue/state machine into the migration. Before WorkService becomes
   sole authority, either:
   - quiesce and disable every production Robomp write path, importing any
     unresolved business work and provenance that must survive; or
   - prove a temporary compatibility adapter with a bounded retirement date.

   Archive the legacy DB and reconciliation evidence. Runs, stages, attempts,
   fleet leases and scheduling belong to the later Fleet Kernel program, not
   to a duplicated migration-time scheduler.

DATA MODEL AND SERVICE SEMANTICS

8. WorkService has explicit, versioned types for work, dependencies,
   acceptance contracts, plans/plan approvals, evidence, reviews/verdicts,
   ownership, lifecycle events and imported provenance. State transitions are
   validated server-side.

   Evidence and review records must have a schema-versioned machine envelope,
   candidate/plan identity and content hashes. The durable object is canonical;
   Markdown is a renderer output for humans, never the machine protocol. The
   `/summary` path publishes through a WorkService sink adapter rather than
   asking a model to copy its own report between transports.

   If the current headed-text auditor parser must remain during cutover, label
   it as a compatibility bridge and create an explicit Fleet dependency to
   replace it with runtime-generated `EvidenceManifest` and native typed
   `AuditResult`. Do not simply re-enable the currently problematic task-agent
   `outputSchema` path without transport regression tests.

8A. Preserve the distinction between interactive and fleet authority:
   - an owner session may retain one active NOW item and owner-authorized final
     transitions;
   - fleet work uses independent fenced claims and controller-authorized
     transitions under frozen policy;
   - a model authorizes neither mode.

8B. Ratify storage and API extension points for the future machine-owned
    evidence pipeline. At minimum they must support schema version, work/run/
    stage/attempt identity, plan hash, base/candidate commit and tree, dirty
    baseline, changed paths, content-addressed diff and verification artifacts,
    acceptance-criterion evidence references, typed findings/unverified claims,
    model/sandbox/policy provenance and invalidation after any mutation.

8C. Ratify an additive post-migration extension seam for a future typed intake
    compiler. The migration does not implement it, but WorkService versioning,
    artifacts, actor authority, optimistic concurrency, events and generated
    contracts must not preclude: frozen intake snapshots; atomic candidate and
    admitted claims; exact evidence spans; owner decisions; derivations;
    conflicts and gaps; acceptance-criterion trace links; contract hashes;
    owner ratification; and server-generated readiness receipts. Markdown must
    remain a projection. This is an extension seam, not permission to broaden
    SQL-0 into NSI-1 through NSI-6.

9. Every mutation supports:
   - a stable idempotency key;
   - a request hash;
   - expected prior revision/state;
   - actor/service identity;
   - append-only intent/audit event;
   - deterministic same-key/same-body replay;
   - rejection of same-key/different-body reuse;
   - reconciliation after timeout or unknown outcome.

10. Dependencies are transactionally validated. Tests cover cycles,
    duplicates, missing parents, partial batch failure, concurrent publication,
    stale versions and retry after an ambiguous response.

11. Durable events use a monotonic opaque cursor. Notifications may wake
    readers, but LISTEN/NOTIFY or in-memory delivery is not authority. Consumers
    can snapshot at `as_of_cursor`, resume, deduplicate and detect a gap.

12. Schema migrations are forward-only, transactional where PostgreSQL permits,
    tested from every supported deployed version, and safe under rolling
    application deployment. The service exposes schema/API versions and
    readiness separately from liveness.

CUTOVER AND ROLLBACK

13. Avoid an uncontrolled dual-write period. Linear remains authoritative
    through rehearsal. Perform an initial import and shadow-read comparison,
    then freeze legacy mutations, import the final delta, reconcile, and flip
    one backend selector atomically so WorkService becomes the sole writer.

14. Record source high-water marks, row counts by entity/state, dependency
    counts, normalized checksums, rejected/exception rows and a human-readable
    reconciliation report. Preserve the exact importer and version used.

15. Rehearse the cutover on a production-shaped copy. Test interruption before
    and after every boundary. Rerunning the importer is idempotent and never
    duplicates comments, reviews, dependencies or lifecycle events.

16. Pre-cutover rollback is rehearsed. After WorkService accepts new writes,
    rollback is explicitly a reconciliation/export procedure—not a blind flip
    back to stale Linear. Define the point of no return, recovery owner and
    data-loss envelope.

17. Revoke or remove Linear runtime credentials and disable its mutation paths
    only after the full workflow smoke test passes. A repository-wide check
    proves no production path can fall back to Linear or legacy SQLite.

OPERATIONS AND SECURITY

18. Local development and tests use a reproducible PostgreSQL environment,
    not an SQLite compatibility mode. Connection pools, statement timeouts,
    transaction timeouts, cancellation and bounded pagination are configured.

19. Backups, point-in-time recovery where appropriate, restore into an empty
    environment, migration replay and disaster-recovery runbooks are exercised,
    timed and evidenced. A successful backup command without a restore drill is
    not proof.

20. Least-privilege database roles separate migration, service runtime,
    read-only operations and backup. TLS and secret rotation are covered.
    Logs, errors and telemetry contain no credentials or sensitive payloads.

21. Work text, imported comments, repository content and tool output are
    untrusted data. They are never interpolated into trusted instructions and
    cannot authorize a WorkService mutation.

22. Observability covers mutation latency/errors, connection-pool pressure,
    lock waits, deadlocks, stale-version conflicts, idempotent replays, event
    lag, import exceptions, backup freshness and service/API versions.

DOWNSTREAM INTAKE AND FLEET HANDOFF CONTRACT

23. Ratify versioned WorkService extension seams for the future Neuro-symbolic
    Intake Compiler and Fleet Kernel. The migration need not implement intake
    reasoning or fleet scheduling, but it must not preclude:
    typed claim/provenance/decision/ratification/readiness records and
    runs/stages/attempts, claims, leases/fence epochs, manifests, policy/budgets,
    immutable receipts/artifacts, stop epochs, external intents, durable fleet
    events, versioned per-attempt execution graphs/nodes/artifact edges/joins,
    or resource claims. This is an extension seam only: do not add the graph
    reasoner, solver adapter, graph scheduler, sandbox runtime, cache
    optimization or agent fleet to SQL-0.

24. Publish generated OpenAPI/JSON Schemas and contract fixtures for consumers.
    The future controller and Fleet Manager use those APIs; neither writes SQL.

25. End with a machine-readable migration completion report containing:
    source and target versions; reconciliation hashes/counts; exceptions;
    workflow smoke results; backup/restore result; revoked legacy paths;
    residual risks; and an explicit SQL-0 verdict of PROVEN or NOT_PROVEN.

The Neuro-symbolic Intake Compiler may not start until SQL-0 is PROVEN. The
Autonomous Fleet Kernel may not be published or activated until the intake
compiler has separately qualified and cut over its typed contract/readiness
consumer seam. If any gate above is missing, amend only the active migration
program. Do not create NSI, Fleet Kernel or Fleet Manager children under the
migration.
```
