# Bounded Intake Exploration technical contract

Status: additive implementation baseline for the optional `NSI-E1` through
`NSI-E4` side extension. Each child starts only after the core dependencies in
Section 17; N4 requires the integrated NSI-E4/NSI-6 qualification. The
owner-facing product label is **Explore alternatives**. This design
adapts useful divergent-ideation mechanics from
[`UditAkhourii/adhd`](https://github.com/UditAkhourii/adhd) at
`53ab5576b77fb3d6e62739a1a285356261e5f568`; it does not install that package,
adopt its Claude-specific runtime, or make exploration a readiness authority.

The core intake contract in
`03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md` remains controlling. If this
addendum and that contract appear to disagree, preserve owner authority,
WorkService authority, exact provenance, deterministic readiness and the
narrower capability.

## 1. User outcome

For a genuinely consequential open choice, intake may offer the owner a small,
bounded design panel before asking for the final answer:

```text
current code-selected clarification question
  -> owner chooses Explore alternatives and confirms hard currency-or-resource limits
  -> isolated read-only branches receive the same frozen brief
  -> code validates and screens their structured proposals
  -> a separate model produces a concise neutral comparison
  -> owner uses or combines an option, writes an answer, says none fit or decides later
  -> owner confirms the exact answer that will be recorded
  -> normal recordOwnerDecision admission and deterministic reasoning rerun
```

The default `/intake` path remains fast. No usage-consuming exploration starts
because the model thinks it would be interesting. The system may offer the
action when code finds an eligible decision; the owner must authorize every
model run, including metered-quota and resource-only subscription routes, during the first qualified
release.

Two and only two lanes are supported:

1. `owner_decision` is bound to one current `ClarificationQuestion`. It may help
   the owner decide product behavior, scope or policy. It returns to the normal
   owner-decision path.
2. `planning_handoff` is available only after successful intake publication.
   It explores implementation approaches for `/plan`. It is an advisory
   context artifact, never an intake requirement or owner decision.

There is no general-brainstorm lane, arbitrary remote prompt box or default
intake swarm.

## 2. Authority boundary

| Object or action | Authority |
| --- | --- |
| Whether a current question is eligible for an offer | Reviewed policy plus deterministic WorkService checks |
| Whether any exploration model run starts | Authenticated owner authorization under hard server-enforced currency-or-resource limits |
| Frame registry, prompt compiler, context compiler and limits | Reviewed, versioned harness source |
| Candidate options, criticisms, clusters and proposed traps | Model proposals only |
| Repository feasibility facts | Current tool evidence bound to the frozen source snapshot |
| Constraint conflicts and candidate schema/reference validity | Deterministic code |
| Product meaning | Owner's exact confirmed answer through `recordOwnerDecision` |
| Intake gaps, conflicts, assessment, ratification and publication | Existing NSI reasoner and WorkService contracts |
| Technical approach selected by `/plan` | Planner under the published intake and normal plan approval |

Exploration cannot create or remove a `Gap`, admit an `IntakeClaim`, answer a
question, author a production rule, invoke a formal adapter, waive a policy,
ratify a contract, mint a receipt, publish intake, approve a plan or change
Fleet state. Model agreement, novelty, a score, a trap label and a recommendation
have no authority effect.

Only the exact answer the owner sees and confirms enters the existing
`OwnerDecision` path. Unselected alternatives remain unselected proposals; they
do not become rejected interpretations, prohibited behavior or non-goals unless
the owner explicitly says so.

## 3. What is adopted, adapted and rejected

Adopt from the upstream method:

- isolated parallel generation under meaningfully different perspectives;
- strict separation between initial generation and later criticism;
- grouping by underlying approach rather than surface wording;
- explicit surfacing of attractive failure modes and assumptions; and
- optional bounded deepening of promising options.

Substantially adapt:

- OMP's existing model broker, task isolation, WorkService state and generated
  contracts replace the standalone Claude Agent SDK runtime;
- NSI-E1 inventories reusable OMP/WorkService and planned Fleet execution
  primitives, then implements one generic bounded-model-job substrate for
  authorization, reservation, broker dispatch, events, cancellation and
  reconciliation. Exploration-specific code owns only eligibility, frozen
  context, frames, typed proposals/screening and option presentation; it does
  not create a second scheduler/control plane;
- code selects a reviewed, versioned frame pack deterministically rather than
  using unseeded randomness;
- every stage receives one identical frozen `ExplorationInputManifest` plus
  its stage-specific data;
- hard constraints, provenance and malformed references are screened by code
  before model synthesis;
- model judgments become plain-language advisory tradeoffs, not numeric truth;
- branch failures are independently durable and use all-settled semantics;
- the UI shows a few options and hides the wider pool behind disclosure; and
- owner selection uses normal revision-bound decision admission.

Reject:

- automatic anchor stripping or silent rewriting of the question;
- explicit invocation bypassing privacy, authority, staleness or budget policy;
- fixed `novelty * .35 + viability * .40 + fit * .25` pruning;
- automatically removing an option because a model called it a trap;
- random or unrecorded frames;
- raw chain-of-thought collection or display;
- direct provider credentials, tools, shell, filesystem, SQL or lifecycle
  mutation in a branch;
- one provider/parse failure destroying every successful branch;
- thirty equally weighted ideas in normal intake; and
- the upstream six-task, same-family LLM-judged result as local proof of value.

## 4. Eligibility and invocation

An `owner_decision` offer is legal only when all are true:

- WorkService has returned one current code-selected
  `ClarificationQuestion` bound to the current intake revision;
- the question represents owner authority rather than a repository/tool lookup;
- several materially different answers could be valid;
- the choice affects product semantics, scope, safety, security, data,
  compatibility or downstream rework;
- no current conflict, source policy or data classification prohibits provider
  egress; and
- an enforceable route, concurrency slot and budget are available.

It is not offered for canonical lookups, repository-discoverable facts, a bug
with a known cause, trivial wording, a genuinely exhaustive exactly-one answer,
or a question already answered/superseded. The owner may explicitly request
exploration when the offer heuristic says no, but explicit invocation still
cannot bypass the hard open-choice/owner-authority eligibility rules,
currentness, data policy, authorization, containment or hard budgets.

A `planning_handoff` run additionally requires a current `published` intake,
matching `IntakePublicationReceipt` and current contract/snapshot. It cannot
resolve a missing requirement. Any missing product meaning routes back to
normal intake.

Initial command outcomes, adapted to live OMP conventions during implementation:

```text
/intake --explore <request>   # offer exploration at the first eligible question
/explore                     # target the exact current eligible question
/explore status              # show current durable run and actual usage
/explore cancel              # request safe cancellation of that exact run
/explore approaches          # post-publication planning handoff only
```

`/explore status` renders the same legal recovery actions as Web. During
reconciliation it can select **Keep waiting**; after `outcome_unknown` it can
request **Authorize a replacement call**, which only opens a fresh current
offer and never dispatches or reuses limits by itself.

`--explore` requests an offer; it does not pre-authorize model calls or quota
use. If no current question is eligible, `/explore` returns `No eligible open
intake decision right now` plus a deterministic reason/current question when
safe, makes no model call and leaves direct intake available. For example:
`This is a repository fact; OMP will inspect the code instead.` `/intake
--explore` simply continues normal intake if no eligible question appears.

## 5. Normative typed domain

Exact module and route names follow live repository conventions. These field
semantics and authority distinctions are normative.

```ts
type ExplorationOfferId = string;
type ExplorationRunId = string;
type ExplorationDeepeningRunId = string;
type ExplorationKind = "owner_decision" | "planning_handoff";

type ExplorationObjectKind =
  | "authorization"
  | "branch_attempt"
  | "broker_status_receipt"
  | "budget_account"
  | "budget_allocation"
  | "budget_availability"
  | "budget_policy_definition"
  | "budget_reservation"
  | "candidate"
  | "candidate_screening"
  | "clarification_question"
  | "data_classification_receipt"
  | "deepening_artifact"
  | "deepening_authorization"
  | "deepening_run"
  | "deepening_screening"
  | "egress_plan"
  | "egress_policy_receipt"
  | "egress_projection"
  | "eligibility_assessment"
  | "encrypted_idempotency_key"
  | "exploration_run"
  | "frame_selection"
  | "gap"
  | "input_manifest"
  | "intake_publication_receipt"
  | "invocation_intent"
  | "invocation_receipt"
  | "ledger_transaction"
  | "model_route_receipt"
  | "option"
  | "option_screening"
  | "owner_decision"
  | "pricing_snapshot"
  | "proposed_assertion"
  | "provider_data_handling"
  | "provider_ingress_admission"
  | "quota_meter"
  | "redaction_impact_receipt"
  | "redaction_receipt"
  | "reservation_partition_event"
  | "screened_assertion"
  | "stage_attempt"
  | "subscription_entitlement"
  | "synthesis"
  | "terminal_artifact"
  | "usage_receipt";

interface ExplorationRef<K extends ExplorationObjectKind> {
  kind: K;
  id: string;
  contentHash: string;
}

interface ExplorationSnapshotRef<K extends ExplorationObjectKind> {
  kind: K;
  id: string;
  revision: number;
  contentHash: string;
}

interface ExplorationControlRef<K extends ExplorationObjectKind> {
  kind: K;
  id: string;
  controlHash: string;
}

type ExplorationTarget =
  | {
      kind: "owner_decision";
      questionRef: ExplorationRef<"clarification_question">;
      gapRefs: ExplorationRef<"gap">[];
    }
  | {
      kind: "planning_handoff";
      contractHash: ContractHash;
      snapshotHash: string;
      publicationReceiptRef: ExplorationRef<"intake_publication_receipt">;
    };

interface ExplorationLimits {
  maxBranches: number;
  maxCandidatesPerBranch: number;
  maxModelCallsPerStage: number;
  maxTotalModelCalls: number;
  maxInputTokensPerCall: number;
  maxOutputTokensPerCall: number;
  maxTotalInputTokens: number;
  maxTotalOutputTokens: number;
  maxInvocationWallClockMs: number;
  maxWallClockMs: number;
  maxConcurrency: number;
  maxRetriesPerStage: number;
}

type ExplorationCostControl =
  | {
      kind: "broker_enforced_currency_cap";
      currency: string;
      maxCostMicros: number;
      pricingSnapshotRef: ExplorationRef<"pricing_snapshot">;
    }
  | {
      kind: "metered_quota";
      dollarLimitAvailable: false;
      quotaUnit: string;
      maxQuotaUnits: number;
      quotaMeterReceiptRef: ExplorationRef<"quota_meter">;
    }
  | {
      kind: "resource_only_subscription";
      dollarLimitAvailable: false;
      quotaLimitAvailable: false;
      subscriptionEntitlementReceiptRef: ExplorationRef<"subscription_entitlement">;
    };

interface ExplorationEligibilityAssessmentBase {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  hardEligible: boolean;
  hardFailureCodes: string[];
  suggestOffer: boolean;
  suggestionReasonRuleIds: RuleId[];
  policyHash: string;
  engineVersion: string;
  contentHash: string;
}

type ExplorationEligibilityAssessment =
  | (ExplorationEligibilityAssessmentBase & {
      kind: "owner_decision";
      target: Extract<ExplorationTarget, { kind: "owner_decision" }>;
      questionArchetype: string;
      answerDomain: "open" | "bounded" | "canonical";
      materiality: RequirementDimensionDefinition["materiality"];
    })
  | (ExplorationEligibilityAssessmentBase & {
      kind: "planning_handoff";
      target: Extract<ExplorationTarget, { kind: "planning_handoff" }>;
      questionArchetype?: never;
      answerDomain?: never;
      materiality?: never;
    });

interface ExplorationPolicy {
  id: string;
  version: string;
  trigger: "owner_only" | "owner_or_system_offer";
  allowedKinds: ExplorationKind[];
  allowedMaterialities: RequirementDimensionDefinition["materiality"][];
  dataClassificationPolicyHash: string;
  allowedDataClassIds: string[];
  frameRegistryHash: string;
  contextCompilerVersion: string;
  promptCompilerVersion: string;
  modelRoutingPolicyHash: string;
  budgetPolicyDefinitionRef: ExplorationRef<"budget_policy_definition">;
  limits: ExplorationLimits;
  presentationPolicy: {
    ownerDecision: {
      minimumPresentableBranches: number;
      minimumDistinctFrameFamilies: number;
      minimumPresentableOptions: number;
      maximumPresentableOptions: number;
    };
    planningHandoff: {
      minimumPresentableBranches: number;
      minimumDistinctFrameFamilies: number;
      minimumPresentableApproaches: number;
      maximumPresentableApproaches: number;
    };
  };
  reconciliationDeadlineMs: number;
  ownerConfirmationRequired: true;
  automaticUsageConsumingRun: false;
  contentHash: string;
}

interface ExplorationEstimateBase {
  modelCalls: { minimum: number; maximum: number };
  inputTokens: { minimum: number; maximum: number };
  outputTokens: { minimum: number; maximum: number };
  wallClockMs: { minimum: number; maximum: number };
}

type ExplorationCostedEstimate =
  | {
      costControl: Extract<ExplorationCostControl,
        { kind: "broker_enforced_currency_cap" }>;
      estimate: ExplorationEstimateBase & {
        costMicros: { minimum: number; maximum: number };
      };
    }
  | {
      costControl: Exclude<ExplorationCostControl,
        { kind: "broker_enforced_currency_cap" }>;
      estimate: ExplorationEstimateBase & { costMicros?: never };
    };

interface ExplorationOfferBase {
  id: ExplorationOfferId;
  intakeId: IntakeId;
  intakeRevision: number;
  eligibilityAssessmentRef: ExplorationRef<"eligibility_assessment">;
  policyHash: string;
  inputManifestRef: ExplorationRef<"input_manifest">;
  budgetPolicyDefinitionRef: ExplorationRef<"budget_policy_definition">;
  budgetAvailabilityRef: ExplorationSnapshotRef<"budget_availability">;
  plannedRoutes: Array<{
    stage: "diverge" | "synthesize";
    routeReceiptRef: ExplorationRef<"model_route_receipt">;
  }>;
  egressPlanRefs: ExplorationRef<"egress_plan">[];
  hardLimits: ExplorationLimits;
  expiresAt: string;
  semanticContentHash: string;
  controlHash: string;
}

type ExplorationOfferLane =
  | {
      lane: "owner_decision";
      target: Extract<ExplorationTarget, { kind: "owner_decision" }>;
    }
  | {
      lane: "planning_handoff";
      target: Extract<ExplorationTarget, { kind: "planning_handoff" }>;
    };

type ExplorationOffer = ExplorationOfferBase & ExplorationOfferLane &
  ExplorationCostedEstimate;

interface ExplorationAuthorization {
  id: string;
  offerId: ExplorationOfferId;
  offerControlHash: string;
  intakeId: IntakeId;
  intakeRevision: number;
  ownerActor: ActorRef & { kind: "owner" };
  acceptedLimits: ExplorationLimits;
  acceptedCostControl: ExplorationCostControl;
  exactConfirmationArtifactId: ArtifactId;
  exactConfirmationArtifactHash: string;
  authorizedAt: string;
  controlHash: string;
}

interface ExplorationInputManifestBase {
  id: string;
  intakeId: IntakeId;
  intakeRevision: number;
  snapshotHash: string;
  exactOwnerWordingArtifactRefs: Array<{ id: ArtifactId; sha256: string }>;
  admittedClaimRefs: Array<{ id: ClaimId; contentHash: string }>;
  constraintRefs: Array<{ id: string; contentHash: string }>;
  nonGoalRefs: Array<{ id: string; contentHash: string }>;
  priorDecisionRefs: Array<{ id: DecisionId; contentHash: string }>;
  unknownGapRefs: Array<{ id: string; contentHash: string }>;
  evidenceSpanRefs: Array<{ id: string; spanHash: string }>;
  repositoryCommits: Record<string, string>;
  ontologyVersion: string;
  ruleBundleHash: string;
  contextCompilerVersion: string;
  dataClassificationReceiptRef: ExplorationRef<"data_classification_receipt">;
  contentHash: string;
}

type ExplorationInputManifest = ExplorationInputManifestBase &
  ExplorationOfferLane;

interface ExplorationFrameDefinitionBase {
  id: string;
  version: string;
  family: "practical" | "user" | "failure" | "security" | "operations" |
    "compatibility" | "inversion" | "assumption_challenge" | "wildcard";
  promptTemplateArtifactId: ArtifactId;
  promptTemplateHash: string;
  contentHash: string;
}

type ExplorationFrameDefinition =
  | (ExplorationFrameDefinitionBase & {
      lane: "owner_decision";
      appliesToMaterialities: RequirementDimensionDefinition["materiality"][];
    })
  | (ExplorationFrameDefinitionBase & {
      lane: "planning_handoff";
      appliesToMaterialities?: never;
    });

interface ExplorationFrameSelection {
  lane: ExplorationKind;
  registryHash: string;
  selectorVersion: string;
  selectorSeed: string;
  selectedFrameRefs: Array<{ id: string; version: string; contentHash: string }>;
  selectionReasonCodes: string[];
  contentHash: string;
}

interface ModelRouteReceipt {
  id: string;
  role: "intake_explore_generate" | "intake_explore_critic" |
    "intake_explore_deepen";
  provider: string;
  model: string;
  effort: string;
  region?: string;
  statusLookupSupported: boolean;
  idempotentSubmitSupported: boolean;
  routingPolicyHash: string;
  resolvedAt: string;
  contentHash: string;
}

interface ExplorationBudgetPolicyDefinitionBase {
  id: string;
  version: string;
  scopeHash: string;
  periodRuleHash: string;
  limits: ExplorationLimits;
  maxConcurrentRuns: number;
  contentHash: string;
}

type ExplorationBudgetPolicyDefinition =
  | (ExplorationBudgetPolicyDefinitionBase & {
      costControlKind: "broker_enforced_currency_cap";
      currency: string;
      pricingSourcePolicyHash: string;
      quotaUnit?: never;
    })
  | (ExplorationBudgetPolicyDefinitionBase & {
      costControlKind: "metered_quota";
      currency?: never;
      quotaUnit: string;
      quotaMeterPolicyHash: string;
    })
  | (ExplorationBudgetPolicyDefinitionBase & {
      costControlKind: "resource_only_subscription";
      currency?: never;
      quotaUnit?: never;
      subscriptionEntitlementPolicyHash: string;
    });

interface ExplorationBudgetAvailabilityBase {
  id: string;
  budgetPolicyDefinitionRef: ExplorationRef<"budget_policy_definition">;
  budgetAccountRef: ExplorationRef<"budget_account">;
  ledgerRevision: number;
  periodStart: string;
  periodEnd: string;
  remainingModelCalls: number;
  remainingInputTokens: number;
  remainingOutputTokens: number;
  remainingConcurrentRuns: number;
  issuedAt: string;
  expiresAt: string;
  revision: number;
  contentHash: string;
}

type ExplorationBudgetAvailabilityReceipt =
  | (ExplorationBudgetAvailabilityBase & {
      costControlKind: "broker_enforced_currency_cap";
      currency: string;
      pricingSnapshotRef: ExplorationRef<"pricing_snapshot">;
      remainingCostMicros: number;
      remainingQuotaUnits?: never;
    })
  | (ExplorationBudgetAvailabilityBase & {
      costControlKind: "metered_quota";
      quotaUnit: string;
      quotaMeterReceiptRef: ExplorationRef<"quota_meter">;
      remainingCostMicros?: never;
      remainingQuotaUnits: number;
    })
  | (ExplorationBudgetAvailabilityBase & {
      costControlKind: "resource_only_subscription";
      subscriptionEntitlementReceiptRef: ExplorationRef<"subscription_entitlement">;
      remainingCostMicros?: never;
      remainingQuotaUnits?: never;
    });

interface ProviderDataHandlingReceiptBase {
  id: string;
  provider: string;
  providerAccountProfileHash: string;
  endpointOrigin: string;
  region?: string;
  policyVersion: string;
  policySourceArtifactHash: string;
  trainingUse: "disabled" | "enabled" | "unknown";
  verifiedAt: string;
  expiresAt: string;
  contentHash: string;
}

type ProviderRetentionPosture =
  | {
      zeroDataRetention: "verified";
      retentionDurationSeconds: 0;
      deletionSupport: "supported" | "unsupported";
    }
  | {
      zeroDataRetention: "not_available";
      retentionDurationSeconds: number;
      deletionSupport: "supported" | "unsupported";
    }
  | {
      zeroDataRetention: "unknown";
      retentionDurationSeconds?: never;
      deletionSupport: "unknown";
    };

type ProviderCachePosture =
  | {
      promptCacheMode: "disabled";
      cacheDurationSeconds?: never;
    }
  | {
      promptCacheMode: "ephemeral" | "persistent";
      cacheDurationSeconds: number;
    }
  | {
      promptCacheMode: "unknown";
      cacheDurationSeconds?: never;
    };

type ProviderDataHandlingReceipt = ProviderDataHandlingReceiptBase &
  ProviderRetentionPosture & ProviderCachePosture;

interface ExplorationEgressPlan {
  id: string;
  inputManifestHash: string;
  stage: "diverge" | "synthesize" | "deepen";
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  providerAccountProfileHash: string;
  endpointOrigin: string;
  region?: string;
  inputDataClassIds: string[];
  derivedDataClassRuleVersion: string;
  redactionPlanHash: string;
  redactionImpactReceiptRef: ExplorationRef<"redaction_impact_receipt">;
  providerDataHandlingReceiptRef: ExplorationRef<"provider_data_handling">;
  egressPolicyReceiptRef: ExplorationRef<"egress_policy_receipt">;
  retentionPolicyHash: string;
  expiresAt: string;
  contentHash: string;
}

interface ProviderEgressProjection {
  id: string;
  inputManifestHash: string;
  stage: "diverge" | "synthesize" | "deepen";
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  egressPlanRef: ExplorationRef<"egress_plan">;
  providerPayloadArtifactId: ArtifactId;
  providerPayloadArtifactHash: string;
  dataClassIds: string[];
  classificationPolicyHash: string;
  redactionReceiptRef: ExplorationRef<"redaction_receipt">;
  egressPolicyReceiptRef: ExplorationRef<"egress_policy_receipt">;
  retentionPolicyHash: string;
  expiresAt: string;
  contentHash: string;
}

interface ProviderIngressAdmissionReceiptBase {
  id: string;
  invocationReceiptRef: ExplorationSnapshotRef<"invocation_receipt">;
  rawArtifactHash: string;
  scannerPolicyHash: string;
  classificationPolicyHash: string;
  derivedDataClassIds: string[];
  secretFindingCodes: string[];
  contentHash: string;
}

type ProviderIngressAdmissionReceipt =
  | (ProviderIngressAdmissionReceiptBase & {
      disposition: "admitted";
      admittedArtifactHash: string;
      encryptedRawRetentionUntil?: never;
    })
  | (ProviderIngressAdmissionReceiptBase & {
      disposition: "quarantined";
      admittedArtifactHash?: never;
      encryptedRawRetentionUntil: string;
    })
  | (ProviderIngressAdmissionReceiptBase & {
      disposition: "rejected";
      admittedArtifactHash?: never;
      encryptedRawRetentionUntil?: never;
    });

interface AdmittedProviderOutputRef {
  kind: "provider_ingress_admission";
  id: string;
  contentHash: string;
  disposition: "admitted";
  invocationReceiptRef: ExplorationSnapshotRef<"invocation_receipt">;
  rawArtifactHash: string;
  admittedArtifactHash: string;
  classificationPolicyHash: string;
  derivedDataClassIds: string[];
}

interface ExplorationBudgetReservationBase {
  id: string;
  budgetPolicyDefinitionRef: ExplorationRef<"budget_policy_definition">;
  consumedBudgetAvailabilityRef: ExplorationSnapshotRef<"budget_availability">;
  budgetAccountRef: ExplorationRef<"budget_account">;
  openingLedgerRevision: number;
  ledgerTransactionRefs: ExplorationRef<"ledger_transaction">[];
  limits: ExplorationLimits;
  reservedModelCalls: number;
  reservedInputTokens: number;
  reservedOutputTokens: number;
  state: "reserved" | "partially_consumed" | "encumbered_unknown" |
    "settled" | "released";
  revision: number;
  expiresAt: string;
  contentHash: string;
}

type ExplorationBudgetReservationIdentity =
  | {
      runKind: "parent";
      runId: ExplorationRunId;
      authorizationRef: ExplorationControlRef<"authorization">;
    }
  | {
      runKind: "deepening";
      runId: ExplorationDeepeningRunId;
      authorizationRef: ExplorationControlRef<"deepening_authorization">;
    };

type ExplorationBudgetReservationEncumbrance =
  | {
      costControl: Extract<ExplorationCostControl,
        { kind: "broker_enforced_currency_cap" }>;
      reservedCostMicros: number;
      reservedQuotaUnits?: never;
    }
  | {
      costControl: Extract<ExplorationCostControl,
        { kind: "metered_quota" }>;
      reservedCostMicros?: never;
      reservedQuotaUnits: number;
    }
  | {
      costControl: Extract<ExplorationCostControl,
        { kind: "resource_only_subscription" }>;
      reservedCostMicros?: never;
      reservedQuotaUnits?: never;
    };

type ExplorationBudgetReservation = ExplorationBudgetReservationBase &
  ExplorationBudgetReservationIdentity & ExplorationBudgetReservationEncumbrance;

interface ExplorationBudgetAllocationBase {
  id: string;
  reservationRef: ExplorationSnapshotRef<"budget_reservation">;
  preAllocationStageAttemptRef: ExplorationSnapshotRef<"stage_attempt">;
  reservationPartitionEventRef: ExplorationRef<"reservation_partition_event">;
  stageBinding: ExplorationStageBinding;
  modelCalls: 1;
  inputTokens: number;
  outputTokens: number;
  state: "encumbered" | "consumed" | "released" | "encumbered_unknown" |
    "settled_conservative_maximum";
  revision: number;
  contentHash: string;
}

type ExplorationBudgetAllocation =
  | (ExplorationBudgetAllocationBase & {
      costControl: Extract<ExplorationCostControl,
        { kind: "broker_enforced_currency_cap" }>;
      costMicros: number;
      quotaUnits?: never;
    })
  | (ExplorationBudgetAllocationBase & {
      costControl: Extract<ExplorationCostControl,
        { kind: "metered_quota" }>;
      costMicros?: never;
      quotaUnits: number;
    })
  | (ExplorationBudgetAllocationBase & {
      costControl: Extract<ExplorationCostControl,
        { kind: "resource_only_subscription" }>;
      costMicros?: never;
      quotaUnits?: never;
    });

interface ExplorationAuthorizationConsumptionBase {
  id: string;
  offerId: ExplorationOfferId;
  offerControlHash: string;
  consumedAt: string;
  contentHash: string;
}

type ExplorationAuthorizationConsumption =
  | (ExplorationAuthorizationConsumptionBase & {
      runKind: "parent";
      authorizationRef: ExplorationControlRef<"authorization">;
      runRef: ExplorationSnapshotRef<"exploration_run">;
    })
  | (ExplorationAuthorizationConsumptionBase & {
      runKind: "deepening";
      authorizationRef: ExplorationControlRef<"deepening_authorization">;
      runRef: ExplorationSnapshotRef<"deepening_run">;
    });

type ExplorationStageBinding =
  | {
      runKind: "parent";
      runId: ExplorationRunId;
      stage: "diverge" | "synthesize";
    }
  | {
      runKind: "deepening";
      runId: ExplorationDeepeningRunId;
      stage: "deepen";
    };

interface ExplorationInvocationReceiptBase {
  id: string;
  invocationIntentRef: ExplorationSnapshotRef<"invocation_intent">;
  preReceiptStageAttemptRef: ExplorationSnapshotRef<"stage_attempt">;
  idempotencyKeyHash: string;
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  egressProjectionRef: ExplorationRef<"egress_projection">;
  reservationRef: ExplorationSnapshotRef<"budget_reservation">;
  inputManifestHash: string;
  compiledSystemPromptHash: string;
  compiledUserPayloadHash: string;
  providerRequestId?: string;
  outcome:
    | "not_dispatched"
    | "provider_rejected"
    | "provider_accepted"
    | "succeeded"
    | "failed"
    | "cancelled"
    | "unknown";
  inputTokens?: number;
  outputTokens?: number;
  costMicros?: number;
  quotaUnits?: number;
  revision: number;
  contentHash: string;
}

type ExplorationInvocationReceipt = ExplorationInvocationReceiptBase &
  ExplorationStageBinding;

interface ExplorationInvocationIntentBase {
  id: string;
  runFenceToken: string;
  preDispatchStageAttemptRef: ExplorationSnapshotRef<"stage_attempt">;
  reservationRef: ExplorationSnapshotRef<"budget_reservation">;
  budgetAllocationRef: ExplorationSnapshotRef<"budget_allocation">;
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  egressProjectionRef: ExplorationRef<"egress_projection">;
  inputManifestHash: string;
  compiledSystemPromptHash: string;
  compiledUserPayloadHash: string;
  providerIdempotencyKeyHash: string;
  providerIdempotencyKeySecretRef: ExplorationRef<"encrypted_idempotency_key">;
  status: "prepared" | "dispatching" | "dispatched" | "revoked" |
    "outcome_unknown";
  revision: number;
  contentHash: string;
}

type ExplorationInvocationIntent = ExplorationInvocationIntentBase &
  ExplorationStageBinding;

interface ProviderReconciledUsage {
  inputTokens: number;
  outputTokens: number;
  costMicros?: number;
  quotaUnits?: number;
}

interface ProviderOutcomeReconciliationBase {
  id: string;
  invocationReceiptRef: ExplorationSnapshotRef<"invocation_receipt">;
  brokerStatusReceiptRef: ExplorationRef<"broker_status_receipt">;
  reconciledAt: string;
  contentHash: string;
}

type ProviderAuthoritativeLookup =
  | {
      method: "provider_lookup";
      reconciliationIdentity: {
        kind: "provider_request_id";
        providerRequestId: string;
      };
    }
  | {
      method: "idempotency_result";
      reconciliationIdentity: {
        kind: "provider_idempotency_key_hash";
        keyHash: string;
      };
    };

type ProviderAuthoritativeLookupOutcome =
  | {
      observedOutcome: "succeeded" | "failed" | "cancelled";
      usage?: ProviderReconciledUsage;
    }
  | {
      observedOutcome: "still_unknown" | "unreconcilable";
      usage?: never;
    };

type ProviderOutcomeReconciliation = ProviderOutcomeReconciliationBase &
  (
    | (ProviderAuthoritativeLookup & ProviderAuthoritativeLookupOutcome)
    | {
        method: "billing_reconciliation";
        reconciliationIdentity: {
          kind: "billing_window";
          accountProfileHash: string;
          windowEnd: string;
        };
        observedOutcome: "billing_only_usage";
        usage: ProviderReconciledUsage;
      }
    | {
        method: "billing_reconciliation";
        reconciliationIdentity: {
          kind: "billing_window";
          accountProfileHash: string;
          windowEnd: string;
        };
        observedOutcome: "still_unknown" | "unreconcilable";
        usage?: never;
      }
    | {
        method: "unsupported";
        reconciliationIdentity: { kind: "none_supported" };
        observedOutcome: "unreconcilable";
        usage?: never;
      }
  );

type ExplorationRunState =
  | "queued"
  | "diverging"
  | "screening"
  | "synthesizing"
  | "reconciling"
  | "ready"
  | "partial"
  | "outcome_unknown"
  | "cancel_requested"
  | "cancelled"
  | "failed"
  | "stale"
  | "superseded";

interface ExplorationRunBase {
  id: ExplorationRunId;
  intakeId: IntakeId;
  intakeRevision: number;
  authorizationRef: ExplorationControlRef<"authorization">;
  budgetReservationRef: ExplorationSnapshotRef<"budget_reservation">;
  inputManifestRef: ExplorationRef<"input_manifest">;
  policyHash: string;
  frameSelectionRef: ExplorationRef<"frame_selection">;
  limits: ExplorationLimits;
  state: ExplorationRunState;
  revision: number;
  fenceToken: string;
  currentStageAttemptRef?: ExplorationSnapshotRef<"stage_attempt">;
  stopReason?:
    | "owner_cancelled"
    | "owner_answered_directly"
    | "deadline"
    | "call_limit"
    | "token_limit"
    | "resource_limit"
    | "insufficient_branches"
    | "provider_failure"
    | "provider_outcome_unknown"
    | "synthesis_failure"
    | "containment_violation"
    | "secret_detected"
    | "egress_denied"
    | "authorization_revoked"
    | "policy_violation"
    | "input_changed"
    | "policy_changed";
  synthesisRef?: ExplorationRef<"synthesis">;
  settledUsageReceiptRef?: ExplorationRef<"usage_receipt">;
  createdAt: string;
  updatedAt: string;
  contentHash: string;
}

type ExplorationRun = ExplorationRunBase & ExplorationOfferLane;

interface ExplorationStageAttemptBase {
  id: string;
  runRevision: number;
  runHash: string;
  runFenceToken: string;
  attempt: number;
  stageLeaseId: string;
  stageLeaseOwnerHash: string;
  stageLeaseExpiresAt: string;
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  invocationIntentRefs: ExplorationSnapshotRef<"invocation_intent">[];
  invocationReceiptRefs: ExplorationSnapshotRef<"invocation_receipt">[];
  status: "queued" | "leased" | "dispatching" | "running" |
    "reconciling" | "succeeded" | "failed" | "cancelled" |
    "outcome_unknown" | "late_discarded";
  terminalArtifactRef?: ExplorationRef<"terminal_artifact">;
  errorCode?: string;
  revision: number;
  contentHash: string;
}

type ExplorationStageAttempt = ExplorationStageAttemptBase &
  ExplorationStageBinding;

interface ExplorationBranchAttemptBase {
  id: string;
  runId: ExplorationRunId;
  stageAttemptRef: ExplorationSnapshotRef<"stage_attempt">;
  runFenceToken: string;
  frameId: string;
  frameHash: string;
  attempt: number;
  inputManifestHash: string;
  promptCompilerVersion: string;
  compiledSystemPromptHash: string;
  compiledUserPayloadHash: string;
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  revision: number;
  contentHash: string;
}

type ExplorationBranchAttempt = ExplorationBranchAttemptBase &
  (
    | {
        status: "succeeded";
        outputArtifactId: ArtifactId;
        outputArtifactHash: string;
        admittedOutputRef: AdmittedProviderOutputRef;
        invocationReceiptRef: ExplorationSnapshotRef<"invocation_receipt">;
        errorCode?: never;
      }
    | {
        status: "queued" | "running";
        outputArtifactId?: never;
        outputArtifactHash?: never;
        admittedOutputRef?: never;
        invocationReceiptRef?: ExplorationSnapshotRef<"invocation_receipt">;
        errorCode?: never;
      }
    | {
        status: "failed" | "cancelled" | "unknown" | "late_discarded";
        outputArtifactId?: never;
        outputArtifactHash?: never;
        admittedOutputRef?: never;
        invocationReceiptRef?: ExplorationSnapshotRef<"invocation_receipt">;
        errorCode?: string;
      }
  );

type ExplorationEvidenceStatus =
  | "references_manifest"
  | "tool_verified"
  | "requires_tool_verification"
  | "assumption"
  | "contradicted_by_manifest";

interface ProposedExplorationAssertion {
  id: string;
  text: string;
  kind: "fact" | "assumption" | "consequence" | "risk";
  proposedEvidenceSpanRefs: Array<{ id: string; spanHash: string }>;
  contentHash: string;
}

interface ScreenedExplorationAssertion {
  id: string;
  runId: ExplorationRunId | ExplorationDeepeningRunId;
  inputManifestHash: string;
  snapshotHash: string;
  ruleBundleHash: string;
  screeningPolicyHash: string;
  engineVersion: string;
  proposedAssertionRef: ExplorationRef<"proposed_assertion">;
  validatedEvidenceSpanRefs: Array<{ id: string; spanHash: string }>;
  status: ExplorationEvidenceStatus;
  explanationCodes: string[];
  contentHash: string;
}

interface ExplorationProposedClaimDelta {
  localId: string;
  subject: EntityRef;
  predicateId: string;
  value: TypedValue;
  modality: "desired" | "required" | "prohibited" | "possible";
  polarity: "positive" | "negative";
  sourceTextPath: string;
  contentHash: string;
}

interface ExplorationCandidateBase {
  id: string;
  runId: ExplorationRunId;
  branchAttemptRef: ExplorationSnapshotRef<"branch_attempt">;
  frameId: string;
  title: string;
  proposedAnswerOrApproach: string;
  conciseRationale: string;
  tradeoffs: string[];
  assertions: ProposedExplorationAssertion[];
  origin: "model_proposal";
  contentHash: string;
}

type ExplorationCandidate =
  | (ExplorationCandidateBase & {
      lane: "owner_decision";
      kind: "answer_option" | "assumption_challenge";
      proposedDecisionValue: TypedValue;
      proposedClaimDeltas: ExplorationProposedClaimDelta[];
    })
  | (ExplorationCandidateBase & {
      lane: "planning_handoff";
      kind: "planning_approach";
      proposedDecisionValue?: never;
      proposedClaimDeltas?: never;
    });

interface CandidateScreening {
  id: string;
  runId: ExplorationRunId;
  lane: ExplorationKind;
  inputManifestHash: string;
  snapshotHash: string;
  ruleBundleHash: string;
  engineVersion: string;
  candidateRef: ExplorationRef<"candidate">;
  verdict:
    | "eligible_for_comparison"
    | "hard_constraint_conflict"
    | "requires_tool_verification"
    | "exact_duplicate"
    | "invalid";
  ruleIds: RuleId[];
  conflictingClaimIds: ClaimId[];
  duplicateOfCandidateRef?: ExplorationRef<"candidate">;
  assertionScreeningRefs: ExplorationRef<"screened_assertion">[];
  checkResults: Array<{
    check: "schema" | "decision_schema" | "references" | "canonical_duplicate" |
      "explicit_hard_constraint" | "evidence_mapping";
    result: "pass" | "warn" | "fail";
    reasonCode: string;
  }>;
  explanationCode: string;
  contentHash: string;
}

interface ExplorationOptionBase {
  id: string;
  sourceCandidateRefs: ExplorationRef<"candidate">[];
  title: string;
  exactProposedAnswerOrApproach: string;
  summary: string;
  tradeoffs: string[];
  assertions: ProposedExplorationAssertion[];
  deterministicWarningCodes: string[];
  contentHash: string;
}

type ExplorationOption =
  | (ExplorationOptionBase & {
      lane: "owner_decision";
      kind: "owner_decision";
      proposedDecisionValue: TypedValue;
      proposedClaimDeltas: ExplorationProposedClaimDelta[];
    })
  | (ExplorationOptionBase & {
      lane: "planning_handoff";
      kind: "planning_approach";
      proposedDecisionValue?: never;
      proposedClaimDeltas?: never;
    });

interface OptionScreening {
  id: string;
  runId: ExplorationRunId;
  lane: ExplorationKind;
  inputManifestHash: string;
  snapshotHash: string;
  ruleBundleHash: string;
  engineVersion: string;
  optionRef: ExplorationRef<"option">;
  sourceCandidateScreeningRefs: ExplorationRef<"candidate_screening">[];
  assertionScreeningRefs: ExplorationRef<"screened_assertion">[];
  verdict:
    | "presentable"
    | "hard_constraint_conflict"
    | "requires_tool_verification"
    | "exact_duplicate"
    | "invalid";
  ruleIds: RuleId[];
  conflictingClaimIds: ClaimId[];
  explanationCodes: string[];
  contentHash: string;
}

interface ExplorationSynthesisBase {
  id: string;
  runId: ExplorationRunId;
  inputManifestHash: string;
  branchResultRefs: ExplorationSnapshotRef<"branch_attempt">[];
  candidateScreeningRefs: ExplorationRef<"candidate_screening">[];
  unknowns: string[];
  contentHash: string;
}

type ExplorationSynthesisLane =
  | {
      kind: "owner_decision";
      recommendationOptionRef?: never;
    }
  | {
      kind: "planning_handoff";
      recommendationOptionRef?: ExplorationRef<"option">;
    };

type ExplorationSynthesisOutcome =
  | {
      status: "complete" | "partial";
      admittedSynthesisOutputRef: AdmittedProviderOutputRef;
      optionRefs: ExplorationRef<"option">[];
      optionScreeningRefs: ExplorationRef<"option_screening">[];
      watchOuts: Array<{
        candidateRef: ExplorationRef<"candidate">;
        reason: string;
        source: "deterministic_constraint" | "model_critique";
      }>;
      synthesizerInvocationReceiptRefs: [
        ExplorationSnapshotRef<"invocation_receipt">,
        ...ExplorationSnapshotRef<"invocation_receipt">[]
      ];
      terminalInvocationReceiptRefs?: never;
      synthesisFailureCodes?: never;
    }
  | {
      status: "unranked_partial";
      admittedSynthesisOutputRef?: never;
      optionRefs: [];
      optionScreeningRefs: [];
      watchOuts: [];
      recommendationOptionRef?: never;
      synthesizerInvocationReceiptRefs?: never;
      terminalInvocationReceiptRefs: ExplorationSnapshotRef<"invocation_receipt">[];
      synthesisFailureCodes: [string, ...string[]];
    };

type ExplorationSynthesis = ExplorationSynthesisBase &
  ExplorationSynthesisLane & ExplorationSynthesisOutcome;

interface ExplorationDeepeningOfferBase {
  id: ExplorationOfferId;
  parentRunRef: ExplorationSnapshotRef<"exploration_run">;
  parentSynthesisRef: ExplorationRef<"synthesis">;
  optionRef: ExplorationRef<"option">;
  inputManifestRef: ExplorationRef<"input_manifest">;
  plannedRouteReceiptRef: ExplorationRef<"model_route_receipt">;
  egressPlanRef: ExplorationRef<"egress_plan">;
  budgetPolicyDefinitionRef: ExplorationRef<"budget_policy_definition">;
  budgetAvailabilityRef: ExplorationSnapshotRef<"budget_availability">;
  hardLimits: ExplorationLimits;
  expiresAt: string;
  controlHash: string;
}

type ExplorationDeepeningOffer = ExplorationDeepeningOfferBase &
  ExplorationCostedEstimate;

interface ExplorationDeepeningAuthorization {
  id: string;
  offerId: ExplorationOfferId;
  offerControlHash: string;
  ownerActor: ActorRef & { kind: "owner" };
  acceptedLimits: ExplorationLimits;
  acceptedCostControl: ExplorationCostControl;
  exactConfirmationArtifactId: ArtifactId;
  exactConfirmationArtifactHash: string;
  authorizedAt: string;
  controlHash: string;
}

type ExplorationDeepeningState =
  | "queued"
  | "running"
  | "reconciling"
  | "ready"
  | "outcome_unknown"
  | "cancel_requested"
  | "cancelled"
  | "failed"
  | "stale"
  | "superseded";

interface ExplorationDeepeningRun {
  id: ExplorationDeepeningRunId;
  parentRunRef: ExplorationSnapshotRef<"exploration_run">;
  parentSynthesisRef: ExplorationRef<"synthesis">;
  optionRef: ExplorationRef<"option">;
  inputManifestRef: ExplorationRef<"input_manifest">;
  authorizationRef: ExplorationControlRef<"deepening_authorization">;
  budgetReservationRef: ExplorationSnapshotRef<"budget_reservation">;
  routeReceiptRef: ExplorationRef<"model_route_receipt">;
  egressProjectionRef: ExplorationRef<"egress_projection">;
  policyHash: string;
  limits: ExplorationLimits;
  state: ExplorationDeepeningState;
  revision: number;
  fenceToken: string;
  currentStageAttemptRef?: ExplorationSnapshotRef<"stage_attempt">;
  stopReason?: "owner_cancelled" | "deadline" | "call_limit" |
    "token_limit" | "resource_limit" | "provider_failure" |
    "provider_outcome_unknown" | "containment_violation" |
    "secret_detected" | "egress_denied" | "authorization_revoked" |
    "policy_violation" | "input_changed" | "policy_changed";
  invocationReceiptRef?: ExplorationSnapshotRef<"invocation_receipt">;
  artifactRef?: ExplorationRef<"deepening_artifact">;
  screeningRef?: ExplorationRef<"deepening_screening">;
  settledUsageReceiptRef?: ExplorationRef<"usage_receipt">;
  createdAt: string;
  updatedAt: string;
  contentHash: string;
}

interface ExplorationDeepeningArtifact {
  id: string;
  deepeningRunId: ExplorationDeepeningRunId;
  admittedOutputRef: AdmittedProviderOutputRef;
  parentOptionRef: ExplorationRef<"option">;
  inputManifestHash: string;
  detailedAnalysis: string;
  assertions: ProposedExplorationAssertion[];
  additionalTradeoffs: string[];
  additionalRisks: string[];
  contentHash: string;
}

interface ExplorationDeepeningScreening {
  id: string;
  deepeningRunId: ExplorationDeepeningRunId;
  artifactRef: ExplorationRef<"deepening_artifact">;
  inputManifestHash: string;
  snapshotHash: string;
  ruleBundleHash: string;
  engineVersion: string;
  verdict: "presentable" | "hard_constraint_conflict" |
    "requires_tool_verification" | "invalid";
  ruleIds: RuleId[];
  conflictingClaimIds: ClaimId[];
  assertionScreeningRefs: ExplorationRef<"screened_assertion">[];
  explanationCodes: string[];
  contentHash: string;
}

type ExplorationSettledState =
  | "ready"
  | "partial"
  | "outcome_unknown"
  | "cancelled"
  | "failed"
  | "stale"
  | "superseded";

interface ExplorationUsageReceiptBase {
  id: string;
  policyHash: string;
  modelRouteReceiptRefs: ExplorationRef<"model_route_receipt">[];
  invocationReceiptRefs: ExplorationSnapshotRef<"invocation_receipt">[];
  providerRequestIds: string[];
  callsStarted: number;
  callsCompleted: number;
  inputTokens: number;
  outputTokens: number;
  estimatedCostMicros?: number;
  finalCostMicros?: number;
  quotaUnits?: number;
  accountingBasis: "provider_reported" | "broker_observed" |
    "reserved_maximum_due_to_unknown";
  unresolvedInvocationRefs: ExplorationSnapshotRef<"invocation_receipt">[];
  wallClockMs: number;
  contentHash: string;
}

type ExplorationUsageReceipt =
  | (ExplorationUsageReceiptBase & {
      runKind: "parent";
      preSettlementRunRef: ExplorationSnapshotRef<"exploration_run">;
      settledState: ExplorationSettledState;
    })
  | (ExplorationUsageReceiptBase & {
      runKind: "deepening";
      preSettlementRunRef: ExplorationSnapshotRef<"deepening_run">;
      settledState: Exclude<ExplorationSettledState, "partial">;
    });

type ExplorationDecisionSelection =
  | {
      disposition: "accepted" | "modified";
      selectedOptionRefs: [ExplorationRef<"option">];
    }
  | {
      disposition: "combined";
      selectedOptionRefs: [ExplorationRef<"option">,
        ExplorationRef<"option">, ...ExplorationRef<"option">[]];
    }
  | {
      disposition: "wrote_own";
      selectedOptionRefs?: never;
    };

interface OwnerDecisionExplorationLink {
  id: string;
  ownerDecisionRef: ExplorationRef<"owner_decision">;
  runRef: ExplorationSnapshotRef<"exploration_run">;
  synthesisRef: ExplorationRef<"synthesis">;
  selection: ExplorationDecisionSelection;
  deepeningArtifactRefs: ExplorationRef<"deepening_artifact">[];
  authority: "provenance_only";
  contentHash: string;
}

interface PlanningExplorationArtifact {
  id: string;
  intakeId: IntakeId;
  contractHash: ContractHash;
  snapshotHash: string;
  publicationReceiptRef: ExplorationRef<"intake_publication_receipt">;
  inputManifestHash: string;
  synthesisRef: ExplorationRef<"synthesis">;
  authority: "advisory_planning_context";
  createdAt: string;
  contentHash: string;
}
```

`OwnerDecisionExplorationLink` records how the owner reached an answer. It is a
separate append-only audit object and is excluded from `OwnerDecision.contentHash`,
`IntakeContract.semanticClosure`, `semanticClosureHash` and `contractHash`.
The authoritative semantic content remains the exact owner answer and the
claims subsequently shown, confirmed and admitted through normal NSI rules.
`None of these fit` and `Decide later` create no owner decision or link.
Each linked deepening artifact must belong to a current `ready` child with a
`presentable` screening, and its parent option must appear in that link's
selected option refs. A write-own link cannot attach deepening artifacts.

`PlanningExplorationArtifact` is always excluded from `IntakeContract`,
ratification and readiness hashes. When `/plan` receives it in a separately
labeled advisory section, its exact hash is included in the planner's
`ContextManifest` and plan provenance. It must be ignored when stale.

## 6. Hashing, identities and currentness

- WorkService mints every run, attempt, candidate, option and receipt identity.
  Model-supplied IDs are untrusted local keys and are remapped or rejected.
- Canonical hashes separately cover policy, registry, selected frames, input
  manifest, compiled prompts, each invocation, output artifact, candidate,
  screening result, synthesis and usage receipt.
- Stateful run, reservation, invocation and attempt interfaces represent
  immutable versioned snapshots. Every transition appends a WorkService event
  and a new `(id, revision, contentHash)` snapshot; it never edits bytes behind
  an existing hash. Consumers bind the exact revision/hash they observed.
- Transition references are directional and never hash-cycle. A usage receipt
  binds the immediately preceding `preSettlementRunRef`; the same atomic
  transition then creates the terminal run snapshot that points to that receipt
  and whose state equals `settledState`. Likewise, an allocation/intent binds a
  pre-allocation/pre-dispatch stage-attempt snapshot; the following attempt
  snapshot adds the intent ref. An invocation receipt binds the current
  pre-receipt attempt; only the following attempt snapshot adds the receipt ref.
  Neither side may reference the other object's same newly created revision.
- Semantic content hashes exclude timestamps, latency, price and display order.
  Offer/authorization `controlHash` values include the exact target and frozen
  manifest, expiry, planned provider/model/effort/region route, endpoint/account
  profile, data classes, redaction impact, provider data-handling/retention and
  egress receipts, immutable budget-policy definition, exact pre-reservation
  budget-availability revision, pricing snapshot or resource mode, hard limits
  and accepted limits. Every invocation projection must be a
  deterministic subset of those authorized egress plans. Execution,
  reconciliation and usage receipt hashes include actual timing, route and
  usage/cost outcome.
- Offer expiry is no later than the earliest manifest, route, pricing/quota,
  budget-availability, provider-data-handling or egress-plan expiry.
  Authorization atomically compare-and-set consumes that exact availability
  revision while creating the reservation; stale posture creates a new offer
  rather than silently refreshing one field.
- `ExplorationRef` is tagged by object kind. Mutable runs, reservations,
  invocations and attempts use `ExplorationSnapshotRef` with exact revision and
  content hash; generic untagged IDs cannot cross an authority boundary.
- Branch prompt bytes must be byte-identical after canonicalization except for
  the reviewed frame payload. Broker request/invocation identity is out-of-band
  and cannot alter the prompt bytes.
- Any relevant intake revision, question/hash, gap/hash, claim/hash,
  evidence/span hash, snapshot, repository commit, ontology, rule bundle,
  policy, frame registry, context compiler, immutable budget-policy definition,
  the run's own reservation/account eligibility, route capability, provider
  data-handling posture or authorized egress plan change makes the run `stale`.
  After reservation, unrelated aggregate-ledger revisions do not stale an
  active run. They are checked only when making another reservation;
  invocation allocations partition the active run's own versioned reservation
  and never debit aggregate availability again.
- A stale or superseded run cannot present an option-submission action. A late
  model response is retained only as diagnostic evidence and cannot reanimate
  it.
- Direct and option-backed answers serialize through one question-decision
  transaction. The first valid `recordOwnerDecision` commit wins; the loser
  receives the current decision/revision. If the winning decision is direct,
  WorkService atomically supersedes the exploration run. Intake never waits for
  optional brainstorming.
- A provider/model/effort/region or retention/egress destination not present in
  the authorized offer is not a fallback; it requires a new offer and owner
  authorization. Every invocation binds its exact provider-specific payload,
  redaction and egress projection.
- Currentness is enforced when an option-backed answer is admitted. Later
  exploration frame/model/policy drift may stale the run or provenance link but
  cannot retroactively invalidate an already admitted exact owner answer.
  Changes to semantic intake sources still follow ordinary NSI invalidation,
  independently of the exploration link.
- One current offer is single-use. `ExplorationAuthorizationConsumption` stores
  the exact `(offerId, offerControlHash)` under a database uniqueness constraint.
  A second constraint permits at most one active parent run for `(intakeId,
  intakeRevision, target hash, kind)` and at most one active deepening run for
  the exact `(parentRunRef, parentSynthesisRef, optionRef)`, regardless of offer
  identity. A new deepening attempt is possible only after the prior child is
  terminal and the owner confirms a fresh offer. Authorization consumption,
  aggregate budget reservation and queued-run creation commit in one
  serializable transaction; competing tabs receive the same run or a conflict,
  never a second provider dispatch.

## 7. Independent exploration state machine

Exploration state never changes `IntakeRunState` by itself:

```text
offer -> owner authorization -> atomic reservation + queued run
queued -> diverging -> screening -> synthesizing -> ready
                                      |
                                      +-> partial / failed

any dispatched stage --ambiguous provider result--> reconciling
reconciling --resolved + fence still current-------> prior legal work stage
reconciling --resolved + fence rotated-------------> terminal + late_discarded
reconciling --deadline/unsupported-----------------> outcome_unknown

any active state --owner cancel--> cancel_requested -> cancelled
cancel_requested --in-flight result ambiguous--> reconciling -> outcome_unknown
any active state --input/policy changes--------------> stale
any active state --owner answers directly------------> superseded
budget/deadline/containment/provider terminal failure-> partial or failed

ready option -> new deepen offer/authorization/reservation -> child deepen run
child: queued -> running -> reconciling -> ready | outcome_unknown
       queued/running -> cancelled | failed | stale | superseded
```

Here, `resolved` means an authoritative provider-request lookup or supported
idempotency result. Billing reconciliation may settle usage only; it never
makes uncertain output selectable, resumes a work stage or authorizes a retry.

`partial` means some valid artifacts exist, not that a safe recommendation
exists. Initial owner-decision UI treats partial, cancelled, critic-failed and
`unranked_partial` output as view-only and unranked. The owner may always answer
the original question directly.

State invariants are code-enforced:

- a run is created only after current authorization and reservation exist;
- policy enforces two-to-four options for the initial `owner_decision` profile
  and separately bounded approach counts for `planning_handoff`;
- parent `ready` requires a current `complete` same-lane synthesis, the lane's
  required branch/frame diversity, the lane's bounded number of outputs with
  enough current `presentable` post-synthesis screenings, and a settled usage
  receipt. Only `owner_decision` ready output exposes answer actions;
- `partial` requires the exact expected branch set plus terminal outcomes, a
  partial/unranked synthesis if one exists, a stop reason and settled usage;
- `failed`, `cancelled`, `stale` and `superseded` never expose an option-submit
  action;
- `reconciling` and `outcome_unknown` never expose an option-submit action;
  `outcome_unknown` requires a settled conservative usage receipt and leaves
  every unresolved provider output unusable;
- an `outcome_unknown` usage receipt uses
  `reserved_maximum_due_to_unknown` with non-empty unresolved invocation refs;
  ordinary ready/cancelled/failed receipts cannot hide unresolved invocations;
- active states cannot reference a settled usage receipt;
- a terminal snapshot's usage receipt binds exactly its immediately preceding
  run revision and declares that terminal snapshot's state; receipt and
  terminal snapshot are committed atomically without mutual same-revision
  hash references;
- each invocation consumes exactly one dedicated `ExplorationBudgetAllocation`;
  a database uniqueness constraint on the allocation reference in an
  invocation intent forbids reuse, and allocation plus durable intent creation
  is one atomic transaction;
- deepening is an immutable child run for exactly one option in the initial
  canary. It never mutates or replaces the parent synthesis; child `ready`
  requires a current artifact, deterministic schema/reference/explicit-
  constraint/evidence screening and a separate settled usage receipt;
- every provider-output branch, synthesis or deepening artifact used by `ready`
  or finalization has an exact `ProviderIngressAdmissionReceipt` whose
  disposition is
  `admitted`, invocation/raw/admitted hashes match and derived classification is
  the authorized inherited classification. Quarantined/rejected output is
  structurally ineligible for candidates, options, screening and presentation.

## 8. Narrow WorkService and runner operations

Owner/client-facing operations:

| Operation | Required behavior |
| --- | --- |
| `getExplorationOffer` | Code-owned eligibility plus a frozen least-context manifest, current route/data-handling/egress plans, estimate, hard currency-or-resource limits and expiry; no model call |
| `requestIntakeExploration` | Owner-only exact offer/hash/revision confirmation; reserves maximum permitted budget atomically |
| `cancelIntakeExploration` | Owner-only, monotonic and idempotent by exact run ID; an older observed revision cannot prevent safe stop. Atomically rotates the fence/revokes leases, stops new dispatch and returns current Stopping/terminal state. |
| `getIntakeExplorationProjection` | Sanitized current state, phase counts, estimate/actual usage, options and currentness |
| `requestExplorationDeepening` | Owner-only child run for one exact current ready option, with a fresh offer, authorization, reservation and cap |
| `getCurrentPlanningExploration` | Returns only a current published-contract-bound advisory artifact |

The existing `recordOwnerDecision` remains semantically unchanged: exact owner
answer, authentication, expected intake revision, exact question ID/content
hash and normal interpretation confirmation are required. When the owner uses
current options—or explicitly chooses **Write my own answer** from a current
ready panel—WorkService may atomically add a separate
`OwnerDecisionExplorationLink`. The server validates that the run is current and
`ready`, synthesis is `complete`, every selected option belongs uniquely to
that synthesis and each selected option's current post-synthesis verdict is
exactly `presentable`; `requires_tool_verification`, hard-conflict, duplicate
and invalid options are view-only. Disposition cardinality must be legal.
Partial/cancelled/outcome-unknown/stale/superseded output is rejected even if a
client bypasses disabled UI. A write-own answer from those states follows the
ordinary direct path without an exploration link. **None of these fit** returns
to direct answer; **Decide later** leaves the question blocked. Neither creates
a decision.

Controller-only, fenced operations:

| Operation | Required behavior |
| --- | --- |
| `leaseExplorationStageAttempt` | Current run/fence, one stage attempt, bounded lease and model route receipt |
| `reserveExplorationBudget` | Compare-and-set consume the offer's exact availability revision, enforce accepted limits against the immutable policy definition, and atomically reserve worst-case call/token/currency/quota capacity |
| `allocateExplorationInvocationBudget` | Atomically partition the existing reservation into one dedicated one-call allocation plus its durable intent; it never debits aggregate availability again, and exact binding plus a unique allocation reference prevent double dispatch/spend |
| `admitProviderEgressProjection` | Exact provider/stage payload, route, classification, redaction, egress and retention receipts |
| `recordExplorationInvocationIntent` | Persist exact run fence, stage lease, attempt, reservation allocation, route, egress, prompt/input hashes and stable provider idempotency identity before network transmission |
| `recordExplorationInvocation` | Bind the dispatched provider request/result to the pre-dispatch intent and unknown-outcome identity |
| `admitProviderOutput` | Fail-closed ingress DLP/classification receipt; WorkService emits `AdmittedProviderOutputRef` only for exact `admitted` results, while quarantine/rejection can never be represented as a downstream output |
| `reconcileExplorationInvocation` | Pair each method with its exact identity; provider lookup/idempotency may resolve an outcome, billing may settle usage only, and unsupported records remain unreconcilable. None authorizes an automatic replacement call. |
| `completeExplorationBranchAttempt` | Schema/reference validation, artifact hashes, usage and all-settled status |
| `recordCandidateScreening` | Deterministic screening bound to candidate/input/rule hashes |
| `recordOptionScreening` | Re-screen every synthesized option against its typed value/deltas and the exact current manifest/rules |
| `finalizeExplorationSynthesis` | Exact expected branch/terminal-failure set and settled usage. Complete/partial model output requires lane-specific bounds, screenings and exact admitted ingress; `unranked_partial` requires terminal failure refs/codes and zero options/admitted synthesis output. |
| `finalizeExplorationDeepening` | Fenced child run; exact admitted ingress receipt, immutable artifact plus current-context assertion/deepening screening for one option, separate usage and no parent-synthesis mutation |
| `markExplorationStale` | Server currentness calculation; caller cannot override |

Before the broker sends bytes, it revalidates the durable intent's current run
fence, exact stage-attempt snapshot and unexpired embedded lease, budget
allocation, authorized route and
egress plan. Cancel, stale and supersede atomically rotate the fence and revoke
leases. Old-fence results may settle usage only; they cannot enter screening or
synthesis.

Dispatch uses a compare-and-set from `prepared` to durable `dispatching` before
network transmission. A crash/restart observed at `dispatching` is an unknown
provider outcome, never permission to resend. The real provider idempotency key
is deterministically/HMAC-derived from immutable intent identity or retained by
encrypted broker-only reference; its hash alone is audit evidence, not recovery
material. Only provider-supported idempotent replay or status reconciliation
can resolve the ambiguity.

All mutations use the existing `MutationEnvelope`, authenticated server-derived
principal, idempotency key and canonical request hash. Owner operations other
than cancellation carry `expectedIntakeRevision`, the exact question
ID/content hash where relevant, and `expectedExplorationRevision` (or child
revision); they never overload one ambiguous revision. Cancellation is the
monotonic safety exception described above. Public request DTOs omit
server-stamped actor, IDs, timestamps and hashes; persistence records may show
those fields only after WorkService derives them from authenticated context. A
model receives none of these mutation APIs and no direct WorkService/SQL
credential.

## 9. Frame and prompt policy

Frames are reviewed perspective operators, not identities or authorities.
Initial versioned packs should cover:

- `owner_decision`: user outcome, simplest/reversible choice, failure/recovery,
  security/abuse, compatibility/migration and at most one clearly labeled
  assumption challenge;
- `planning_handoff`: simplicity/operability, security, compatibility,
  scale/performance, testing/recovery and at most one wildcard; and
- question-specific selection by materiality without arbitrary generated
  production frames.

Selection is deterministic from policy, target and input hashes and is recorded.
The original wording and every admitted constraint remain immutable inputs.
An assumption-challenge frame may ask what changes if an assumption is relaxed,
but its output must name that relaxation; it never replaces the question.

Branch calls are fresh, isolated and tool-free. Branches cannot see siblings,
the owner transcript beyond the compiled manifest, ambient project files,
credentials or provider/account controls. Provider system instructions and
untrusted repository/owner/model text use separate roles/data sections.

Prompts request concise structured outputs: proposed answer, short rationale,
assumptions, consequences, tradeoffs, risks and evidence references. They do
not request, store or display private reasoning traces.

## 10. Deterministic screening and advisory synthesis

Before any model comparison, code must:

1. validate schemas, sizes, exact run/branch references and ID uniqueness;
2. reject cross-run, missing, duplicate or invented references;
3. mark exact normalized duplicates deterministically; near-semantic duplicate
   clustering, if used, remains advisory and cannot silently delete a proposal;
4. test explicit known hard constraints and admitted owner decisions;
5. mark repository/feasibility claims that need tool verification; and
6. preserve every valid proposal and warning for disclosure.

Each candidate therefore supplies both concise prose and a typed proposed
decision value matching the current question's answer schema, plus proposed
claim deltas using known entity/predicate/value IDs. Code can deterministically
check only those explicit typed fields and exact normalized text. It must label
unmapped prose or semantic interpretation as requiring owner/tool review rather
than claiming to have proved it conflict-free.

Models submit `ProposedExplorationAssertion` only; they cannot assign
`tool_verified` or any other evidence verdict. Code resolves exact evidence
references and emits `ScreenedExplorationAssertion`. The aggregate UI status is
the most restrictive current server verdict in this order:
`contradicted_by_manifest`, `requires_tool_verification`, `assumption`,
`references_manifest`, `tool_verified`. Missing or mixed mappings never upgrade
an assertion.

A hard-constraint conflict cannot be presented as compliant. It may remain in
the expanded view as a labeled watch-out or assumption challenge. A model trap
label cannot delete a candidate.

For `owner_decision`, those typed values/deltas match the current question
schema. `planning_handoff` candidates and options use the discriminated
approach-only variant and cannot carry owner-decision values or semantic claim
deltas.

The synthesizer receives the complete identical input manifest plus all valid
branch artifacts and screening results. It returns no more than four
meaningfully distinct options for `owner_decision`. Numeric 0–10 confidence,
novelty, viability or fit scores are not shown or treated as calibrated.

Synthesis is another untrusted model output. Every resulting option is parsed
into the same typed value/claim-delta/assertion shape and receives a fresh
`OptionScreening` before presentation. Sol cannot launder a screened-out
conflict, unsupported fact or invented reference back into a selectable option.
An explicit hard conflict is never presented as compliant; a missing semantic
mapping is labeled, not inferred away. Final owner wording still passes normal
`recordOwnerDecision` admission and the complete NSI reasoner.

To reduce anchoring, the initial `owner_decision` view is neutral: no starred
winner and no recommendation placed before the alternatives. It shows the
options, evidence/assumption status and tradeoffs first. An optional advisory
analysis may be expanded after those options are visible. The owner always has
**Use this option**, **Combine options**, **Write my own answer**,
**None of these fit**, **Decide later** and, when separately authorized,
**Explore this option further**.

A complete `planning_handoff` synthesis may include one explicitly advisory
recommendation because it does not define product intent. `/plan` must still
compare it against the published contract and normal verification design.

Deepening is a separate child run on exactly one option per authorization in
the initial canary. It never overwrites the original option or synthesis and is
not automatically spent. Wider/deeper profiles require separate evaluation.

## 11. Budget, provider failure and cancellation

- The confirmation view leads with estimated time and the exact enforceable
  resource mode; route identities, calls and tokens are under Details. A
  currency-billed route is eligible for the initial canary only when a current
  conservative pricing snapshot and broker-enforced token maxima make its
  currency ceiling enforceable. `metered_quota` requires a current meter,
  mandatory unit and hard quota ceiling. `resource_only_subscription` states
  plainly that neither a dollar nor quota ceiling is available and relies on
  hard call/token/time/concurrency/retry limits. Every mode requires owner
  confirmation before model use.
- Price is an estimate. The completed view shows actual provider-reported usage
  and cost when available. Cancellation cannot refund completed or already
  accepted provider work.
- WorkService computes `offer.hardLimits` as the component-wise strictest
  ceiling from `ExplorationPolicy.limits`,
  `ExplorationBudgetPolicyDefinition.limits`, current availability and every
  route/provider limit. The compiled minimum-feasibility vector must fit those
  ceilings. Authorization then enforces, component by component,
  `compiledMinimum <= acceptedLimits <= offer.hardLimits`; a caller cannot raise
  or omit a required ceiling. All numeric limits are finite non-negative safe
  integers.
- Cost-control kind and unit identity are invariant across the immutable budget
  policy definition, availability receipt, offer, authorization, reservation
  and allocation. Currency mode preserves currency and
  pricing-snapshot identity with
  `accepted maxCost <= offer maxCost <= consumed availability remaining cost`;
  metered quota preserves quota unit/meter identity with the same ceiling
  ordering. Currency estimates are mandatory only for currency offers and
  absent from non-currency offers.
- Currency reservations require `reservedCostMicros` and forbid quota units;
  metered-quota reservations require `reservedQuotaUnits` and forbid cost;
  resource-only subscriptions forbid both fields. Missing provider-reported
  final usage never becomes zero; unknown outcomes use the authorized reserved
  maximum as their conservative accounting basis.
- Reserve atomically against a versioned aggregate ledger covering owner,
  repository/account and rolling period, including concurrency and remaining
  call/token/currency/quota capacity. Authorization is single-use; reservation,
  authorization consumption and queued-run creation share one serializable
  transaction/lock. That transaction consumes the exact availability revision;
  later unrelated ledger activity cannot invalidate the resulting reservation.
- Debit aggregate availability exactly once when the authorization transaction
  creates the worst-case reservation. Before each parallel dispatch, partition
  that reservation into a dedicated allocation; do not debit the aggregate
  ledger again. Refuse dispatch if the reservation's unallocated remainder
  cannot cover it.
- Allocation, intent and attempt must bind the same exact run identity, stage,
  fence, stage-attempt snapshot and reservation snapshot. Component-wise sums
  of all non-released allocations may never exceed the reservation. Terminal
  settlement consumes observed/maximum-unknown usage, releases unused capacity
  and closes both every allocation and its reservation exactly once.
- Enforce per-call and cumulative call, input/output token, enforceable
  cost/quota, wall-clock, concurrency and retry caps
  before every dispatch. Owner confirmation never overrides repository egress
  or security policy.
- Persist each branch independently and use all-settled semantics. One failure
  never deletes successful branch artifacts.
- A parse/schema failure is a typed failed attempt. Every real retry uses a new
  stage attempt/request key, counts against every cumulative limit, honors
  `Retry-After` plus bounded exponential backoff/jitter and cannot exceed the
  stage/run deadline. Reuse a provider idempotency identity only to reconcile
  an unknown request when the route receipt proves that behavior. Never retry
  policy/secret/egress denial, cancellation, staleness or permanent refusal,
  and never silently change the model/effort.
- Require the code-owned minimum successful branch and distinct-frame count
  before synthesis. Below it, fail honestly.
- A synthesis failure yields a controller-generated `unranked_partial` summary
  with terminal invocation/failure refs and zero options; no admitted synthesis
  output, fake ordering or option-submission button appears.
- Cancel stops queued/new work immediately. In-flight requests receive
  cancellation where supported. Later results are `late_discarded` and cannot
  enter synthesis.
- Retries and unknown outcomes consume reservation until reconciliation proves
  otherwise. Reservation expiry blocks new dispatch but never releases capacity
  behind an unresolved invocation. Unknown provider outcomes use authoritative
  provider lookup or supported idempotency results when available. Billing data
  may settle accounting but cannot admit output or resume work. If the provider
  supports no authoritative outcome lookup, the invocation receipt remains
  `unknown`.
  After the policy's reconciliation deadline, WorkService settles accounting
  conservatively at the reserved maximum, records
  `reserved_maximum_due_to_unknown`, marks the run `outcome_unknown` and keeps
  every uncertain output unusable. A replacement is never automatic: it needs
  a fresh current offer and owner confirmation that warns of possible duplicate
  currency charge, quota use or subscription use. Restart resumes unfinished
  durable stages, not transcripts.

## 12. Initial model routing

The first evaluation candidate uses OMP roles, not hard-coded provider SDKs:

```yaml
intake_explore_generate: google-antigravity/gemini-3.7-flash:medium
intake_explore_critic: openai-codex/gpt-5.6-sol:high
intake_explore_deepen: kimi-code/k3-256k:high
```

- Fable-high remains the owner-facing interviewer. Web/CLI deterministically
  render typed synthesis/options without another model call or reordering.
- Four fresh Flash-medium branches are the first standard-profile candidate;
  their reviewed frames provide divergent perspectives.
- A fresh Sol-high synthesis sees the complete frozen manifest and all valid
  branch artifacts.
- K3-256K-high deepening is separately owner-requested and starts fresh under
  its no-resume/no-compaction policy.
- Keep all three roles outside `cycleOrder`.
- The initial canary has no automatic cross-model fallback: an unavailable
  route yields honest unavailable/partial/failed state. Any later fallback is a
  separately qualified, recorded new attempt that preserves generator/critic
  family separation; silent model substitution is forbidden.
- Model agreement and cross-family criticism remain heuristics. Exact route,
  width, frame and budget defaults are promoted only from `NSI-E4` results.

Opus remains reserved for fresh implementation audit rather than becoming an
intake exploration voter. The deterministic intake reasoner continues to own
readiness.

## 13. OMP Web and CLI experience

An eligible question card may show a secondary **Explore alternatives** action.
The normal direct-answer control remains primary. CLI status/cancel always print
the exact target question and run ID before acting; if more than one run could
match, OMP asks instead of guessing “latest.” An expired or changed offer is
refreshed and shown again—it never starts under a new route, price or limit
without reconfirmation.

Before starting, lead with a plain summary such as the dynamically generated
`About 1–3 min · estimated $X–$Y · maximum $Z` (illustrative values only), then
show:

- plain-language purpose and target question;
- estimated time/cost and enforceable maximum spend or usage;
- the number of perspectives and a statement that further detail is not
  included and never starts automatically;
- under Details, provider account/destination/region, sent data classes,
  training use, cache mode/duration, retention duration, deletion support,
  route identities, calls/tokens, frozen-source identity and budget source; and
- one explicit **Run exploration** confirmation. A metered-quota route says
  `Uses quota · maximum Q units · N calls / M tokens / T minutes`. A
  resource-only subscription says `Uses subscription · dollar and quota limits
  unavailable · maximum N calls / M tokens / T minutes`. Both require the same
  explicit confirmation as a currency-billed route.

Progress uses truthful phases and counts, never a fake percentage:

| Internal state | User label |
| --- | --- |
| `queued` | Preparing |
| `diverging` | Exploring n of N perspectives |
| `screening` | Checking constraints |
| `synthesizing` | Comparing alternatives |
| `reconciling` | Checking provider result |
| `ready` | Alternatives ready |
| child `queued/running/reconciling` | Preparing detail / Adding detail / Checking provider result |
| `partial` | Incomplete exploration |
| `outcome_unknown` | Provider result unknown |
| `cancel_requested` | Stopping |
| `cancelled` | Exploration cancelled |
| `failed` | Exploration failed |
| `stale` | Outdated |
| `superseded` | No longer needed — answered directly |

The browser may disconnect and reconnect to the durable run. Cancel displays
**Stopping** until server terminal evidence exists. Completion, failure,
cancellation, Provider result unknown or Outdated status updates the same
question card and Needs You item; it never creates a second queue item.
Notifications deduplicate on intake/question/run. Incomplete, failed,
cancelled, Provider result unknown and Outdated views offer **Write my own
answer** and, when legal, **Run exploration again**; Outdated also names what
changed. Every rerun fetches a fresh current offer and requires a new limits
confirmation. While lookup remains possible, show **Keep waiting**. A Provider
result unknown view separates known provider-reported usage from a mode-specific
warning: currency says `Provider charge/usage unknown · OMP is counting up to
$Z against your limit until reconciled`; metered quota says `Provider usage
unknown · OMP is counting up to Q units against your quota limit until
reconciled`; resource-only subscription says `Provider usage unknown · OMP is
keeping the authorized N calls / M tokens / T minutes encumbered until
reconciled; a replacement may duplicate subscription usage`.
**Authorize a replacement call** is available only through a fresh offer with
the matching possible duplicate currency, quota or subscription-use warning.

The ready owner-decision view defaults to two to four neutral options with
tradeoffs, risks, evidence/assumption labels and watch-outs. The full branch set
is an accessible collapsed disclosure, not a required graph canvas. Generated
Markdown, HTML, SVG, ANSI, links and command text are hostile data and are
sanitized. No raw prompt, chain-of-thought, provider trace or credential is
rendered.

**Use this option**, **Combine options** or **Write my own answer** opens an
exact-answer preview. Only a second explicit
confirmation invokes `recordOwnerDecision`. Selecting the card alone changes
nothing. **None of these fit** returns to writing an answer and creates no
decision; **Decide later** leaves a critical question blocked. Partial,
cancelled, Provider result unknown or Outdated output is readable as incomplete
notes but cannot be submitted. A free-form direct answer always remains
available.

If the owner answers while calls are active, show: `Answer now and stop
exploration? Calls already sent may still finish and consume money, quota or
subscription usage.`
The first valid serialized decision commit wins; a winning direct answer
atomically supersedes the run and prevents every late result from becoming
selectable.

Remote start/view/cancel/deepen/select is available only through the OWEB-7
`WORK_OWNER` Work/Intake BFF after `N4`. It uses owner scope, current revision,
CSRF and the budget capability. The browser cannot choose raw prompts, frames,
models, provider endpoints, backend paths or tools. The BFF never runs branches
or holds provider credentials. A privacy-safe notification says only
“Exploration ready” and deep-links to the authenticated Work/Intake origin.

For the initial remote policy, cancel never requires step-up. Start and
**Explore this option further** require the owner capability and exact preview;
recent authentication is required only when session assurance is stale or the
server's budget/risk threshold requires it. Option submission uses normal
owner-decision authentication, while ratification keeps its existing stronger
step-up policy.

Mobile/accessibility acceptance includes keyboard-only operation, semantic
heading/disclosure lists, visible-text currency/resource-limit information, focus restoration,
focus to an error summary after failed confirmation, polite live-region phase
announcements, color-independent status, contrast/reduced-motion, at least
44-by-44 CSS-pixel touch targets, safe areas and virtual-keyboard behavior.

## 14. Security and privacy controls

- Compile least-context manifests from admitted data; do not forward an entire
  transcript or repository by convenience.
- Apply repository/provider egress policy, secret scanning and deterministic
  redaction before any model dispatch. Either compile one intersection-safe
  payload approved for every authorized route or create stage/provider-specific
  projections. Every invocation binds exact provider-bound bytes, destination/
  region, route, data classes, redaction/egress receipts and retention policy.
- Before authorization, bind current `ProviderDataHandlingReceipt` and
  `ExplorationEgressPlan` records covering account/endpoint/region, training
  use, zero-retention status, cache mode, actual retention/deletion behavior,
  input classes and redaction impact. Unknown or incompatible required posture
  fails closed. A dispatched payload must be a deterministic subset of the
  authorized plan; any expansion requires a new offer.
- Data-handling durations are finite non-negative integers. Verified zero data
  retention requires an exact zero; non-ZDR retention and enabled provider cache
  require explicit positive durations. Unknown training, retention, caching or
  deletion posture is representable for audit but ineligible whenever policy
  requires a known compatible posture. Internally inconsistent provider claims
  fail closed rather than being normalized.
- Derived content inherits the union/highest sensitivity of every input plus
  new DLP findings. Flash output sent to Sol or K3 therefore cannot be
  reclassified downward merely because a model rewrote it. Every downstream
  provider must be authorized for the inherited classes. A newly detected class
  outside the preauthorized downstream plan blocks that dispatch and requires a
  fresh offer; it is never silently downgraded or added after confirmation.
- Redaction receives a semantic-impact receipt. If it touches material owner
  wording, constraints, non-goals or deciding evidence, block exploration and
  ask for a safe replacement through ordinary intake; never silently explore a
  materially altered question.
- Provider credentials remain in the OMP broker. Branch/synthesis/deepening
  processes have no ambient secrets, filesystem, shell, SQL, WorkService,
  GitHub, deployment or unrestricted network capability.
- Treat owner text, repository content, external evidence and all model output
  as untrusted data. None can alter system policy, frame registry, routing,
  budget, schema or authority.
- Bound arrays, strings, nesting, artifacts, decompression and rendered output.
  Validate exact cardinality and unique references after parsing.
- Run fail-closed broker-ingress secret/DLP/classification checks before model
  output is persisted beyond quarantine, forwarded, logged or rendered. Only an
  admitted output artifact can enter screening or synthesis. Scanner failure
  blocks; raw quarantine, if retention is necessary, is encrypted,
  least-privilege, metadata-only in logs and short-lived.
- Store concise artifacts and usage/provenance, not hidden reasoning. Apply
  configured retention/deletion policy without deleting the authoritative
  owner decision. Encrypt and ACL provider payload/output artifacts at rest;
  deletion emits receipts/tombstones and covers derived indexes, caches and the
  documented backup-retention boundary while preserving non-sensitive hashes
  and audit metadata.
- Remote authorization, budget spending and data egress are server-side
  capabilities. A hidden/disabled button is not enforcement.

## 15. Mandatory tests

Authority and semantics:

- model output attempts owner impersonation, claim admission, rule changes,
  waiver, READY, receipt, publication or lifecycle mutation;
- viewing, not selecting, **Use this option**, **Combine options**, **Write my
  own answer**, **None of these fit** and **Decide later** paths;
- unselected options do not become rejected claims or non-goals;
- owner confirms exact final wording before decision admission;
- candidate rationale/assumptions do not enter the semantic contract;
- `OwnerDecisionExplorationLink` is absent from owner-decision semantic hashes
  and two identical exact answers yield the same contract hash with or without
  exploration;
- `planning_handoff` cannot satisfy a gap or enter a contract hash;
- model scores, consensus and recommendations cannot affect readiness.

Context, injection and currentness:

- branch manifests differ only by reviewed frame payload;
- no branch sees sibling output during divergence;
- critic and deepener receive the complete frozen manifest;
- candidate, synthesized option and deepening outputs each receive their own
  exact-manifest typed screening; synthesis cannot reintroduce a selectable
  explicit conflict;
- a synthesis timeout/refusal/no-bytes failure creates only an
  `unranked_partial` controller summary with failure receipts/codes and zero
  options; it cannot forge an admitted synthesis output;
- every screened assertion binds the exact run, manifest, snapshot, rule bundle,
  screening policy and engine; stale or cross-context screenings are rejected;
- owner/repository/model text attempts to change prompts, reveal secrets,
  invoke tools, weaken constraints or alter budgets;
- canary secrets never appear in provider requests, outputs, logs or UI;
- provider-output DLP scanner failure/quarantine, encrypted short retention and
  proof quarantined bytes never reach a downstream stage or browser;
- branch, synthesis and deepening finalization reject missing, mismatched,
  quarantined or rejected ingress receipts, including hash/classification drift;
- input-to-derived classification inheritance across Flash, Sol and K3,
  including attempted cross-provider sensitivity downgrade/laundering;
- provider account/endpoint/region/training/cache/retention/deletion policy
  expiry or drift, and provider payload expansion beyond the authorized plan;
- redaction of a material question/constraint/evidence span blocks rather than
  silently changing semantics;
- snapshot, repository commit, question, gap, claim, evidence, rules, ontology,
  policy or frame registry changes during every stage;
- stale, cross-run, duplicate, omitted, unknown and forged IDs/hashes;
- offer authorization binds exact provider/model/effort/region routes; route or
  destination change requires a new offer and confirmation;
- direct and option-backed answers race through one serialized transaction;
  exactly one wins, and a winning direct answer supersedes the run atomically.

Budget, provider and recovery:

- duplicate starts from two tabs, single-use-offer uniqueness and same-key
  replay/different-body rejection;
- two concurrent deepening offers for one exact parent run/synthesis/option
  produce at most one active child, regardless of offer identity;
- concurrent or replayed intents cannot reuse one budget allocation; allocation
  and durable intent creation either both commit or neither commits;
- authorization debits aggregate availability once; invocation allocations
  only partition that reservation, their non-released component sums never
  exceed it, and terminal settlement releases unused capacity exactly once;
- cross-run, cross-stage, cross-attempt, wrong-fence or wrong-reservation
  allocation/intent bindings are rejected before dispatch;
- authorization compare-and-set consumes the exact availability revision;
  reservation creation does not stale its own run and an unrelated ledger
  reservation does not stale an already reserved run;
- currency, metered-quota and resource-only reservation/allocation unions reject
  missing, extra or wrong-unit encumbrance fields;
- cancellation from a stale browser revision still atomically fences new
  dispatch and returns the current Stopping/terminal projection;
- individual timeout, 429, refusal, malformed output and provider disappearance;
- retry classification, `Retry-After`, bounded backoff/jitter, cumulative-limit
  accounting and no retry after permanent/policy/secret/egress/stale/cancel;
- unknown provider outcome followed by restart/reconciliation;
- reconciliation rejects every mismatched method/identity/outcome combination;
  billing-only usage can settle accounting but never admits output, resumes a
  work stage or permits automatic retry;
- crash after durable `dispatching` but before a provider response never causes
  an automatic resend; only supported status/idempotency reconciliation may
  resolve it;
- screening, synthesis and deepening failures after successful branches;
- call/token/cost/deadline exhaustion before and during fan-out;
- cancel while queued, running, synthesizing and deepening;
- late provider response after cancel, staleness or supersession;
- reconciliation after a rotated fence settles usage and records
  `late_discarded`; it never resumes the prior work stage;
- process crash between every state transition and no duplicate automatic model
  call; providers without lookup/idempotency stop at `unknown` until a new
  owner-authorized replacement;
- usage/terminal-run and stage-attempt/invocation transitions have directional
  previous-revision references and no same-revision content-hash cycles;
- estimate/pricing drift; currency never exceeds a broker-enforced currency cap;
  non-currency routes obey call/token/time limits, and metered-quota routes also
  obey their quota limit;
- minimum branch/diversity threshold and honest partial behavior.
- component-wise accepted/offer/policy limit enforcement, and every retry or
  unknown outcome remains reserved until reconciled.

Web/security/accessibility:

- cross-principal/repository/session start, read, cancel, deepen and select;
- missing/forged Host, Origin, CSRF, recent-auth where required, budget
  capability, expected revision and idempotency identity;
- confirmation Details disclose the exact provider account/destination/region,
  data classes, training use, cache mode/duration, retention duration and
  deletion support that are bound into authorization;
- hostile Markdown/HTML/SVG/ANSI/link/control-character/payload output;
- proof browser/BFF cannot submit raw prompts, select providers/frames, invoke
  tools or access credentials/routes outside Work/Intake;
- reconnect/out-of-order events and outdated option submission disabled;
- complete keyboard, screen-reader, contrast, reduced-motion, touch and mobile
  flows.

## 16. Evaluation and promotion

Do not reuse the upstream marketing scores. `NSI-E4` adds a frozen,
owner-involved experiment after base NSI qualification:

| Arm | Configuration |
| --- | --- |
| X-A | Qualified neuro-symbolic intake, no generated alternatives |
| X-B | One Sol-high alternatives pass |
| X-C0 | Four unframed Flash-medium branches plus the identical Sol-high synthesis and matched limits |
| X-C | Four isolated Flash-medium framed branches plus the same Sol-high route, prompt and limits as X-C0 |
| X-D | X-C plus a randomized deepening offer; report intention-to-treat and the self-selected use cohort separately |

Use identical frozen `ExplorationInputManifest` data, pinned route identities
and explicit call/token/currency-or-resource reporting. X-C0 isolates reviewed frames
from width, parallelism and compute; also report matched-token X-B comparisons
so extra spend is not mistaken for architectural value. Include historical
architecture, API/UX, migration, security and ambiguous-behavior decisions;
canonical/closed negative controls; and seeded attractive traps. Repeat a
representative stochastic subset. Use a pilot only to set sample size,
non-inferiority margins, selector/frame tuning and non-safety thresholds; then
freeze a separate holdout qualification corpus. Randomize option order,
normalize presentation length, hide arm identity from reviewers where
practical, record the owner's unaided initial choice before revealing
alternatives, and predeclare missing/abandoned-run handling.

Measure:

- material viable options found and actually selected;
- critical conflicts incorrectly presented as compliant/selectable/admitted,
  unsupported factual claims and misleading traps; raw labeled/rejected
  assumption challenges are not themselves a safety failure;
- owner corrections, decision reversals, time, confidence and abandonment;
- later plan revisions, implementation rework and downstream audit findings
  attributable to the decision;
- duplicate/noisy branches and eligibility-offer precision;
- calls, tokens, actual cost, latency, cancellation and provider failures; and
- intake false-ready, critical omissions and provenance closure.

Promotion requires zero authority, containment, secret/egress, currentness,
fencing, idempotency or limit-enforcement violations; zero critical conflicts
presented as compliant, exposed as selectable or admitted into owner/semantic
state; zero option submission after staleness; preregistered non-inferiority on
false-ready, critical omissions, provenance closure and owner-correction
burden; stable material benefit over X-A and an equal-compute control;
owner-confirmed currency/resource limit compliance; and proven rollback.
Calibrate non-safety benefit/cost thresholds from the pilot, then judge only
the frozen holdout.

Rollout:

1. offline historical evaluation under an explicit owner-approved corpus,
   provider/egress policy and aggregate study budget;
2. offer-only live selector shadow with no model call, provider egress or cost;
3. manual explicit local **Explore alternatives** canary during NSI-E4;
4. contextual no-cost offers and owner-confirmed local runs after `N4`;
5. private remote canary only after both `N4` and OWEB-7; and
6. automatic usage-consuming execution remains prohibited unless a later owner-ratified
   program establishes a preauthorized budget, egress policy and clear outcome
   advantage.

Base NSI cutover and Fleet eligibility do not depend on `N4`. Failure to prove
exploration value removes or leaves the extension manual; it does not block the
reliable intake path.

## 17. Program decomposition

Add these optional children to the NSI program without changing the hard
`SQL-0 -> NSI-1..6 -> FLEET-1` sequence:

```text
NSI-1 + NSI-2 + NSI-3 -> NSI-E1 exploration contracts and policy
NSI-E1 + NSI-4        -> NSI-E2 bounded runner, screening and synthesis
NSI-E2 + NSI-5        -> NSI-E3 owner decision, CLI and generated Web contracts
NSI-E3 + NSI-6        -> NSI-E4 shadow evaluation and opt-in promotion
NSI-E3 + OWEB-4       -> local Web client fixtures
NSI-E4 + local client -> manual local canary
NSI-E4 proof          -> N4 owner-confirmed exploration gate
N4 + OWEB-4 client    -> normal local Explore alternatives UI
N4 + OWEB-7           -> remote Explore alternatives UI
```

### NSI-E1 — Contracts, policy and frame registry

Define every type/hash/currentness/authority rule in this document, reviewed
frame packs, eligibility policy, limits, route manifests, schema evolution and
compatibility fixtures. Produce a reuse/retirement inventory of current OMP,
WorkService and planned Fleet dispatch/lease/event/budget/reconciliation
primitives. Implement or extract one shared generic bounded-model-job substrate;
CI must reject an exploration-only second scheduler/control plane.

### NSI-E2 — Durable bounded execution and advisory synthesis

Implement the manifest compiler, brokered isolated branches, all-settled
attempt ledger, deterministic screening, synthesis/deepening, reservations,
cancellation, staleness, recovery, usage receipts and containment tests.

### NSI-E3 — Owner decision, CLI and generated Web contracts

Implement offers, per-run confirmation, CLI, generated OMP Web projections and
fixtures, neutral options, exact-answer confirmation, source provenance,
planning handoff and accessibility. Preserve the direct-answer path. The
`omp-webui` OWEB-4 sub-lane owns the native local client; NSI-E4 owns its manual
canary and N4 gates normal activation.

### NSI-E4 — Evaluation and promotion

Implement X-A, X-B, X-C0, X-C and X-D; negative controls; offer-only shadow and
explicit canary rollout; selector precision; owner/outcome/currency-or-resource
measures; rollback; and `N4` evidence. Remote UI consumes the qualified
contracts only after `N4` and OWEB-7.

## 18. Licensing and attribution

The inspected upstream repository is MIT-licensed. Reimplementing the general
method does not justify adding its runtime dependency. If implementation copies
prompt/frame wording, schemas or substantial source, add the upstream copyright
and full MIT permission notice to OMP's `THIRD_PARTY_NOTICES`, pin the copied
source commit and record it in dependency/SBOM inventory. NSI-E1 acceptance and
CI must fail when copied material lacks that notice, pinned provenance or SBOM
entry. Documentation should say “adapted from UditAkhourii/adhd” without
implying endorsement.

## 19. Explicit non-goals

- no default, recursive, self-authorizing or unbounded intake swarm;
- no general brainstorming service or remote prompt shell;
- no automatic problem/constraint rewriting;
- no model-owned eligibility, owner intent, claims, rules, readiness or state;
- no direct `adhd-agent`/Claude Agent SDK runtime dependency;
- no visible numeric confidence or vote as truth;
- no raw/private chain-of-thought capture, storage or display;
- no automatic deepening or usage-consuming execution in the initial release;
- no conversion of unselected options into non-goals;
- no requirement that Fleet, `/plan` or ordinary intake wait for exploration;
- no use in deterministic verification or independent final audit; and
- no claim that more ideas, model agreement or a polished synthesis improves
  coding outcomes until local evaluation demonstrates it.

## 20. Repository-dependent implementation decisions

`NSI-E1` resolves these from live code and provider telemetry without weakening
the contract:

- exact schema/module/table/event names and generated-client mechanism;
- exact current pricing/usage receipt sources and reservation implementation;
- calibrated standard/deep branch, token, wall-clock and cost profiles;
- frame-pack wording and selector implementation;
- data-classification/egress policy bindings and artifact retention;
- minimum successful branch/diversity count;
- route fallbacks that preserve model-family and attempt independence; and
- non-safety promotion thresholds after pilot variance is known.

No unresolved item above permits implementation to omit a hard maximum,
authorization, currentness binding, deterministic screening, containment or
owner confirmation.
