# Model, agent and harness operating policy

This is an operating/configuration checklist, not another program intake.

## Current status and central doctrine

At the inspected `oh-my-pi` HEAD, the fork already has automatic `/intake`
routing, a fail-closed fresh-context `/summary` auditor, native `/plan`
handoff, task-agent discovery, bounded/isolated agents, `/agents`, Agent Hub and
advisors.

Do not rebuild the command/bookend semantics. Expose the same commands, session
identity, model inventory and policy through official OMP Web without creating
a second agent runtime or authority. After SQL-0, harden `/intake` first through
NSI-1–NSI-6: the models propose claims and questions, WorkService stores
provenance and decisions, the deterministic reasoner owns pre-ratification
assessment, the owner ratifies meaning, and WorkService revalidates, mints the
current positive receipt and publishes. Then harden execution through the Fleet program with
machine-owned evidence, real containment, task-specific context, evaluation and
a separately versioned harness package.

The 2026-08-16 model-policy revision treats the user's Vivace-backed Kimi Code
access as a first-class production resource. K3 is no longer a vague deep
alternate. It becomes the normal fresh-session fleet worker for standard
multi-file work, the large-context worker for repository-wide work, and the
bounded Engineering Manager reasoning model. It does not become the current
mixed-model interactive `default`, its own auditor, or a source of lifecycle
authority.

Important qualification: the existing auditor is fresh-context and semantically
non-repairing, but a prompt saying “read-only” plus general `bash` under
headless/yolo execution is not mechanical immutability. Do not describe it as a
security boundary until filesystem, process, network, credential and tool
restrictions are proven.

Guiding doctrine:

> Models produce interpretation proposals, judgment, plans and code. The owner
> ratifies product meaning. The harness owns state, context provenance,
> evidence, permissions, execution boundaries and legal truth claims.

Evidence:

- [model-bookends extension](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/session-system/extensions/model-bookends.ts)
- [auditor definition](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/session-system/agents/auditor.md)
- [task-agent discovery](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/docs/task-agent-discovery.md)
- [Agent Hub](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/docs/agent-hub.md)

## Current preferred routing

Resolve exact provider selectors with the installed `/models` inventory. Pin
snapshots where supported rather than relying on moving aliases.

```yaml
modelRoles:
  # Current interactive owner-session routes
  default: google-antigravity/gemini-3.7-flash:high
  intake: anthropic/claude-fable-5:high
  intake_explore_generate: google-antigravity/gemini-3.7-flash:medium
  intake_explore_critic: openai-codex/gpt-5.6-sol:high
  intake_explore_deepen: kimi-code/k3-256k:high
  plan: openai-codex/gpt-5.6-sol:high
  advisor: openai-codex/gpt-5.6-sol:high

  # Fresh fleet-stage K3 routes
  fleet_plan: kimi-code/k3-256k:high
  fleet_worker: kimi-code/k3-256k:high
  fleet_long: kimi-code/k3:high
  fleet_max: kimi-code/k3:max
  fleet_manager: kimi-code/k3:high

  # Cross-family escalation and review
  high_worker: openai-codex/gpt-5.6-terra:high
  slow: openai-codex/gpt-5.6-sol:xhigh
  audit: anthropic/claude-opus-5:high

  # Cheap supporting work
  task: google-antigravity/gemini-3.7-flash:medium
  smol: google-antigravity/gemini-3.7-flash:low
  commit: openai-codex/gpt-5.6-luna:low
  tiny: google-antigravity/gemini-3.1-flash-lite

cycleOrder:
  - smol
  - default
  - high_worker
  - slow
```

| Function | Initial route | Policy |
| --- | --- | --- |
| Intake interview/candidate extraction | Fable high | Owner-facing interpretation, neutral question wording and candidate ACs; cannot admit claims or set assessments/receipts |
| Intake alternate/scout | Fresh K3-256K high; full K3 only for capacity | Read-only alternate interpretation, formalization proposal, topology and unknowns; never admits or ratifies |
| Intake exploration generation | Four fresh Flash medium branches as initial canary | Owner-confirmed, isolated, tool-free, identical frozen manifest plus one reviewed frame; proposal only |
| Intake exploration synthesis | Fresh Sol high as initial canary | Sees complete frozen manifest and all screened branches; neutral comparison, no readiness/owner authority |
| Intake exploration deepening | Fresh K3-256K high, separately owner-requested | Exactly one current option per authorization in the initial canary, separate currency-or-resource preview and limits; advisory and no resume/compaction |
| Intake admission/pre-ratification assessment | Deterministic NSI reasoner | Code-owned ontology, rules, conflicts, gaps, coverage and `READY_FOR_RATIFICATION`/failure assessment |
| Intake semantic authority | Owner | Decisions, waivers and exact contract-hash ratification |
| Intake receipt/publication | WorkService after revalidation | Mint `ELIGIBLE_FOR_PUBLICATION` only, bind required formal properties, then perform the explicit publish transition |
| Interactive planning | Sol high | Current native owner command; cross-file architecture, invariants and verification design |
| Fleet standard planning | Fresh K3-256K high | Typed plan stage; high/critical work escalates to Sol |
| Low/local implementation | Gemini 3.7 Flash high | Fast interactive or trivial fleet edit/tool loop |
| Standard multi-file implementation | Fresh K3-256K high | Primary fleet volume lane after K3 qualification |
| Repository-wide/long implementation | Fresh K3 1M high | Capacity route when compiled context/tool trajectory may exceed 256K |
| Exceptional long-horizon attempt | Fresh K3 1M max | New recorded attempt; never raise effort in place |
| High-risk implementation | Terra high | Stronger worker under hardened containment |
| Critical/stuck implementation | Sol xhigh | Qualified critical work or repeated failure |
| Boundary advisor | Sol high | Event-triggered advice only; no transition authority |
| Final acceptance audit | Fresh Opus 5 high | Cross-family, evidence-bound and mechanically immutable |
| Cheap scout/task | Gemini 3.7 Flash medium/low | Clear bounded read-oriented delegation |
| Engineering Manager | Fresh K3 1M high | Typed bounded portfolio proposals; max only for scheduled deep synthesis |
| Adjudication | Third family relative to worker and auditor | Sol/Gemini when K3 implemented; K3 only when it preserves family independence |
| Commit text | Luna low | Commit/changelog transformations |

Keep every K3 route, `intake`, every `intake_explore_*` role and `audit` out of
`cycleOrder`. The cycle changes
the model in the existing transcript; K3 must instead enter through a fresh
named agent, fresh OMP process or fresh fleet stage. Sol advice should trigger at
high-value boundaries—plan handoff, first failed verification, material plan
deviation, unexpectedly broad diff and pre-audit—not run noisily on every
trivial turn.

The repository's direct Sol pin in `WATCHDOG.yml` now matches the desired
advisor choice. Prefer `model: "@advisor"` so the role remains the single
routing source rather than hardcoding the same model in two places.

### Bounded intake exploration routing policy

`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` controls this optional path.
Its dispatch/budget/event/reconciliation controls reuse one generic
bounded-model-job substrate shared with OMP/WorkService and later Fleet stages;
exploration does not grow a parallel scheduler.
The initial candidate is four fresh Flash-medium generator branches, one fresh
Sol-high synthesis and K3-256K-high deepening only when the owner separately
requests it. Fable-high remains the owner-facing interviewer; Web/CLI render the
typed options deterministically without an extra model call. These defaults are canary hypotheses, not permanent entitlements;
`NSI-E4` must compare them against no-exploration and equal-compute one-pass
alternatives before promotion.

Each branch receives the same frozen, content-addressed question/contract,
owner wording, admitted constraints/non-goals/decisions, unknowns and current
repository evidence. Only a reviewed frame differs. Branches are isolated and
cannot see siblings. The synthesizer and any deepener receive that complete
manifest plus the exact screened inputs; never reproduce the upstream behavior
where later stages lose supplied context.

All calls are fresh, brokered, tool-free and read-only with no ambient shell,
filesystem, SQL, WorkService, GitHub, deployment or provider-account
credential. Apply egress policy and secret scanning before dispatch. Every run
has owner-confirmed hard call/token/time plus a currency ceiling, metered quota
or explicit resource-only subscription mode; provider/stage-specific
payload/data-handling/redaction/egress and output-ingress receipts; durable
all-settled attempts; cancellation; currentness/fencing; and actual or
conservatively settled usage receipts.

Do not enable automatic anchor stripping, random/unrecorded frames, fixed
numeric novelty/viability/fit weighting, trap-driven automatic deletion,
same-model voting, raw reasoning capture or silent fallback. Deterministic code
screens schemas, exact references, duplicates and explicit hard constraints;
model synthesis remains advisory and every synthesized option is re-screened.
For owner decisions, present neutral options
before any optional advisory analysis. Planning handoff may include one clearly
advisory recommendation outside the ratified contract.

The first canary has no automatic cross-model fallback. A later fallback or
model/effort/destination change requires a preauthorized qualified route set or
a new offer/confirmation and creates a new recorded attempt. An ambiguous
provider result enters durable `reconciling`, then non-selectable
`outcome_unknown` with conservative maximum accounting; no replacement starts
without a fresh warned offer. Partial/cancelled/stale/critic-failed or
outcome-unknown output is honest and cannot be submitted through an option
card. Ordinary direct intake never waits for optional exploration.

### K3 capacity and session policy

Use `kimi-code/k3-256k:high` for ordinary K3 work. Kimi documents it as the same
K3 result quality inside 256K while full `k3` consumes about twice the quota.
Use `kimi-code/k3:high` only when the compiled context plus expected tool
trajectory may exceed roughly 180–200K, repository-wide topology materially
benefits from the extra capacity, avoiding compaction is important, or video
input is required. Use `:max` only in a new quality-first attempt.

K3 is sensitive to preserved native thinking history. Until OMP has proven
complete replay across tool loops, save/resume, compaction and cross-model
conversion:

- start K3 before the first assistant turn of its stage;
- never switch an existing Fable/Sol/Flash/Terra transcript into K3;
- never switch away from K3 and then back;
- do not resume or compact a correctness-critical K3 stage;
- recover a failed K3 process by creating a new attempt from immutable typed
  artifacts, not by continuing its transcript;
- treat every fallback into or out of K3 as a fresh attempt;
- keep model ID and effort fixed for the entire attempt.

The runner records a `modelHistoryPolicy`; K3 routes initially require
`fresh_only_no_resume_no_compaction`. Promotion to native resume requires
provider-wire regression tests, not merely a successful interactive session.

Before enabling K3 fleet routes, inspect authenticated model discovery and
require:

| Selector | Effective context | Maximum output | Efforts |
| --- | ---: | ---: | --- |
| `kimi-code/k3` | 1,048,576 for this Vivace entitlement | 131,072 | low/high/max |
| `kimi-code/k3-256k` | 262,144 | 131,072 | low/high/max |

The authenticated provider response is authoritative. A stale catalog, 32K
output cap, missing `max`, or incorrect entitlement blocks K3 promotion until
fixed. Vivace is substantial but not unlimited: membership features share a
credit pool and Kimi Code has rolling limits. Start with two concurrent 256K
workers and one full-context K3 slot, then promote from observed 429, latency,
credit and quality telemetry. Kimi's hosted Agent Swarm allowances do not
automatically become OMP fleet concurrency.

Primary references:

- [Kimi Code model configuration](https://www.kimi.com/code/docs/en/kimi-code/models.html)
- [Kimi Code API overview](https://www.kimi.com/code/docs/en/)
- [Vivace membership and shared-credit rules](https://www.kimi.com/help/membership/membership-overview)
- [K3 capabilities and limitations](https://www.kimi.com/blog/kimi-k3)
- [OMP K3 preserved-history qualification issue](https://github.com/can1357/oh-my-pi/issues/5847)
- [OMP K3 output-limit issue and workaround history](https://github.com/can1357/oh-my-pi/issues/6711)

## Mechanical risk routing

Risk is a deterministic policy result derived from admitted intake claims,
recorded unknowns and qualified repository/tool observations, not raw prose or
a prompt suggestion:

```ts
interface TaskRisk {
  level: "low" | "standard" | "high" | "critical";
  reasons: string[];
  requiresPlan: boolean;
  requiresIndependentAudit: boolean;
  requiresSandbox: boolean;
  requiresOwnerApproval: boolean;
  workerRole:
    | "default"
    | "fleet_worker"
    | "fleet_long"
    | "fleet_max"
    | "high_worker"
    | "slow";
  plannerRole: "plan" | "fleet_plan";
  modelHistoryPolicy: "fresh_only_no_resume_no_compaction" | "native_resume";
  specialistReviews: string[];
}
```

| Risk | Initial execution policy |
| --- | --- |
| Low | Flash high, deterministic checks, no Sol advice unless triggered |
| Standard | Fresh K3-256K high planner/worker for multi-file work, deterministic checks and Opus audit; Flash remains the trivial/local speed lane |
| High | Sol plan/advice, Terra high worker, hardened sandbox, Opus audit and relevant specialist |
| Critical | Sol xhigh, explicit owner authorization unless a narrow pre-authorized policy covers it, hardened sandbox, Opus audit plus adjudication |

Risk and context capacity are separate dimensions. A large context does not by
itself make a task high risk; it selects `fleet_long`. Conversely, a tiny
security or migration change remains high/critical and does not become a K3
volume task merely because it fits in 256K.

Automatic escalation includes:

- two failed verification loops;
- material plan deviation;
- security/authentication/authorization;
- schema or data migration;
- destructive or irreversible behavior;
- concurrency/distributed state;
- public API/protocol compatibility;
- dependency execution, release or deployment;
- unexpectedly broad diff;
- auditor `BLOCKED`;
- a critical/high audit finding;
- any containment or credential-policy event.

Compute before planning and recompute after planning and implementation. New
facts may only preserve or raise risk in the active attempt. Models may propose
escalation but cannot lower the deterministic result.

Keep independent audit for every fleet code candidate during qualification.
Skipping or sampling low-risk audits is a later evidence-backed promotion.

## Execution-graph node routing

Keep three mechanisms separate: the Work-item dependency DAG orders backlog
items, the lifecycle state machine authorizes transitions, and a bounded
execution DAG schedules computation inside one immutable attempt. File,
worktree, credential and concurrency conflicts are resource claims, not fake
data-dependency edges.

Models may propose an `ExecutionGraphProposal`, but the controller compiles it
from an allowlisted template, validates it and owns every transition. Initial
templates are `direct`, `read_discovery_diamond` and
`verification_diamond`; `split_implementation` stays disabled until isolated
multi-writer qualification. A repair or candidate mutation creates a new graph
epoch bound to the new candidate SHA and invalidates every downstream verifier,
join and audit result.

| Graph node | Initial route | Authority and constraints |
| --- | --- | --- |
| Portfolio decomposition/template proposal | Fresh K3 1M high | Engineering Manager proposes bounded nodes, edges, resources and budgets; controller accepts or rejects |
| Local read discovery | Flash medium/low | Read-only, independently checkable output; no lifecycle or topology authority |
| Repository-wide discovery/reduction | Fresh K3 1M high | Capacity route for large maps; must retain source/artifact references through reduction |
| Standard plan | Fresh K3-256K high | Typed plan plus graph proposal; no execution authorization |
| High-risk plan challenge | Sol high | Different-family challenge of invariants, hazards and verification design |
| Standard implementation | Fresh K3-256K high | One writable isolated worktree and declared resource claims |
| Large-context implementation | Fresh K3 1M high | Capacity exception with the same one-writer and attempt rules |
| High-risk implementation | Terra high | Hardened sandbox and stricter verifier profile |
| Critical/stuck implementation | Sol xhigh | New attempt under critical policy, never an in-place model switch |
| Build, tests, lint, types and security anchors | No model | Deterministic verifier nodes produce content-addressed evidence |
| Evidence join | No model | Requires the exact expected input count and matching candidate/policy/manifest hashes; fails closed on missing or stale input |
| Acceptance audit | Fresh Opus 5 high | Immutable, artifact-fed, cross-family verdict; never repairs |
| Disagreement adjudication | Sol or Gemini when K3 implemented | Exact evidence only; advisory result returns to deterministic policy |

Do not use majority voting as truth. Independent model votes may prioritize
investigation, but deterministic checks, exact source anchors and a
different-family evidence-bound auditor decide qualification. Sibling messages
are advisory coordination only; versioned artifacts and graph edges carry the
authoritative contract.

## Authoritative evidence and typed audit

The runtime—not the worker—creates a content-addressed, schema-versioned
`EvidenceManifest` containing:

- Work item and acceptance-contract revision/hash;
- approved plan/hash;
- run/stage/attempt and Run Manifest identity;
- repository, dirty baseline, base commit/tree and candidate commit/tree;
- changed paths and exact diff artifact/hash;
- verification argv, cwd, environment/image identity, timestamps, exit codes and
  stdout/stderr artifact refs;
- AC-to-evidence references;
- context, policy, model, tool and sandbox provenance.

The auditor returns a native typed `AuditResult` bound to candidate, evidence
and Run Manifest with:

- PASS, NEEDS_FIX or BLOCKED;
- typed severity findings and AC/evidence references;
- impact and minimal recommended scope;
- confidence;
- unverified claims, reason and required evidence.

Code validates and stores the object in WorkService before rendering Markdown or
UI. The model never copies its own canonical report into another transport.
Any mutation, rebase, base advance, policy/manifest change or repair invalidates
candidate-bound evidence and requires re-verification plus a fresh audit.

Do not simply re-enable the task-agent `outputSchema` route that previously
corrupted headed audit reports. First prove adversarial round-trip behavior at
the RPC/task transport boundary. Preserve the strict headed-text parser as a
fail-closed compatibility bridge until typed transport is proven.

## Mechanical auditor containment

A qualified fleet auditor requires all of:

- immutable candidate commit/tree and read-only repository mount;
- no writable git refs or patch-apply path;
- disposable scratch/cache that cannot affect the candidate;
- network denied;
- no WorkService, PostgreSQL, GitHub, controller, provider or deployment
  credentials exposed to model tools;
- separate process/context and different provider/model family from worker;
- read/grep/glob/artifact-reader and optional LSP;
- deterministic build/test evidence supplied by verifier rather than unrestricted
  auditor `bash`;
- containment telemetry; any mutation attempt is a violation;
- failure to establish any boundary blocks the audit.

Different-family routing is necessary but not sufficient for independence.

Every executable graph node also emits a controller-generated
`SandboxAttestation` before its first tool call:

```ts
interface SandboxAttestation {
  schemaVersion: string;
  runId: string;
  attemptId: string;
  graphEpoch: number;
  nodeId: string;
  sandboxId: string;
  runtimeImageDigest: string;
  candidateTree: string;
  writableMounts: string[];
  readOnlyMounts: string[];
  networkPolicy: "deny" | "allowlist";
  credentialProjectionIds: string[];
  processPolicyDigest: string;
  toolPolicyDigest: string;
  observedAt: string;
}
```

The controller verifies the attestation against the node policy before model or
command execution and records termination/violation telemetry afterward. OMP
task worktrees, copy-on-write clones and overlay filesystems are useful change
isolation but are not this security attestation. An in-process shell cannot be
made a trustworthy per-agent boundary by attaching an ad hoc “eBPF profile” to
the shared OMP process; run untrusted execution behind a process/container
boundary and apply filesystem, network, credential, syscall/LSM and resource
policy there.

## Context compiler and progressive policy

Do not solve context problems by adding more universal doctrine. Compile a
task-specific `ContextManifest` with only:

- exact Work item/acceptance criteria;
- approved plan/hash;
- lifecycle/risk state;
- applicable trusted rule IDs;
- compact symbol/signature repository map;
- files selected from imports, references, tests, ownership and failures;
- stage tool/safety policy;
- relevant previous failed attempts;
- authoritative artifact references.

Record every included source, hash, precedence, token count, truncation/redaction
and exclusion reason. Enumerate discovered `AGENTS`, skills, commands, hooks,
extensions, MCP and cross-ecosystem configuration before trust. Repository
content remains untrusted unless admitted by the frozen manifest.

Refactor large skills into concise routing documents with phase-specific
references and deterministic scripts. Register every rule:

```ts
interface HarnessRule {
  id: string;
  scope: string[];
  enforcement: "runtime" | "tool-policy" | "prompt" | "owner";
  originWorkItem?: string;
  evaluationId?: string;
  lastValidatedAt?: string;
}
```

When runtime/tool policy enforces a rule, remove duplicated normative prompt text
apart from a short explanatory reference. Rules and stages that do not improve
measured outcomes are deletion candidates.

### Stable prefix and cache telemetry

Compile each provider request as a stable prefix followed by task-varying
content. The stable prefix contains only the versioned harness identity,
immutable tool schemas and the stage's frozen policy; repository facts,
retrieved files, current failures and user/work-item content remain in the
dynamic suffix. Never place secrets in either region or weaken provenance to
increase cache hits.

Record, per request:

- provider, model, effort and exact prefix hash/byte count;
- tool-schema, harness-policy and ContextManifest revisions;
- provider-reported cache write/read tokens or equivalent, when exposed;
- time to first token, total latency, input/output/image tokens and cost/quota;
- cache miss/invalidation reason, model fallback and context rebuild;
- compaction, shake, Snapcompact and artifact-retrieval events.

Do not adopt a universal 20/50/20/10 context partition or assume a five-minute
cache lifetime across providers. Promote prefix layouts from measured hit rate,
latency, correctness and provider-specific behavior. Cache efficiency never
overrides K3's initial `fresh_only_no_resume_no_compaction` correctness policy.

### Snapcompact authority boundary

Snapcompact is a lossy, vision-token-efficient navigation/archive aid. It is
never the authoritative source for acceptance criteria, approved plans, policy,
candidate identity, diffs, test logs, security findings or audit evidence.
Those remain content-addressed original artifacts referenced by the manifest;
any node making a consequential claim must retrieve the original source.

Record Snapcompact source hash, serializer/shape configuration, frame hashes,
truncation and fallback reason. Never give the auditor only image frames or a
Snapcompact-derived summary. A non-vision model falls back explicitly, and
correctness-critical K3 stages continue to prohibit compaction until provider-
wire qualification proves preserved reasoning history.

### Syntax and semantic diagnostics policy

Do not describe syntax checking as absent. Current Hashline already parses the
baseline and proposed result, performs narrowly proven boundary repair and
warns when an edit makes a previously parsing file invalid; LSP write-through
can surface post-write diagnostics. Strengthen this as a versioned policy
rather than adding a duplicate parser wrapper:

```ts
type SyntaxPolicy = "off" | "advisory" | "reject_introduced";
```

- During multi-step implementation, introduced parse errors are advisory so a
  temporary cross-file state does not deadlock repair.
- At node completion and candidate sealing, supported source files that parsed
  at baseline must parse; `reject_introduced` fails closed unless an explicit
  generated/vendor/unsupported-language exception is recorded.
- Compiler, type-checker, formatter/linter and LSP diagnostics are separate
  deterministic evidence nodes. A clean Tree-sitter parse is not semantic
  correctness.
- Diagnostics bind to candidate tree, tool/version/config and exact command;
  any edit invalidates them.

## Interactive and fleet profiles

Client channel does not select model authority. Terminal and OMP Web consume
the same server-owned role/policy resolution. A browser-supplied profile, hidden
control or model narration cannot grant a route, permission, lifecycle action or
history exception. `/web` handoff changes the client, not the attempt; if a
handoff requires resume, reconstruction or compaction, the attempt's existing
`modelHistoryPolicy` still controls it.

Interactive owner profile:

- one active NOW Work item remains a useful focus discipline;
- owner-facing `/intake`, `/plan`, `/summary`, `/done`;
- after NSI cutover, `/intake` preserves the visible scan and one-question UX
  while candidate claims flow through WorkService admission, code-selected gaps,
  exact semantic-closure owner ratification, a current positive readiness
  receipt and explicit publication;
- after the optional N4 gate, a current eligible question may offer owner-
  confirmed **Explore alternatives**. It produces proposals only; direct answer
  remains primary and base intake/plan/Fleet never depends on the extension;
- `/plan` refuses an unpublished, missing/stale/conflicted/invalid or
  hash-mismatched intake receipt instead of allowing the planner to guess
  missing meaning;
- Flash remains the current active `default` because native `/plan` and model
  cycling operate in the same transcript;
- add a controller/extension-owned `/implement` handoff that seals the approved
  plan and ContextManifest, launches a fresh `@fleet_worker`, `@fleet_long` or
  `@fleet_max` stage in an isolated worktree, and returns candidate/evidence;
- owner-authorized final lifecycle transition;
- optional advisor and explicitly invoked task agents.

Fleet profile:

- separate HOME/`PI_CODING_AGENT_DIR`;
- multiple independent Work items under fenced controller claims;
- `@fleet_worker` is the normal standard implementation route and
  `@fleet_long` is the capacity route; every K3 stage is fresh and artifact-fed;
- trusted source-controlled agents plus explicit extension/skill/rule/tool/spawn
  allowlists;
- no interactive tracker extension, owner UI prompts or ambient project agents;
- headless approvals/questions fail closed;
- controller-authorized transitions under frozen qualified policy;
- repository-local agents, skills, hooks and configuration untrusted until
  admitted.

A model authorizes neither mode. Do not weaken the owner profile globally to
make the fleet run.

## Agent-role boundaries

- `specifier`: Fable proposes claims, ACs and owner-facing question wording;
  cannot admit a claim, set an assessment/receipt or ratify.
- `intake_alternate`: fresh K3 proposes alternate interpretations or bounded
  formalizations for large/high-risk intake; cannot vote away disagreement or
  establish truth.
- `intake_reasoner`: deterministic harness function, not an LLM; owns schema,
  rule, graph, conflict, gap, coverage and pre-ratification assessment.
- `intake_explore_generate`: bounded fresh tool-free alternatives under one
  reviewed frame; cannot see siblings, mutate state or establish a proposed
  factual assertion as authoritative/evidence-verified.
- `intake_explore_critic`: fresh full-manifest comparison and watch-outs;
  cannot rank into authority, delete a proposal as truth or answer for owner.
- `intake_explore_deepen`: separately owner-requested expansion of exact
  current options; proposal only, within a new confirmed budget.
- `owner`: the only product-semantic decision and contract-ratification
  authority.
- `work_service`: revalidates the ratified exact hash, creates current positive
  eligibility/formal-binding receipts and performs the explicit publish transition.
- `planner`: typed plan and AC mapping.
- `plan_critic`: conditional different-family review for high-risk work.
- `implementer`: only model role with worktree write access.
- `verifier`: deterministic harness function, not an LLM.
- `auditor`: immutable read-only verdict; never repairs.
- `security_reviewer`: conditional specialist.
- `engineering_manager`: typed portfolio/intake proposals only; cannot answer
  owner questions, admit claims or ratify.
- `observer/advisor`: anomaly advice only, never a completion gate.
- `integrator`: deterministic controller/broker function initially.

For the Fleet MVP disable recursive delegation and nested writers. Later permit
only a small allowlisted number of read-only scouts with spawn, recursion,
wall-clock, token and cost budgets. Final audit remains a controller-launched
fresh top-level stage.

The bounded intake exploration fan-out is not Fleet delegation: it is a
non-recursive, read-only, one-question proposal stage with its own hard budget,
durable inputs and N4 promotion gate. It grants no spawn capability to its
branches.

`/agents` manages definitions and Agent Hub observes one live process. Neither
is the fleet scheduler or durable state store.

## Fallback and independence

- A fallback is a recorded new attempt/resolution event, never invisible.
- A K3 fallback or effort/model change always creates a new session and attempt;
  it never continues the previous model's transcript.
- Use role-specific chains; a generic default chain must not convert audit into
  the worker family or a cheap task into an expensive unintended route.
- If no independent auditor route exists, block rather than self-audit.
- A model/effort change is recorded in manifest and evidence.
- Worker/auditor disagreement uses a third-family adjudicator on exact evidence,
  not majority vote.
- When K3 implemented the candidate and Opus audited it, use Sol or Gemini for
  adjudication. Use K3 as adjudicator only when K3 did not implement or audit.
- Required deterministic check failure blocks regardless of model reassurance.

## Outcome evaluation and ablation

First qualify the intake compiler independently on the same frozen intake tasks
and model/context limits:

| Intake arm | Configuration |
| --- | --- |
| I-A | Current prompt-owned intake |
| I-B | Practitioner requirements interviewer plus decisions log |
| I-C | Typed claims/provenance plus code-owned rules |
| I-D | I-C plus only selectively qualified formal adapters |

Measure false-ready first, then critical omissions, provenance closure, AC
coverage, material/redundant questions, owner corrections, key-question
efficiency, plan deviations and downstream audit findings caused by intake,
tokens and time. Promotion requires zero false-ready results on the versioned
seeded critical-omission corpus and complete provenance for every premise
contributing to a `READY_FOR_RATIFICATION` assessment.
Calibrate all other thresholds from the corpus. A solver result or model
agreement never substitutes for semantic ratification.

After base NSI qualification, run a separate owner-involved exploration
experiment on genuinely eligible decisions and closed/canonical negative
controls:

| Exploration arm | Configuration |
| --- | --- |
| X-A | Qualified NSI intake, no generated alternatives |
| X-B | One Sol-high alternatives pass |
| X-C0 | Four unframed Flash-medium branches plus the identical Sol-high synthesis and matched limits |
| X-C | Four isolated Flash-medium framed branches plus the same Sol-high route, prompt and limits as X-C0 |
| X-D | X-C plus a randomized deepening offer; analyze intention-to-treat and self-selected use separately |

Use the same frozen manifest and pinned routes. Match or explicitly report
total compute; X-C0 isolates frames from width/parallelism and matched-token X-B
controls extra spend. Measure useful selected options, critical conflicts
incorrectly presented as compliant/selectable/admitted,
unsupported facts, owner correction/reversal/time/abandonment, later plan
changes, implementation rework, downstream audit findings, duplicate/noisy
branches, offer precision, tokens, actual cost, latency, provider failures and
cancellation. Repeat a representative stochastic subset. Tune frames,
selector, sample size, margins and thresholds on a pilot, then freeze a separate
holdout. Randomize option order, normalize presentation length, blind arm
identity where practical and predeclare abandoned/missing handling.

N4 promotion requires zero authority, containment, secret/egress, currentness,
fencing, idempotency or limit-enforcement violations; zero critical conflicts
presented as compliant, exposed as selectable or admitted into owner/semantic
state; zero option submission after staleness; preregistered non-inferiority on
false-ready, critical omissions, provenance closure and owner-correction
burden; stable material benefit over X-A and an equal-compute control;
owner-confirmed currency/resource limit compliance; and proven rollback on the
frozen holdout. Automatic usage-consuming execution remains prohibited;
contextual no-model-call offers
are promoted only after selector precision is measured.

Use 30–50 frozen representative tasks and hold the worker model fixed for the
first harness ablation:

| Arm | Configuration |
| --- | --- |
| A | Bare OMP plus repository instructions |
| B | A plus role routing |
| C | B plus intake and approved plan |
| D | C plus worker self-review, no independent auditor |
| E | C plus independent auditor, no worker self-review |
| F | Full current text/evidence harness |
| G | Typed evidence-native, context-compiled, mechanically contained revised harness |

The corpus includes localized bugs, ambiguous intake, multi-file features,
migration, difficult debugging, resume-from-existing-work, security/concurrency,
seeded defects and false-positive bait. Measure hidden/AC success, first/final
pass, intervention, out-of-scope edits, regressions, repair loops, recovery,
turns, tokens, cost, latency and improvement over bare OMP per dollar/minute.

Run model routing only after the first same-worker ablation so harness and model
effects are not confounded. The first routing experiment compares K3-256K high,
Flash high and Terra high on the same standard-work corpus. Test full K3 only on
the large-context subset; it is a capacity route, not a presumed quality upgrade
inside 256K. Measure provider quota/rate-limit behavior in addition to ordinary
tokens, cost and latency.

Maintain a dedicated auditor benchmark containing functional, boundary,
missing-test, security, concurrency, scope-expansion, cross-file/interface and
false-positive-bait defects. Measure recall by severity, unsupported-finding
rate, BLOCKED calibration, evidence quality, adjudicated validity and cost per
real defect.

Initial promotion targets are provisional until baseline variance is known:

- zero seeded critical-defect misses and zero containment/fencing/idempotency
  violations;
- at least 90% high/blocker recall;
- no more than 15% unsupported findings;
- no silent same-family fallback;
- K3-256K qualifies as the primary standard fleet worker only if it has no
  critical safety/regression loss, stays within the ratified AC/defect-escape
  tolerance versus Terra, and materially improves subscription utilization or
  long-horizon success versus Flash.

Keep scheduled evaluations and 10–20% shadow/alternate-family audits after
promotion to detect drift.

## CI, packaging and maintainability

Add a required fast harness job triggered by:

```yaml
paths:
  - "session-system/**"
  - "AGENTS.md"
  - ".omp/**"
  - "packages/session-harness/**"
```

Its repository-inspected command equivalents must cover:

```text
bun test session-system/tests
session-system/install.sh --check
bun check session-system
```

Require the job on main. Keep deterministic mechanism/contract/security tests in
the PR path; run expensive probabilistic evals on schedule and before capability
promotion.

Native OMP Web release qualification additionally pins the exact browser asset
tree and tests `omp web`, `/web` exact-session handoff, protocol/capability
version negotiation, cross-session event isolation, reconnect/replay and
`LOCAL_OWNER`, `REMOTE_RESTRICTED`, `WORK_OWNER` and `FLEET_SUPERVISORY`
capability/credential isolation. Packaging must resolve one supported Web build
per OMP release; a separate manual WebUI installation or silent protocol drift
is not accepted.

When bounded exploration is built, CI additionally covers its schemas,
canonical hashes, deterministic frame replay, currentness/fencing, branch
isolation, all-settled recovery, budget/cancel behavior, secret/egress controls,
hostile rendering and exact owner-answer admission. Expensive stochastic X-A,
X-B, X-C0, X-C and X-D evaluations run on schedule and before N4 promotion, not on every
ordinary PR.

Package the custom layer—name subject to live repository inspection, for example
`@theturtlecsz/omp-session-harness`—with lifecycle, context, evidence, routing,
policies, WorkService adapter, agents, skills, tests and eval fixtures. Keep only
unavoidable compatibility hooks in the fork. Version prompt, policy, agent,
schema, tool and model-resolution manifests, and test against both the pinned
OMP revision and a regularly refreshed upstream revision.

## Research disposition

For intake, adopt requirements-sufficiency gating, provenance-carrying typed
claims, code-owned rules, gap-directed questions, concrete witnesses and exact
owner ratification. Select Z3 only for demonstrated bounded hard constraints;
defer ASP to genuine defaults/exceptions and temporal model checking to
high-risk lifecycle/concurrency properties. Reject model self-certification,
universal formalization and question volume as a quality metric. Full evidence
classes and caveats are recorded in
`08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`.

For exploration, adopt isolated framed divergence, generator/critic separation,
explicit watch-outs and bounded optional deepening only with substantial OMP-
native adaptation. Reject the standalone Claude runtime, default-on fan-out,
automatic anchor rewriting, random frames, model-score authority and raw
reasoning display. Treat the upstream six-task evaluation as preliminary
breadth evidence, not human or coding-outcome proof.

Treat the supplied architectural report as untrusted source material, not as a
verified inventory or score. Incorporate only claims corroborated by current
repository code, primary documentation or controlled evaluation. Current
repository evidence at the review point reports 31
built-in tools, 14 LSP operations and 28 DAP operations—not 32/13/27. Task
isolation and structured output are real but optional; isolation defaults to
`none`, output schemas are not mandatory, and headless subagents run `yolo`.
Current OMP also already has `workflowz`, `parallel`, barriered `pipeline`,
Agent Hub and peer messaging, so the missing fleet capability is durable,
controller-authorized graph state rather than basic agent communication.

Accepted research directions are process-level containment, sandbox
attestation, bounded DAG templates, typed evidence, stable-prefix telemetry,
task-specific context and extension packaging. Adapted directions are syntax
validation (strengthen the existing advisory at candidate boundaries) and DAG
coordination (artifacts and deterministic joins, not free-form sibling state).
Rejected directions are in-process “Seccomp-eBPF,” automatic AST conflict
resolution, fixed context percentages, majority vote as proof, and nonexistent
`pi-headroom`, `headroom-retrieve` or `stream-filter` surfaces.

Primary implementation references:

- [current fork capability counts](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/README.md)
- [task isolation and structured-output behavior](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/tools/task.md)
- [approval and headless-subagent policy](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/approval-mode.md)
- [current Hashline syntax behavior](https://github.com/theturtlecsz/oh-my-pi/blob/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8/packages/hashline/src/apply.ts)
- [Snapcompact compaction behavior](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/compaction.md)
- [workflow helpers](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/packages/coding-agent/src/prompts/system/workflow-notice.md)
