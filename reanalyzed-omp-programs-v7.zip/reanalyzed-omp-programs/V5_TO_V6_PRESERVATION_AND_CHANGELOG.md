# v5 to v6 preservation record and changelog

## Purpose

This file records exactly how v6 was derived from v5. The v5 archive remains the immutable baseline; v6 is a new package revision and does not replace or rewrite it.

Baseline archive:

- File: `reanalyzed-omp-programs-v5.zip`
- SHA-256: `c3c953d544227b816faa3c81f0e4ddd612c6a67b0c4d5df9ec9442395c06ba8a`
- Archive root: `reanalyzed-omp-programs/`
- Baseline contents: 13 files, including the generated `SHA256SUMS`

The hashes below prove byte identity only. They do not prove that a revised document preserved every requirement or meaning. Semantic preservation for revised files is addressed by the explicit section-level disposition later in this record and by independent cross-file review.

## Complete v5 baseline inventory

Every v5 path is retained at the same path in v6. `UNCHANGED` means the v6 copy must have the exact v5 bytes and SHA-256. `REVISED` means the path is retained but its contents are intentionally updated and therefore receive a new v6 hash. `GENERATED` is a revised file whose final contents are computed from the completed v6 tree.

| v5 path | v5 bytes | v5 SHA-256 | v6 handling |
| --- | ---: | --- | --- |
| `00_READ_ME_FIRST.md` | 12,533 | `c90bdf438de577d05b17a6725c41558c08f54f552e7365193d702f560234250f` | REVISED |
| `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` | 11,420 | `125a041048950c5b7c22ce5d90314518b637bb2d7b76580919affd294ca17b18` | UNCHANGED |
| `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md` | 30,149 | `ee960dab787c2a329d65875bdfc2f6f54d4791bcb9dec89cafc9864fda9e56e8` | UNCHANGED |
| `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md` | 35,161 | `4021bbe935c42df624678c70ee2a66cc9eec4d9a17d667a6afe22ce7dd217ef9` | UNCHANGED |
| `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` | 55,336 | `17896b9a0e130e1e175fd2537506ac9bfce74661ef217a5d40ebc4e61a459227` | UNCHANGED |
| `05_REMOTE_FLEET_MANAGER_INTAKE.md` | 27,652 | `34156773a4f94a0dbc0a93af833dc44de2528aaaf7615af6aff509afd1e2ea90` | REVISED |
| `06_MODEL_AND_AGENT_OPERATING_POLICY.md` | 33,777 | `23753354cc428928fe2e5c5a75cfa46c6654b30ad3167e20226e0d5b1c356129` | REVISED |
| `07_HARNESS_RECOMMENDATION_CROSSWALK.md` | 21,637 | `2f1f0054cb6168d0c8433f814e8766f0863fa280437e98efdfe9513e648439b3` | REVISED |
| `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md` | 49,546 | `9f55f47c523d1a63ee5fef93c613a0247f4ec960676c1055c4a6578b0e8f6d28` | REVISED |
| `09_SOLO_DEVELOPER_USER_GUIDE.md` | 13,459 | `2174c5069e5c8edc5bbda9e05758d6925b7a80dec8673f1bd55385984f68105e` | REVISED |
| `PROGRAM_DEPENDENCIES.md` | 13,135 | `ecd7647a87fdf3d03bb8cbda28b38dea02c86e75b8d0dd207d9ae60418f209e1` | REVISED |
| `MANIFEST.md` | 1,896 | `8405f1b013bdbe33e77b607b2e05446ca2c4e63ecaad95bda5cb4ea73933654a` | REVISED |
| `SHA256SUMS` | 1,212 | `a1c4c509528eecc63e8069990c3d38dbd2ae344830320bc41779c478ff03abbe` | REVISED / GENERATED |

## Files added in v6

| Added path | Purpose |
| --- | --- |
| `03A_NATIVE_OMP_WEB_INTAKE.md` | Paste-ready implementation program for making `omp-webui` the official first-party OMP Web experience while retaining separate processes, protocols and trust boundaries. |
| `V5_BASELINE_SHA256SUMS` | Machine-readable copy of the v5 baseline hashes so preservation checks do not depend on prose extraction. |
| `V5_TO_V6_PRESERVATION_AND_CHANGELOG.md` | This human-readable preservation classification and semantic change record. |

No v5 path is removed or renamed. The v6 archive keeps the same single archive root and adds only the three paths listed above.

## Preservation rules

1. Keep `reanalyzed-omp-programs-v5.zip` unchanged and publish v6 as a separately named archive.
2. Require all 13 v5 paths to exist at the same relative paths in the v6 staging tree.
3. Require the four `UNCHANGED` files to match their v5 byte counts and SHA-256 values exactly.
4. Permit content changes only in the nine paths classified as `REVISED` or `REVISED / GENERATED` above.
5. Treat all three v6 additions as additive material. They may not silently replace SQL-0, NSI, Fleet, model-policy or Fleet Manager requirements.
6. Preserve SQL-0 as the hard prerequisite for authoritative NSI and Fleet activation. Native Web work must not be hidden inside, expand or weaken the in-flight PostgreSQL migration.
7. Preserve WorkService/PostgreSQL as the sole operational authority, the deterministic Fleet controller as the lifecycle authority, and exact-candidate verification and independent audit as completion requirements. A browser, local Web daemon or derived UI database cannot acquire those roles.
8. Preserve the security boundary: one official OMP Web product may share a visual shell, components and distribution, but Local Session, Restricted Remote Session, Work/Intake and Fleet services retain separate processes, origins, protocols, credentials and least-privileged capabilities.
9. Do not expose the broad local OMP daemon protocol, provider credentials, unrestricted files or Git operations, or a raw PTY through the remote mode. Any later remote-prompt capability must be explicit, capability-gated and qualified by a canary.
10. Regenerate the final v6 `SHA256SUMS` after all content is frozen. It must cover every package file except itself, including this record and `V5_BASELINE_SHA256SUMS`.
11. Reject duplicate ZIP member names, absolute or traversal paths, symlinks and extra archive roots. Test the ZIP, cleanly extract it, verify its internal sums and compare the extraction with the frozen staging tree.
12. Record the final v6 archive SHA-256 separately. Do not place the digest of `SHA256SUMS` inside `SHA256SUMS` or create a checksum cycle.

## Section-level disposition for revised v5 files

### `00_READ_ME_FIRST.md`

Preserved:

- The evidence boundary and qualified nature of external recommendations.
- The SQL-0 → NSI → Fleet authority sequence.
- The neuro-symbolic intake tranche, model boundaries and owner-intervention rules.
- The corrected authority architecture: WorkService owns durable truth; models propose; deterministic code validates; owner ratification controls intended meaning.
- The primary-source anchors and instruction to revalidate moving targets before implementation.

Revised or added:

- Identify the package as v6 and add the native OMP Web tranche.
- Clarify that “native” means an official, bundled, version-matched OMP product experience—not putting the browser UI, agent loop and Fleet authority into one privileged process.
- Add the v6 file inventory and the Web program’s safe place in the execution order.
- Replace the old presentation of a separately branded wrapper with one OMP Web product that has distinct Local Session, Restricted Remote Session, Work/Intake and Fleet trust modes.

No SQL-0, NSI, Fleet or audit gate is removed by this revision.

### `05_REMOTE_FLEET_MANAGER_INTAKE.md`

Preserved:

- The complete Fleet Manager program and its bounded, typed operator-command model.
- WorkService/PostgreSQL projections as authority, server-side authorization, idempotency, audit logging, stale-state handling and exact-candidate safeguards.
- Separate least-privileged Fleet gateway/backend, strong authentication, private deployment first, emergency stop semantics and fail-closed behavior.
- Read-only-first rollout, fixture-driven UI, notifications, mobile/responsive behavior, accessibility, hostile-content handling, tests, promotion gates and rollback.
- The prohibition on exposing the local broad Chat/OMP daemon, provider credentials, unrestricted file/Git access or PTY remotely.

Revised or added:

- Replace “two distinct products” with one official OMP Web product expressed through separately deployed trust modes and backends.
- Allow the visual shell and safe presentational components to be shared while continuing to forbid shared privileged runtime authority or importing the local daemon into the remote Fleet gateway.
- Make the native OMP Web foundation an explicit dependency for the Fleet-facing mode and retain WFM tasks for the Fleet-specific gateway, projections and controls.
- Distinguish full local-session capability from restricted Remote Session, Work/Intake and Fleet capability in user-facing language and negotiation.

This is a product and distribution consolidation, not a collapse of security boundaries.

### `06_MODEL_AND_AGENT_OPERATING_POLICY.md`

Preserved:

- Every v5 model route, risk rule, K3 history restriction, auditor boundary,
  evidence rule, containment policy and promotion/qualification requirement.
- The existing command/bookend meanings and the SQL-0 → NSI → Fleet order.

Revised or added:

- Clarify that OMP Web presents the existing command/bookend semantics rather
  than duplicating them as another agent runtime.
- State that changing from terminal to browser cannot change model authority,
  permissions, attempt identity or `modelHistoryPolicy`.
- Add version-matched Web packaging and four-profile capability/credential
  isolation tests to release qualification without changing any model role.

### `07_HARNESS_RECOMMENDATION_CROSSWALK.md`

Preserved:

- Every existing accepted, adapted, deferred and rejected harness recommendation.
- Existing status labels and the requirement that unimplemented capabilities not be presented as current behavior.
- The model-policy intent and rejection of worktrees as a security boundary, arbitrary mutable agent graphs, same-model voting as proof, worker self-attestation and unsupported autonomous authority.

Revised or added:

- Add a separate disposition for Kimi Code’s WebUI, Orca and Agent Orchestrator findings.
- Adopt user-visible patterns that add solo-developer value: one-command Web startup, current-session browser handoff, session/workspace navigation, rich tool and diff views, an attention queue, reconnect/resume and responsive remote access.
- Reject wholesale adoption of their orchestrators, databases, trust claims, YOLO defaults, raw remote shells and worker-owned correctness signals.
- Clarify that recreating useful interaction patterns in the existing React codebase is different from copying unavailable or obsolete compiled UI source, branding or a third-party harness.

### `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`

Preserved:

- The status/authority warning, repository evidence rules and revalidation requirement.
- The complete neuro-symbolic, graph-engineering and recommendation dispositions.
- The exact mapping of accepted ideas into NSI and Fleet tasks.
- The primary-source register and the distinction between verified facts, design choices and qualification hypotheses.

Revised or added:

- Record current OMP, `omp-webui` and Kimi Code repository anchors used for the v6 decision.
- Add the native Web research disposition and source register for Kimi’s official Web, command, API, release and remote-control materials plus Orca/AO primary documentation.
- State the evidence-based inference: make `omp-webui` first-party in packaging and UX while keeping its runtime adapter out of the OMP agent loop and keeping Remote Session, Work/Intake and Fleet protocols least-privileged.
- Map borrowed ideas to OWEB tasks and preserve qualification gates for remote prompts, mobile/PWA behavior, compatibility, replay and security.

The new sources justify the product direction and candidate features; they do not prove outcome improvement before the prescribed evaluation.

### `09_SOLO_DEVELOPER_USER_GUIDE.md`

Preserved:

- The plain-language explanation of what the system gives one developer.
- The distinction between what works now and what becomes available after SQL-0, NSI and Fleet milestones.
- The workflows for new ideas, existing issues, typed blueprints and backlogs.
- The owner’s required intervention points and the warning not to activate planned capabilities early.
- The SQL-0-first next action.

Revised or added:

- Explain OMP Web in end-user terms: `omp web`, `/web` handoff, the same sessions/config/models and no separate wrapper installation.
- Add the local full-workbench experience and the deliberately narrower remote experience.
- Add Web implementation to the one-time build order without weakening SQL-0, NSI or Fleet authority gates.
- Replace the old implication that remote use is only a separate future Fleet product with staged local Web, restricted remote Web and later Fleet pages in the same official product.

### `PROGRAM_DEPENDENCIES.md`

Preserved:

- All SQL-0, NSI, Fleet and WFM task dependencies, activation gates, risk policy, graph separation and stop rules.
- The rule that no authoritative Fleet activation occurs before `SQL-0: PROVEN` and a qualified NSI contract/receipt path.
- The deterministic controller, exact-candidate artifacts and bounded-promotion model.

Revised or added:

- Add the OWEB task graph for contracts, native distribution, adapter reliability, Kimi-inspired UX, local mode, restricted remote mode and qualification.
- Allow non-authoritative fixture/design work to proceed independently only when it does not modify or obscure SQL-0.
- Gate OMP-core Web changes around repository conflicts and gate Intake/Fleet views on their authoritative backends.
- Make WFM the Fleet-specific backend/mode program built on the OMP Web foundation, rather than a separately branded product.

### `MANIFEST.md`

Preserved:

- The hard SQL-0 → NSI → Fleet sequence.
- Reading/application order, paste-ready command identification, integrity instructions and evidence boundary.

Revised or added:

- Identify v6, add the native Web intake and preservation artifacts, and place them in reading/application order.
- Describe the WEB and WFM relationship without moving authority into the UI.
- Update the integrity instructions for the larger v6 inventory.

### `SHA256SUMS`

The v5 checksum file is replaced only after the v6 content tree is frozen. The v6 file is a mechanically generated integrity index, sorted by package-relative path, and covers every package file except `SHA256SUMS` itself. This regeneration reflects deliberate revisions and additions; it does not by itself demonstrate semantic preservation.

## Preservation acceptance checks

The v6 package is acceptable only if all of the following pass:

- The original v5 ZIP still has the recorded archive hash and passes ZIP integrity testing.
- The v5 internal checksums pass before derivation.
- Every v5 path remains present in v6.
- All four `UNCHANGED` files match their recorded v5 hashes exactly.
- Every changed or added path appears in this record; there are no undeclared changes.
- Cross-file review finds no contradiction that weakens SQL-0, NSI, Fleet, evidence, audit or remote-security requirements.
- The v6 `SHA256SUMS` verifies from a clean extraction.
- The extracted archive is byte-for-byte identical to the frozen v6 staging tree.

Passing these checks establishes reproducible package derivation and reviewed requirement disposition. It does not turn future implementation claims or research hypotheses into proven runtime behavior.
