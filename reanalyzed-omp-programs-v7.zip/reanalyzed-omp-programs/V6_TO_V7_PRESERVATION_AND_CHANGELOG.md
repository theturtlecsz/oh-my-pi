# v6 to v7 preservation record and changelog

## Baseline identity

This file records exactly how v7 was derived from v6. The v6 archive remains
an immutable baseline; v7 is a separately named package revision and does not
replace or rewrite it.

- Baseline archive: `reanalyzed-omp-programs-v6.zip`
- Baseline archive SHA-256:
  `329a66057b84ebf5542c0ffaf25f9731dade3728d31f2fdd64fb0bcd696a8570`
- Baseline file index: `V6_BASELINE_SHA256SUMS`
- New archive: `reanalyzed-omp-programs-v7.zip`
- Research anchor added: `UditAkhourii/adhd` at
  `53ab5576b77fb3d6e62739a1a285356261e5f568`, rechecked 2026-08-29

## Path-by-path preservation

Every v6 path remains at the same relative path in v7. `UNCHANGED` means exact
v6 bytes and SHA-256 are required. `REVISED` means the path is retained and its
contents are deliberately extended. `GENERATED` means the final file is
mechanically rebuilt only after the v7 tree is frozen.

| v6 path | v6 bytes | v6 SHA-256 | v7 handling |
| --- | ---: | --- | --- |
| `00_READ_ME_FIRST.md` | 15,441 | `1202a2b58c8d4f2acd315db305747f330c8b28ef5eff73c63f6314c0a6cec1f5` | REVISED |
| `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md` | 11,420 | `125a041048950c5b7c22ce5d90314518b637bb2d7b76580919affd294ca17b18` | UNCHANGED |
| `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md` | 30,149 | `ee960dab787c2a329d65875bdfc2f6f54d4791bcb9dec89cafc9864fda9e56e8` | REVISED |
| `03A_NATIVE_OMP_WEB_INTAKE.md` | 27,288 | `b6097fc6533357ba63d7d7830660331866200d1a9c8c8eaddd775b4daea535e8` | REVISED |
| `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md` | 35,161 | `4021bbe935c42df624678c70ee2a66cc9eec4d9a17d667a6afe22ce7dd217ef9` | REVISED |
| `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` | 55,336 | `17896b9a0e130e1e175fd2537506ac9bfce74661ef217a5d40ebc4e61a459227` | UNCHANGED |
| `05_REMOTE_FLEET_MANAGER_INTAKE.md` | 29,980 | `7be4ef4ecb34fa80bb546979db3774296d20bfe21fd0e0ed23f5db8952933de6` | UNCHANGED |
| `06_MODEL_AND_AGENT_OPERATING_POLICY.md` | 34,846 | `d08a20a8ddfc6edc4668030b6259a5d26ab7fd65a000ed5ed49634cc1eee48b9` | REVISED |
| `07_HARNESS_RECOMMENDATION_CROSSWALK.md` | 25,507 | `85e0d251c0f3a6dde523fb50786b6e5d0f2ade43d4241bee0f6ff72a0fd508a0` | REVISED |
| `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md` | 57,715 | `c74f8f4dcf3d805514b3150864a83fbed28c171b0356964af8b478c512948c40` | REVISED |
| `09_SOLO_DEVELOPER_USER_GUIDE.md` | 17,001 | `2585e1c745b85e7c6496ae89a3459cc1d092fe82a46cbc0cda80d462549f16e0` | REVISED |
| `MANIFEST.md` | 2,933 | `1999b374f9cc75cb04ec7a16f51d484c10b83b058a84a69bd7bf627ae78c498a` | REVISED |
| `PROGRAM_DEPENDENCIES.md` | 18,304 | `a590e57d675a488e0abe851a0591d480988c8aeeaa24e6833f5819d18456ecc4` | REVISED |
| `SHA256SUMS` | 1,501 | `af5ac200383fe800ea3a5749fb1f523fedcc43d5afca6144c3daaf1e87f52d06` | GENERATED |
| `V5_BASELINE_SHA256SUMS` | 1,289 | `03b91fcaca7e9d506c7c58c7d8cc90ed4d795e09d6d2d916d7ec04d17f840d42` | UNCHANGED |
| `V5_TO_V6_PRESERVATION_AND_CHANGELOG.md` | 15,011 | `9be08ca4d0e63422424d86412b3be1e0c3cdd213482bc2eaf4d05ac453ba89a5` | REVISED — transcription-only correction described below |

## Files added in v7

| Added path | Purpose |
| --- | --- |
| `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` | Normative optional NSI-E1–E4 contract: eligibility, owner authorization, frozen inputs, branch/synthesis topology, budgets, durability, security, Web/CLI UX, evaluation and N4 promotion. |
| `V6_BASELINE_SHA256SUMS` | Machine-readable immutable hash index of every original v6 file, including v6 `SHA256SUMS`. |
| `V6_TO_V7_PRESERVATION_AND_CHANGELOG.md` | This preservation classification and semantic change record. |

No v6 path is removed or renamed. The v7 archive retains the same single
archive root and contains 19 files: all 16 v6 files plus the three additions.

## Authority and sequencing preservation

The v7 delta is deliberately optional and cannot reopen prior authority
decisions:

1. `SQL-0: PROVEN` remains the hard prerequisite for NSI and live native-Web
   integration.
2. Core `NSI-1..NSI-6: QUALIFIED_AND_CUT_OVER` remains the only intake
   prerequisite of FLEET-1.
3. PostgreSQL through WorkService remains the durable authority.
4. Models remain proposal/advice producers. The owner alone decides product
   meaning, and WorkService alone admits/revalidates/publishes typed state.
5. The deterministic reasoner remains the sole readiness computation path.
6. Native OMP Web remains a client with separate local, remote-session,
   Work/Intake and Fleet trust surfaces.
7. `NSI-E1..NSI-E4 -> N4` is an optional side program. It cannot block normal
   intake or Fleet, mint readiness, alter the contract silently or authorize
   automatic usage-consuming execution.
8. `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md` and
   `05_REMOTE_FLEET_MANAGER_INTAKE.md` are byte-preserved to prove the feature
   does not expand Fleet or Fleet Manager authority.

## What changed semantically

### `00_READ_ME_FIRST.md`

- Identifies v7 and preserves v6 as the immutable baseline.
- Adds the ADHD source anchor and critical adopt/adapt/reject disposition.
- Shows the optional side branch in intake, model roles, order and inventory.
- States plainly that ordinary NSI/Fleet never depends on exploration.

### `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md`

- Adds optional `NSI-E1` through `NSI-E4` child proposals after the core NSI
  contracts they consume.
- Makes eligibility code-selected, execution owner-confirmed and all outputs
  advisory until an exact answer passes ordinary owner-decision admission.
- Adds deterministic pre/post-synthesis screening, enforceable currency-or-resource
  limits, stale/failure behavior and N4.

### `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md`

- Defines the boundary between a current `ClarificationQuestion`, exploration
  artifacts and canonical `OwnerDecision` admission.
- Preserves semantic closure: only the confirmed answer is included; rejected
  or unselected suggestions never become requirements or non-goals.
- References `03B_...` as the controlling extension contract.

### `03A_NATIVE_OMP_WEB_INTAKE.md`

- Adds neutral, accessible Explore/Deepen/Cancel/Submit UX with visible time and
  currency-or-resource previews, enforceable limits, partial results and stale-state
  handling.
- Requires both N4 and OWEB-7 before remote execution; the browser never gains
  provider, scheduler or readiness authority.

### `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`

- Ports the useful divergent-ideation pattern into OMP-native typed contracts.
- Separates owner-decision exploration from a post-publication advisory
  planning handoff.
- Defines immutable manifests, deterministic reviewed frames, isolated
  tool-free branches, code screening, separate synthesis and optional K3
  deepening.
- Binds owner authorization to the frozen manifest, provider account/endpoint/
  region, data classes, provider data-handling/retention posture and exact
  egress plan; derived data inherits sensitivity and provider output passes
  fail-closed ingress DLP before reuse or rendering.
- Requires exact retention/cache durations and owner-visible training, caching,
  retention and deletion posture; only typed `admitted` provider output may
  reach branch success, synthesis, deepening, screening or presentation.
- Adds a shared durable stage-attempt and pre-dispatch invocation-intent
  substrate with leases/fences, single-use offers, one-active-run uniqueness,
  aggregate atomic budget ledgers and server-stamped authorization records.
- Splits immutable budget policy from compare-and-set availability so a
  reservation cannot stale its own run; debits aggregate availability once,
  partitions one dedicated allocation per invocation and prevents allocation
  reuse or duplicate active deepening.
- Separates owner-decision values from planning-approach types and makes
  evidence verdicts server-derived assertion screenings rather than model
  self-labels.
- Defines call/token/time/concurrency/retry caps plus either a broker-enforced
  currency ceiling, metered quota or fixed resource-only subscription limits;
  estimate, authorization, cancellation, partial failure, fencing, idempotency
  and usage receipts.
- Adds durable provider reconciliation, **Checking provider result** and
  non-selectable **Provider result unknown**, conservative maximum accounting
  and fresh warned authorization before any replacement call. Durable
  `dispatching` state makes a crash an unknown outcome, never automatic
  permission to resend.
- Uses directionally ordered previous-revision references to prevent content-hash
  cycles, discriminates provider reconciliation method/identity authority, and
  represents synthesis no-output failure as a zero-option controller summary.
- Assigns server/CLI/generated contracts to NSI-E3 and the native local client
  to the OWEB-4 `omp-webui` sub-lane; NSI-E4 owns manual local canary and N4
  gates normal local or remote activation.
- Prohibits raw/private chain-of-thought capture or display.
- Defines X-A/X-B/X-C0/X-C/X-D comparisons, pre- and post-synthesis screening,
  identical X-C0/X-C synthesis controls, separate deepening,
  safety/outcome/currency-or-resource measures and the exact N4 promotion gate.

### `06_MODEL_AND_AGENT_OPERATING_POLICY.md`

- Adds explicit generation, synthesis and deepen routes with separate models
  and no self-authorizing usage-consuming loop.
- Requires branch isolation, full-manifest synthesis, a shared generic
  bounded-model-job substrate, currency-or-resource accounting and
  equal/reported-compute evaluation.

### `07_HARNESS_RECOMMENDATION_CROSSWALK.md`

- Records what is adopted, substantially adapted, deferred and rejected from
  ADHD instead of accepting the project label wholesale.

### `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`

- Adds inspected implementation facts, limitations, evidence quality, Tree of
  Thoughts scope, exact NSI-E mapping and primary-source links.
- Carries upstream defects into controls rather than copying them: automatic
  anchor stripping, unseeded frames, fixed model-score pruning, context loss,
  brittle partial failure and missing durability/budgets/staleness.

### `09_SOLO_DEVELOPER_USER_GUIDE.md`

- Leads with jargon-free everyday use, then moves program IDs, model roles and
  build gates into a builder/maintainer appendix.
- Explains when the feature is worth its currency/quota/time use, exact CLI/Web
  interaction, choices, limits, reconciliation/failure/stale behavior and what
  never becomes authoritative.

### `PROGRAM_DEPENDENCIES.md`

- Adds the optional NSI-E graph, N4, local OWEB-4 and remote OWEB-7 dependencies,
  producer/consumer contracts, model routes and stop rules without changing
  `NSI-6 -> FLEET-1`.

### `MANIFEST.md`

- Identifies v7, inventories all 19 files and records both the hard authority
  sequence and separate optional exploration sequence.

### Historical transcription correction

The v6 `V5_TO_V6_PRESERVATION_AND_CHANGELOG.md` accidentally transcribed the
v5 `PROGRAM_DEPENDENCIES.md` SHA-256 with two characters omitted/moved. v7
changes only that table cell to the value already present in the immutable
`V5_BASELINE_SHA256SUMS`:

```text
ecd7647a87fdf3d03bb8cbda28b38dea02c86e75b8d0dd207d9ae60418f209e1
```

No v5 file or original v6 archive is changed; `V6_BASELINE_SHA256SUMS` records
the original v6 bytes. This is a historical documentation correction, not a
semantic or baseline rewrite.

## Deliberately not adopted

- Installing or calling the upstream Claude Agent SDK runtime.
- Default or automatic usage-consuming exploration on every `/intake`.
- Automatic anchor stripping or paraphrasing of owner constraints.
- Random/unrecorded frames, branch communication or access to tools.
- Fixed numeric model-score pruning, trap-label deletion or model voting as
  truth.
- Raw/private reasoning capture, display or persistence.
- Exploration in deterministic verification, final audit, readiness, receipt
  issuance, lifecycle control or external writes.
- Automatic recursive/deepen loops or any spend/use beyond owner-confirmed
  enforceable limits.

## Final verification requirements

The v7 package is acceptable only if all of the following pass:

- the original v6 archive independently passes ZIP integrity and its internal
  `SHA256SUMS`;
- every v6 path remains present at the same relative path;
- all four `UNCHANGED` paths match `V6_BASELINE_SHA256SUMS` byte-for-byte;
- the three new paths exist and no unlisted path is introduced;
- all Markdown links and relative file references are checked;
- terminology, gates, routes and authority statements agree across the intake,
  contracts, Web UX, policy, dependency map and guide;
- `SHA256SUMS` covers every v7 file except itself exactly once and verifies from
  a clean extraction;
- the archive has one root and no path traversal, absolute path, duplicate
  member, symlink or hidden metadata entry; and
- a clean extracted tree is byte-for-byte identical to the frozen staging tree.

The final v7 archive SHA-256 is recorded outside the archive at publication to
avoid a checksum cycle.
