# Harness review integration crosswalk

This records how the supplied harness verdict, graph-engineering research,
architectural evaluation report, Vivace/K3 revision, neuro-symbolic
requirements research, practitioner interview technique and the v6
Kimi/Orca/Agent Orchestrator product comparison, plus the v7 review of
`UditAkhourii/adhd` divergent ideation, were incorporated.
It intentionally does not copy the reviews verbatim or turn their
subjective `8.2/10` or `8.8/10` scores into product requirements. Recalculate
any rating only after the new baselines exist.

Important terminology: **included in this package does not mean implemented in
the repository**. The status below separates what exists now, what belongs to
the active SQL migration, what the post-SQL Intake Compiler and later Fleet
programs will build, what is deferred behind qualification, and what is
intentionally rejected.

## Implementation status at package revision

| Status | What belongs here |
| --- | --- |
| **Already present in the inspected fork** | Automatic intake model bookend; native plan handoff; fresh-context fail-closed summary auditor and strict headed-text parser; task-agent definitions/discovery; `/agents`; Agent Hub; advisors; role aliases; task isolation primitives; OMP RPC; Robomp prototypes and event-level lifecycle tests. These are reusable foundations, not proof of OS containment or typed evidence. |
| **Active now: SQL-0 only** | PostgreSQL/WorkService authority, Linear import and cutover, no dual writer, idempotent service mutations, interactive workflow cutover, reconciliation, backup/restore and a future typed-evidence storage seam. Do not build the autonomous fleet, K3 stage runner, GitHub broker, EM or remote control inside this migration. |
| **Post-SQL, pre-Fleet: NSI-1–NSI-6** | Preserve `/intake` UX while adding typed source/claim provenance, code-owned ontology/rules/pre-ratification assessment, gap-directed questions, typed ACs, exact owner ratification, positive-only current receipts, explicit publication, shadow evaluation and sole-path cutover. No autonomous fleet work is hidden here. |
| **Optional side extension: NSI-E1–NSI-E4** | Add owner-confirmed **Explore alternatives** for a current eligible question and a post-publication advisory planning handoff. Each child starts only after its listed core NSI dependencies. OMP-native frozen context, isolated tool-free branches, candidate plus post-synthesis screening, hard currency-or-resource controls, exact-answer confirmation and X-A/X-B/X-C0/X-C/X-D holdout qualification; no new readiness or Fleet prerequisite. |
| **Will be implemented after NSI through FLEET-1–15** | Consume published intake contracts with matching current positive receipts; versioned harness package/CI; typed lifecycle/risk/model-history and execution-graph contracts; controller-owned graph templates and exact-input joins; graph node model routing; task-specific context compiler; stable-prefix/cache telemetry; real sandbox, per-node sandbox attestation and immutable auditor; runtime-generated evidence; deterministic verifier and candidate-bound syntax/semantic diagnostics; typed audit; fresh K3 stage lanes; local candidate vertical slice; ablation/auditor/fault qualification; GitHub broker; exact-SHA CI/merge; multi-item scheduler; bounded K3 Engineering Manager; unattended operations. |
| **Parallel non-authoritative product track: official OMP Web** | Promote the existing React/Bun/RPC application into OMP's maintained browser client: `omp web`, `/web`, shared canonical sessions/config/models, bundled compatible releases and Kimi-inspired local UX. Fixture-only work may proceed beside SQL-0 if it does not alter OMP core, WorkService, Fleet state or the migration. The broad local daemon is not published remotely. |
| **Progressive remote and Fleet consumers** | Add a separate restricted Session gateway, private read-only/replay, Needs You notifications and bounded replies first. After NSI-6 add typed intake; after FLEET-8 add live read-only Fleet; after FLEET-12 add candidate-bound review/commands. The same OMP Web shell hosts the pages while producer contracts and separate gateways preserve authority. |
| **Deferred until evidence/promotion** | Audit sampling; auto-merge/close; `split_implementation`; more than one writer per repository; nested writer agents; arbitrary/dynamic graph topology; bounded EM decision authority; broad Internet exposure; critical unattended work; native K3 resume/compaction; higher K3 concurrency. |
| **Intentionally not implemented** | Linear runtime authority; Robomp/WebUI SQLite or Agent Hub as ledger/scheduler; one privileged EM chat; model-authorized transitions or intake ratification; generic/recursive agent swarms; direct agent SQL/GitHub credentials; general remote PTY or unrestricted Fleet prompt takeover; free-form sibling state as authority; general graph/ontology/theorem-prover infrastructure solely for a label; universal solver use; in-process “Seccomp-eBPF”; automatic AST conflict resolution; fixed context-percentage partitions; majority vote as proof; fictional `pi-headroom`/`headroom-retrieve`/`stream-filter` components; copying another harness or proprietary Web bundle wholesale; a second tracker/controller; subjective score-driven complexity. |

The ordering is hard: finish and prove SQL-0; run and qualify NSI-1–NSI-6;
then submit/rebaseline the Fleet intake in a fresh OMP session. This ZIP is
downstream planning material and must not be applied concurrently to the active
PostgreSQL migration.

The only parallel exception is isolated OMP Web fixture/design work that has no
WorkService, Fleet or OMP-core side effect. This is a product track, not an
authority-chain shortcut.

## Accepted into the downstream design

| Review recommendation | Revised program location | Result |
| --- | --- | --- |
| Requirements-sufficiency gate before planning | NSI-1/3/5/6 | A Work item cannot become planner/Fleet eligible until the owner ratifies the exact semantic-closure hash, WorkService issues a current positive receipt and the intake reaches `published`. |
| Atomic claims and exact provenance | NSI-1/2; technical contract | Owner words, repository facts, tool receipts, model proposals and rule derivations remain distinct, content-addressed and revisioned. |
| Gap/counterexample-directed interviewing | NSI-3/4 | Code selects one unresolved material premise; Fable renders the question. Tool-discoverable facts never become owner questions. |
| Bounded divergent option generation | NSI-E1/E2; `03B` contract | For an eligible current question, reviewed deterministic frames drive isolated proposal branches over one frozen manifest. Code screens schema/reference/explicit-constraint failures before and after advisory synthesis on a shared bounded-model-job substrate. |
| Owner-controlled exploration UX | NSI-E3 locally; exploration routes in OWEB-7 only after N4 | Base OWEB-7 Intake is gated by NSI-6, not N4. Direct answer stays primary; the owner sees time and currency-or-resource limits, starts/cancels explicitly, compares a few neutral options and confirms the exact answer through the ordinary decision API. |
| Exploration outcome qualification | NSI-E4 | Compare no exploration, one-pass alternatives, equal-width unframed versus framed branches with the same synthesis route/prompt/limits, and a randomized deepening offer on pilot-then-holdout owner/outcome/safety/currency-or-resource measures—not breadth alone. |
| Typed AC compilation and readiness receipts | NSI-5 | Every admitted behavior maps to an observable oracle or explicit legal waiver; WorkService separates the pre-ratification assessment from a positive-only current receipt and explicit published state. |
| Owner semantic ratification | NSI-5; OWEB-7 remote client later | Solver/model agreement is not intent fidelity. Only the owner ratifies the exact `IntakeContract` hash through WorkService's current challenge. |
| Markdown as a replaceable view | NSI-2/5; Fleet/WFM consumers | Canonical typed records are stored first; human Markdown is rendered and never reparsed for authority. |
| Selective formal methods | NSI-3/6 | Typed code/graph rules first; Z3 only for demonstrated bounded hard constraints; ASP/LTL remain gated to real exception/temporal cases. |
| Intake-specific ablation | NSI-6; FLEET-9 regression | Compare current intake, practitioner interviewer, typed rules and typed-plus-selective-solvers on false-ready, omissions, question efficiency, owner burden and downstream defects. |
| Harness owns lifecycle truth rather than relying on prompts | Fleet authority doctrine; FLEET-1 and FLEET-3 | State transitions, policy, revisions and receipts remain deterministic WorkService/controller responsibilities. |
| Mechanical auditor isolation | FLEET-6; model policy | Read-only candidate/refs, disposable scratch, network denial, credential removal, no patch path and containment tests are required. |
| Runtime-generated authoritative evidence | FLEET-1 and FLEET-7; SQL review gate 8 | Controller creates a content-addressed `EvidenceManifest`; the worker cannot curate the canonical audit packet. |
| Native typed audit | FLEET-1 and FLEET-7; WFM-3/7 | `AuditResult` is validated/stored before canonical Markdown/UI rendering. Candidate/hash mismatches fail closed. |
| Preserve hardened text parser during transition | FLEET-7 and model policy | The current headed-text parser remains a compatibility bridge until RPC/task structured output passes adversarial round-trip tests. |
| Mechanical risk routing | FLEET-1 and FLEET-4; model policy | Typed `TaskRisk`, deterministic lower bound, monotonic escalation, required stages/containment/models/capabilities. |
| Task-specific context compiler | FLEET-5 | Hashed `ContextManifest`, symbol-level repository map, exact source provenance, token/redaction policy and relevant-failure selection. |
| Progressive skills and policy registry | FLEET-2 and FLEET-5 | Concise routing skills, phase references/scripts and rule records identifying runtime/tool/prompt/owner enforcement. |
| Remove redundant doctrine | FLEET-2/FLEET-5 acceptance | Runtime-enforced rules leave prompts; unevaluated or non-contributing rules/stages become deletion candidates. |
| Exact harness ablation | FLEET-9; model policy | Fixed-worker A–G experiment separates routing, intake/plan, self-review, independent audit and revised typed harness effects. |
| Independent auditor benchmark | FLEET-9 | Seeded functional, boundary, missing-test, security, concurrency, scope, cross-file and false-positive-bait cases. |
| CI protection for custom harness | FLEET-2; model policy | Required fast path for `session-system/**`, `AGENTS.md`, `.omp/**` and the extracted package. |
| Version the custom harness separately | FLEET-2 | Repository-appropriate `@theturtlecsz/omp-session-harness` package, minimal OMP shim, pinned-fork and upstream compatibility tests. |
| Use Git and exact candidate identity as protocol | FLEET-7, FLEET-10–12 | Evidence, CI, PR, audit and closeout bind to exact base/candidate tree/SHA and invalidate after mutation. |
| Evals and trace observability as product features | FLEET-9 and FLEET-15 | Deterministic PR smoke, scheduled probabilistic evals, immutable promotion runs, shadow audits and operational SLOs. |
| Workspace trust inventory | FLEET-5 | Discover `AGENTS`, skills, commands, hooks, extensions, MCP and other agent config before admitting any into trusted context. |
| Minimalism as a constraint | FLEET-1/FLEET-2/FLEET-9 | Complexity is measured against outcome improvement per dollar/minute; no extra stage survives on ceremony alone. |
| Use Vivace/K3 as a primary production resource | Fleet role policy; FLEET-2/4/6/8/9/14 | K3-256K becomes the standard fresh fleet worker/planner, full K3 the capacity/EM route, and K3 max a new long-horizon attempt—not merely an adjudicator. |
| Preserve K3-native history | FLEET-1/2/6/8; model policy | K3 initially runs fresh-only with no mixed-model continuation, resume or compaction. Failure/fallback creates a new artifact-fed attempt. |
| Qualify K3 rather than trusting plan labels | FLEET-6/9/15 | Authenticated context/output/effort discovery, provider-wire tests, quota/rate-limit telemetry and K3-vs-Flash-vs-Terra outcomes gate promotion. |
| Bounded execution DAGs | FLEET-1/3/8/13/14; model policy | Separate Work-item DAG, lifecycle state machine, per-attempt execution DAG and resource claims. Start with direct/read-discovery/verification templates; controller validates and schedules. |
| Graph-aware model routing | FLEET-4/6/8/14; model policy | Flash handles bounded local discovery, K3-256 plans/implements standard nodes, K3 1M handles portfolio or large-context reduction, Sol challenges high risk, Terra implements high risk, deterministic nodes verify/join, and fresh Opus audits. |
| Fail-closed graph joins and epochs | FLEET-1/3/7/8 | Joins require exact expected inputs bound to candidate/policy/manifest hashes. Repair or mutation creates a new epoch and invalidates downstream results. |
| Stable-prefix/cache telemetry | FLEET-5/6/9/15; model policy | Versioned immutable request prefix plus dynamic task suffix; record prefix hashes, provider cache metrics, latency, tokens, invalidations and compaction events. No universal percentage split. |
| Snapcompact is non-authoritative | FLEET-5/7; model policy | Image archives aid navigation only. Original content-addressed AC, plan, diff, log and evidence artifacts remain mandatory, especially for audit. |
| Candidate-bound syntax and semantic diagnostics | FLEET-6/7/8; model policy | Retain existing Hashline parse repair/advisory, allow temporary intermediate breakage, and fail candidate sealing on introduced supported-language parse errors plus required compiler/LSP/check nodes. |
| Per-node sandbox attestation | FLEET-1/6/7/15; model policy | Controller records image, mounts, network, credentials, process/tool policy and candidate identity before execution; missing/mismatched attestation blocks the node. |
| First-party browser client | OWEB-1..4 | The current wrapper becomes the official browser surface shipped and versioned with OMP rather than a separately installed companion. |
| One product, separate trust profiles | OWEB-1/5/7; WFM-1/2 | Local mode retains qualified interactive OMP capability; Remote Session, Work/Intake and Fleet modes receive smaller server-derived capabilities through separate gateways/service identities. |
| Terminal/browser handoff | OWEB-2/3 | `omp web` and `/web` use canonical OMP session identity; handoff changes the client, not authority or model-history policy. |
| Attention-oriented remote UX | OWEB-4/6; WFM-5/7 | Open, Needs You, Done, Running, Candidate Ready and Blocked replace transcript-watching as the primary owner workflow. |
| Durable replay and notifications | OWEB-3/6; WFM-6/7 | Cursor-bound replay, deduplication, revocable notifications and authenticated deep links support intermittent phone/browser use. |
| Candidate-bound inline review | OWEB-8; FLEET-7/10–12 | Feedback binds to candidate SHA and diff hash; applying it creates a new attempt and invalidates prior evidence. |
| Capability/version negotiation | OWEB-2/5/9 | Core, UI, gateways and runners advertise stable versions/capabilities and fail closed on unsupported combinations. |

## Adapted because the architecture changed

| Supplied statement | Corrected form |
| --- | --- |
| The current entity graph is already mechanically neuro-symbolic | It is valuable symbolic prompting, but one model still builds/interprets/lints ephemeral state. The revised model submits proposals; code owns admission/pre-ratification assessment and WorkService owns receipt/publication. |
| Satisfiable/proved means the requirement is correct | A solver establishes a property only relative to the exact encoding, assumptions and bounds. The owner decides whether that encoding expresses intended behavior. |
| A knowledge graph requires Neo4j/RDF/OWL | Store typed claims/edges/provenance relationally in PostgreSQL through WorkService. Add interchange/ontology infrastructure only for a demonstrated requirement. |
| Closed multiple choice is always better | Use short symmetric options only when exhaustive. Preserve concise free text or owner-supplied values when the domain is genuinely open. |
| More questions or a longer specification means better intake | Ask only material gaps selected by the reasoner. False-ready, critical omissions, question precision and owner correction burden are the outcomes. |
| Install ADHD as the intake reasoner | Port only isolated framed divergence, separate criticism and bounded deepening into OMP's broker and WorkService contracts. The deterministic NSI engine still finds gaps/readiness and the owner still decides meaning. |
| Let the ideation model strip “anchors” | Preserve the exact question and every admitted constraint. An assumption challenge is a labeled proposal, never a silent rewrite. |
| Use novelty/viability/fit scores to prune | Code rejects malformed references and marks explicit hard conflicts; model comparison supplies uncalibrated tradeoffs only. No score, trap label or consensus changes authority. |
| Show the model's winning answer first | Owner-decision exploration presents a small neutral set before optional advisory analysis and always permits **Use this option**, **Combine options**, **Write my own answer**, **None of these fit** or **Decide later**. Technical planning handoff may include a labeled advisory recommendation. |
| Linear is authoritative | PostgreSQL through WorkService is the sole runtime authority. Linear survives only as imported provenance. |
| Publish audit text to Linear | Store validated typed evidence/audit in WorkService; render human text through an adapter afterward. |
| Keep one NOW issue globally | One NOW item remains an interactive owner-session focus discipline. Fleet concurrency uses independent fenced claims. |
| Owner-only final transition everywhere | Interactive mode is owner-authorized. Fleet mode is controller-authorized under frozen, qualified policy. A model authorizes neither. |
| Terra is the everyday default | Interactive default remains Gemini 3.7 Flash high. After SQL-0, NSI qualification and the Fleet K3 gate, fresh K3-256K high becomes the standard multi-file fleet worker; Terra/Sol remain high/critical escalations. |
| Fable is final auditor | Current preference is fresh Claude Opus 5 high for audit; Fable remains intake/specification. Verify exact installed selectors live. |
| Gemini is the continuous advisor | Current preference is Sol high as a conditional boundary advisor; Gemini remains worker/scout. |
| “Read-only” auditor prompt is sufficient | Fresh context is useful but insufficient. Mechanical filesystem/process/network/credential/tool policy is mandatory. |
| Human-readable report is the machine protocol | Typed object is canonical; headed text is transitional input and Markdown is presentation. |
| Hardcoded 21 KB/16 KB skill size is the problem | Measure per-task compiled context, duplication, truncation and outcomes. No universal byte limit is assumed. |
| Full K3 1M is always better than K3-256K | Kimi documents the same K3 results inside 256K while full K3 uses roughly twice the quota. Route full K3 only for capacity/video/compaction avoidance. |
| Vivace means unlimited agents | Membership credits are shared and Kimi Code has rolling limits. OMP concurrency is controller policy; Kimi's hosted Agent Swarm allowance is not an OMP authorization. |
| OMP has only flat fan-out | OMP already has task batching, `workflowz`, `parallel`, barriered `pipeline`, Agent Hub and peer messaging. Build durable PostgreSQL-backed graph state and deterministic joins rather than duplicating communication primitives. |
| Every task is isolated and returns schema-validated JSON | Isolation defaults off and structured output is optional/permissive unless explicitly configured. Fleet node profiles must require and attest the exact isolation/output contract. |
| Syntax validation is missing | Hashline already parses baseline/candidate text, performs bounded repair and emits introduced-parse warnings. Strengthen candidate sealing; do not build a redundant universal pre-write parser. |
| Snapcompact bypasses context limits | It trades text for bounded image context and truncates some serialized material. Treat it as lossy navigation, never evidence or authority. |
| Attach an eBPF profile to the in-process shell | Put untrusted execution behind a process/container boundary first; attest filesystem, network, credential, syscall/LSM and resource policy there. |
| Reserve context as 20/50/20/10 zones | Provider behavior and task needs differ. Instrument exact prefixes, cache behavior and outcomes, then promote measured layouts. |
| `omp-webui` must remain a separate companion product | It may remain a separate source repository/process, but becomes OMP's official bundled and version-matched browser client with one product identity and canonical sessions. |
| Native WebUI requires React inside the agent process | Native is an install, command, session and release property. Keep browser, gateways and agent runners separate where that provides containment. |
| Borrow Kimi's WebUI wholesale | Reimplement its useful interaction model—session/workspace organization, rich tool/diff cards, background status, recovery and mobile behavior—in the existing React app. Do not copy proprietary bundles, assets or branding. |
| Use one broad Web daemon locally and remotely | Preserve the qualified full local surface; remote access uses a separately authenticated, capability-reduced gateway. |
| A remote answer is generic prompt steering | Bind normal remote answers to a current typed attention item. Generic remote chat is a distinct high-risk capability; Fleet intervention remains fenced and candidate-invalidating. |

## Deferred until evidence exists

- Z3/SMT outside demonstrated bounded Boolean, arithmetic, cardinality,
  resource, string or relational constraints. Typed rules remain the default.
- ASP until real defaults/exceptions in the local corpus show explicit
  precedence is inadequate.
- LTL/model checking until high-risk temporal/lifecycle/concurrency/safety work
  has a ratified state/event model and qualification fixtures.
- Multiple stochastic formalizations and round-trip equivalence as ambiguity
  signals. They may support questions after precision/owner-burden evaluation;
  they never become authority.
- Skipping independent audit for low-risk fleet work. Audit every candidate during qualification; later sampling requires an explicit promoted policy and ablation evidence.
- Broad Internet deployment of Fleet Manager. Private read-only, then canary commands, comes first.
- General remote takeover/prompt steering. Bounded replies to current Needs You
  items are allowed through OWEB-6; generic Remote Chat requires separate
  qualification, and Fleet intervention must pause/fence and force a new
  verification/audit.
- Critical unattended work. Security, destructive, migration, compatibility, dependency-execution and deployment classes remain owner-gated or prohibited until separately qualified.
- Multiple nested writer agents. The controller initially owns one writable worktree; only bounded read-only scouts may be promoted later.
- K3 save/resume, lossy compaction or cross-model continuation. Keep K3
  `fresh_only_no_resume_no_compaction` until OMP proves complete preserved-
  thinking behavior with regression tests.
- Raising K3 concurrency beyond two 256K workers plus one full-context slot.
  Promote from observed provider, credit, latency and quality evidence.
- Arbitrary graph topology, recursive spawning and `split_implementation`.
  Promote only after the direct, read-discovery and verification templates pass
  recovery, join, resource-conflict and budget qualification.
- Any syntax fail-fast mode inside every edit. Intermediate invalid states stay
  advisory; candidate sealing is the first mandatory syntax boundary.
- Automatic usage-consuming intake exploration, adaptive/model-authored/user-overridden or
  unqualified frame/model selection, or a preauthorized daily budget. Reviewed
  deterministic policy selection after owner confirmation is required. Consider
  contextual no-cost offers only after N4 selector-precision evidence. Paid
  auto-run requires a later owner-ratified program.

## Explicitly rejected

- The same model extracting, admitting, reasoning, linting and declaring its
  own intake `READY_FOR_RATIFICATION` assessment.
- Universal formalization, one-shot natural-language-to-Z3/Lean/LTL authority,
  or treating `SAT`/proof/model agreement as owner-intent fidelity.
- Neo4j, RDF/OWL, PDDL, a general theorem prover, trained differentiable logic
  or an intake swarm solely to claim “neuro-symbolic AI.”
- Forty-question batches, specification length, “hundreds of questions found”
  or question count as a success criterion.
- Letting a model select, submit, admit or finalize an owner decision, author
  production rules, ratify a contract or mint readiness. Models may propose
  visibly non-authoritative alternatives.
- Adding another agent merely to raise the harness score.
- Treating `/agents`, Agent Hub, transcripts, GitHub state or SQLite as the durable fleet scheduler.
- Copying Claude Code, Codex, Aider, OpenHands, Gemini CLI or Mini-SWE-Agent wholesale. Their useful lessons were translated into local requirements for lifecycle coherence, sandboxing, compact context, evaluation, workspace trust and complexity discipline.
- Confounding model and harness experiments. The first A–G ablation holds the worker fixed; model-routing comparisons run separately.
- Removing the proven headed-text parser before typed transport is demonstrated.
- Making the subjective rating or competitor comparison an acceptance criterion.
- Making K3 the final auditor of K3 code, the owner-facing intent authority, or
  the deterministic Engineering Manager/controller.
- Putting K3 in interactive `cycleOrder` while that mechanism continues a
  mixed-model transcript.
- Treating Snapcompact frames, summaries, model votes or sibling messages as
  authoritative evidence.
- Automatic AST-aware merge/conflict resolution. Prevent overlapping writers;
  use an explicit integration node and deterministic verification instead.
- In-process “Seccomp-eBPF” as a substitute for a separate execution boundary.
- Fixed context allocation percentages or nonexistent `pi-headroom`,
  `headroom-retrieve` and `stream-filter` surfaces.
- Copying Kimi's compiled/source-unavailable frontend, assets, trademarks or
  branding instead of reimplementing the interaction patterns.
- Exposing the current broad local daemon/static token on the Internet or using
  its cache/database as WorkService truth.
- Installing Orca or Agent Orchestrator as Fleet controller, scheduler,
  database or correctness authority; treating worktrees, worker `done` reports
  or model agreement as verification.
- Installing `adhd-agent` or its Claude Agent SDK runtime as a second OMP
  orchestrator; default-on ten-call intake fan-out; automatic anchor rewriting;
  random/unreplayable frames; numeric model scores/trap pruning as truth; raw
  chain-of-thought exposure; or generated options as owner decisions.

## Current model-policy intent

| Stage/risk | Route |
| --- | --- |
| Intake interview/candidate claims | Fable 5 high, non-authoritative |
| Intake alternate/ambiguity/formalization scout | Fresh K3-256K high; full K3 for capacity, read-only and non-authoritative |
| Intake exploration generation | Four fresh Gemini 3.7 Flash medium branches as initial canary; isolated/tool-free/proposal-only |
| Intake exploration synthesis | Fresh Sol high with the complete frozen manifest; neutral comparison only |
| Intake exploration deepening | Fresh K3-256K high in a separate child run for one exact option per owner authorization |
| Intake admission/pre-ratification assessment | Deterministic NSI reasoner |
| Intake semantic ratification | Human owner |
| Intake receipt/publication | WorkService, after exact-hash revalidation |
| Interactive plan | Sol high |
| Standard fleet plan | Fresh K3-256K high |
| Low/local worker | Gemini 3.7 Flash high |
| Standard multi-file fleet worker | Fresh K3-256K high |
| Repository-wide/long worker | Fresh K3 1M high |
| Exceptional long-horizon attempt | Fresh K3 1M max |
| High-risk worker | Terra high |
| Critical/stuck worker | Sol xhigh |
| Boundary advisor | Sol high, event-triggered |
| Auditor | Fresh Opus 5 high, mechanically isolated |
| Scout/task | Gemini 3.7 Flash medium/low |
| Engineering Manager | Fresh K3 1M high; max as a new scheduled attempt |
| Adjudicator | Third family; Sol/Gemini when K3 implemented |

Architecture uses role aliases. Every attempt records the exact resolved provider, model, effort and fallback; unavailable independent audit blocks rather than silently becoming self-review.
