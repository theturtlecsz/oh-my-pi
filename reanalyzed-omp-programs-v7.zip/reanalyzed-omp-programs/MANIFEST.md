# Package manifest

Package: `reanalyzed-omp-programs-v7`

Generated: 2026-08-29

Supersedes: `reanalyzed-omp-programs-v6.zip`

Purpose: implementation-ready PostgreSQL-first OMP workflow package with a
typed neuro-symbolic intake gate, autonomous Fleet Kernel and remote Fleet
Manager; official Native OMP Web distribution and restricted remote use; and
an optional, owner-confirmed **Explore alternatives** extension for genuinely
open intake decisions.

## Hard sequence

```text
SQL-0: PROVEN
  -> NSI-1..NSI-6: QUALIFIED_AND_CUT_OVER
  -> Fleet program publication/rebaseline
  -> FLEET-1
  -> gated Fleet and Fleet Manager promotion
```

The optional exploration sequence is separate:

```text
each listed core NSI dependency
  -> corresponding NSI-E1..NSI-E4 child
  -> N4 after integrated NSI-E4 + NSI-6 qualification
```

It does not gate `NSI-6`, FLEET-1 or normal `/intake`. The authority chain must
not be applied concurrently to the active SQL migration. Independent OMP Web
fixtures/design may proceed in `omp-webui` only without OMP-core, WorkService,
Fleet or migration mutations. Native local live integration is rebaselined
after SQL-0; remote Intake/Fleet/exploration features remain gated by their
typed contracts.

## Files in reading/application order

1. `00_READ_ME_FIRST.md`
2. `01_POSTGRESQL_MIGRATION_REVIEW_SUPPLEMENT.md`
3. `02_NEURO_SYMBOLIC_INTAKE_COMPILER_INTAKE.md`
4. `03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md`
5. `03A_NATIVE_OMP_WEB_INTAKE.md`
6. `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`
7. `04_AUTONOMOUS_FLEET_KERNEL_INTAKE.md`
8. `05_REMOTE_FLEET_MANAGER_INTAKE.md`
9. `06_MODEL_AND_AGENT_OPERATING_POLICY.md`
10. `07_HARNESS_RECOMMENDATION_CROSSWALK.md`
11. `08_RESEARCH_EVIDENCE_AND_DESIGN_DISPOSITION.md`
12. `09_SOLO_DEVELOPER_USER_GUIDE.md`
13. `PROGRAM_DEPENDENCIES.md`
14. `V6_TO_V7_PRESERVATION_AND_CHANGELOG.md`
15. `V6_BASELINE_SHA256SUMS`
16. `V5_TO_V6_PRESERVATION_AND_CHANGELOG.md`
17. `V5_BASELINE_SHA256SUMS`
18. `MANIFEST.md`
19. `SHA256SUMS`

## Paste-ready commands

- SQL-0 is already active; `01_...` is a review supplement, not a new intake.
- After SQL-0: paste the fenced command from `03A_...` with current `oh-my-pi`
  and `omp-webui` checkouts. Only its isolated fixture/design pass may start
  earlier under the hard-sequence exception above.
- After SQL-0: paste the fenced command from `02_...` in a fresh `oh-my-pi`
  session. This publishes core NSI plus optional NSI-E child proposals.
- As each consumed core NSI contract is stable: implement its optional NSI-E
  child against `03B_...`; N4 waits for integrated NSI-E4 plus NSI-6, while
  FLEET-1 does not wait for N4.
- After NSI-6: paste the fenced command from `04_...` in a fresh `oh-my-pi`
  session.
- After FLEET-1 contracts: paste the fenced command from `05_...` in a fresh
  `omp-webui` session.

## Integrity

`SHA256SUMS` covers every v7 file except itself. `V6_BASELINE_SHA256SUMS`
records every original v6 file hash, including v6's generated checksum file.
`V5_BASELINE_SHA256SUMS` remains the earlier immutable baseline. Verify v7 from
the package directory:

```text
sha256sum -c SHA256SUMS
```

## Evidence boundary

Repository and research anchors are pinned for reproducibility, but every
program intake must resolve current HEADs, schemas, configuration and work state
before publication. Research is advisory; the ratified intake files and typed
technical contracts govern this package.

The original v6 archive SHA-256 is
`329a66057b84ebf5542c0ffaf25f9731dade3728d31f2fdd64fb0bcd696a8570`.
See `V6_TO_V7_PRESERVATION_AND_CHANGELOG.md` for every v6 path's disposition
and the complete semantic delta. The v5 archive and its preservation record
remain part of the chain and are not rewritten except for the documented
v5 `PROGRAM_DEPENDENCIES.md` hash-transcription correction in the historical
v5-to-v6 record.
