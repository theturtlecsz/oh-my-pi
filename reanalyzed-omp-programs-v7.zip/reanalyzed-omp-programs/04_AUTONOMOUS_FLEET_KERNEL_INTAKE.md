# Paste-ready intake: Autonomous Fleet Kernel

Run this in a fresh OMP session rooted in the `theturtlecsz/oh-my-pi` checkout
only after the PostgreSQL migration reports `SQL-0: PROVEN` and the
Neuro-symbolic Intake Compiler reports `NSI-6: QUALIFIED_AND_CUT_OVER`.

```text
/intake Existing plan/draft — program-level intake.

PROGRAM TITLE

PostgreSQL-backed Autonomous OMP Fleet Kernel

CONTEXT AND PROCESS

This intake concerns:

- https://github.com/theturtlecsz/oh-my-pi
- the already-ratified PostgreSQL/WorkService migration program and its live
  records;
- the qualified neuro-symbolic intake program, its ontology/rule/schema
  versions, typed `IntakeContract`, owner ratification and readiness receipts;
- GitHub as the external code-review and CI boundary;
- omp-webui only as a future consumer of fleet contracts.

Begin by resolving and recording the actual repository HEAD, installed OMP
version, WorkService API/schema versions, migration completion report, NSI-6
qualification/cutover report, active intake schema/ontology/rule versions and
current work graph. Do not assume that the commit or architecture described in
this prompt is still current. Inspect source, documentation, tests, active
program records and effective runtime configuration.

Run this as an Existing plan/draft intake. Do not implement anything and do not
publish automatically. Complete the visible repository scan, current-state
crosswalk, threat-model pass and Socratic pass first. Ask only questions whose
answers materially change authority, safety, deployment, data loss, product
semantics or scope.

Before proposing children, query WorkService for related work. For each
capability classify it as PRESENT_AND_PROVEN, PRESENT_NOT_PROVEN, MISSING or
NOT_APPLICABLE, with evidence. Link or reuse existing work; never duplicate it.
Use a stable program idempotency key and deterministic child keys.

After owner ratification, publish one parent program and the dependency-linked
children defined below through WorkService. If SQL-0 is not PROVEN, NSI-6 is
not qualified/cut over, the typed intake consumer contracts are unavailable,
WorkService publication is unavailable, or Linear/SQLite is still an active
runtime authority, do not implement and do not publish partial children.
Produce a deterministic publication-ready manifest and stop with BLOCKED and
the exact unmet prerequisite.

OWNER-RATIFIED OUTCOME

Build an autonomous coding fleet that safely takes every eligible WorkService
item from a `published` intake run with a current owner-ratified typed
`IntakeContract` and matching positive `IntakeReadinessReceipt` to an exact,
verified, independently
audited and eventually integrated result without continuous user intervention.

“Without intervention” means no routine babysitting for work inside explicit
policy. It does not mean fabricating product requirements, bypassing evidence,
or continuing through unsafe ambiguity. Work lacking material product intent
is marked needs_spec/blocked; unsafe or exhausted work is quarantined; the
fleet continues with other eligible work and records the exact reason.

Guiding doctrine: models produce judgment, plans and code; the harness owns
state, context provenance, evidence, permissions, execution boundaries and
truth.

NON-NEGOTIABLE AUTHORITY MODEL

1. PostgreSQL through WorkService is the sole semantic writer and durable
   authority for work eligibility, dependencies, runs, stages, attempts,
   policy, budgets, row revisions, leases/fence epochs, manifests, operations,
   commands, immutable receipts, artifact metadata, audit, durable events and
   GitHub inbox/outbox intents.

2. A deterministic, restartable fleet controller is the actuator. It claims
   work through WorkService, launches stage runners, renews leases, validates
   results, submits receipts and reconciles uncertainty. It never writes SQL,
   holds a database transaction across a model call, or treats memory as truth.

3. Model agents are replaceable stage workers. They may propose, plan,
   implement, inspect, challenge and explain. They never claim work, mutate
   lifecycle state, change policy, approve their own evidence, merge, close,
   spend beyond budget or authorize an external effect.

4. A credential-isolated GitHub broker is the only GitHub writer. It consumes
   policy-approved, typed outbox intents; enforces repository, branch, base SHA,
   candidate SHA, action and fence scope; executes idempotently where possible;
   reconciles timeout-after-success; and writes exact receipts. It accepts no
   generic model-authored GitHub operation.

5. The stage runner executes exactly one run/stage/attempt from an immutable
   input bundle in an isolated controller-owned worktree/sandbox. It has a
   stage-specific tool, path, egress, time, token and cost contract. It has no
   database or GitHub credential and no lifecycle-write tool.

6. Large artifacts use a content-addressed abstraction with a local-filesystem
   implementation first and an object-store implementation later. PostgreSQL
   stores hash, size, media type, provenance and URI, not unbounded transcripts
   or logs.

7. Fleet Manager is optional supervisory infrastructure. Stopping or losing
   every WebUI process never stops safe controller recovery and never weakens a
   gate.

8. Progress is established only from external facts: WorkService revisions,
   admitted-claim and intake-contract hashes, owner-ratification and current
   readiness receipts,
   git refs/trees, exact candidate SHA, deterministic command artifacts,
   independent audit receipts, GitHub PR/CI/merge state and broker receipts.
   Agent narration is evidence at most and never advances state.

9. The controller, policy, agent definitions, prompts, tool schemas, model
   routing/fallbacks, repository/base revision, Work item revision, budgets,
   model-history/resume policy, sandbox image, allowed egress, intake contract,
   admitted-claim set, ontology/rule bundle and ratification/readiness receipt
   identities are frozen in a hashed Run Manifest.
   In-flight runs drain under that manifest; live configuration changes never
   silently alter them.

10. Every mutation or external effect has a stable idempotency key, canonical
    request hash, expected prior state/revision, recorded intent and receipt.
    On an unknown outcome, read and reconcile before retrying. Never blindly
    retry create, comment, push, PR, merge, close or policy operations.

EXECUTION AND DEPENDENCY MODEL

Keep four mechanisms explicit and separate:

1. The portfolio/work-item DAG represents dependencies among durable
   WorkService items.
2. Lifecycle finite-state machines define the legal transitions and authority
   boundaries for work, runs, stages, attempts, candidates, verification,
   audit, integration and closeout.
3. A per-attempt computation DAG represents bounded execution nodes and typed,
   content-addressed artifact flow within one immutable graph epoch.
4. Resource constraints represent repository/component/file ownership,
   worktrees, credentials, provider slots, integration locks and other things
   that cannot safely be shared concurrently.

Do not disguise a resource collision as a data-dependency edge. Do not use a
live sibling-agent bus or mutable shared agent state: if one node needs another
node's output, encode that need as an explicit typed artifact edge. The
controller instantiates only code-owned, versioned graph templates; validates
acyclicity, inputs, joins, budgets, capabilities and resource claims; and owns
all graph state. A model may propose a template and parameters but may not
execute arbitrary topology.

Freeze the computation DAG before its epoch starts. Every node has typed
inputs/outputs, an exact model/tool/sandbox/budget profile, expected terminal
outcomes and declared resource claims. Joins fail closed on missing, duplicate,
failed, stale or candidate-mismatched inputs. Any repair or mutation that
changes the candidate creates a new graph epoch and invalidates downstream
verification and audit results; it never edits a running graph in place.

POSTGRESQL AND INTAKE PREREQUISITES: SQL-0 + NSI-6

Confirm all of the following from evidence before publication:

- WorkService is the sole work authority and interactive owner workflow is cut
  over end to end;
- Linear runtime credentials and fallback paths are disabled;
- Robomp's production SQLite authority is quiesced/disabled or has a bounded
  compatibility retirement path;
- imported data reconciliation, backup and restore are proven;
- API/schema versions and generated contracts exist;
- no agent/browser/shell has direct SQL access;
- no uncontrolled dual writer remains.

Also confirm from typed evidence:

- the neuro-symbolic intake path is the sole WorkService publication path for
  new/rebased work;
- active ontology, rule bundle, contract, ratification and readiness schemas
  are versioned and available through generated consumer contracts;
- every premise contributing to `READY_FOR_RATIFICATION` has provenance and
  seeded critical-omission evaluation
  produced zero false-ready results under the qualified corpus/version;
- a current eligibility query rejects missing, conflicted, stale, invalid or
  contract/hash-mismatched receipts;
- models and the Engineering Manager cannot admit owner claims, ratify meaning
  or mint positive readiness receipts;
- Markdown remains a projection and cannot authorize work.

Do not recreate the migration, generic work/dependency CRUD, qualified typed
`/intake`, `/plan`, `/summary` or `/done` behavior, intake ontology/reasoner/
ratification/readiness engine, Linear removal, or the database backup framework
in this program. Consume the published NSI contracts and add only fleet-domain
extensions.

CURRENT OMP AND ROBOMP REUSE PASS

Inspect rather than rebuild OMP's existing agent/RPC runtime and current
model-bookend/auditor work.

Prefer extracting or reusing, behind new interfaces and tests:

- the typed `omp-rpc` Python client, protocol negotiation, request correlation,
  bounded event histories, cancellation and host-tool support;
- Robomp worktree/sandbox lifecycle, slot/user isolation, environment scrubbing,
  redaction, pre-push validation and HMAC credential-broker patterns;
- Robomp GitHub parsing/client behavior, deduplication, reconciliation and
  fault-oriented tests;
- the current cold auditor semantics and five-input bundle, retaining its strict
  parser only as a compatibility bridge until typed transport is proven;
- OMP task-agent definitions, role aliases, advisors and bounded read-only
  scouts where they fit inside one stage.

Replace or explicitly reject:

- SQLite as fleet authority;
- in-process `_inflight`, `BEGIN IMMEDIATE`, process-local cancellation or
  Agent Hub as distributed correctness;
- GitHub issues, labels, branches, transcripts, todo state or JSONL as the work
  ledger;
- random model selection from a CSV pool;
- one persistent generalist transcript for an issue's full lifecycle;
- model-callable GitHub mutation tools;
- Robomp's dashboard as a second fleet console;
- mutating Robomp in place without a reuse/retirement boundary.

Create a separate fleet package/process and extract shared primitives rather
than carrying two schedulers. Let the inspected post-migration language and
package layout determine whether the controller remains Python or uses an
existing repository language; do not introduce another framework merely for
novelty.

STAGE PIPELINE

Do not emulate interactive slash commands in headless runs. The controller
launches fresh top-level OMP RPC sessions with immutable typed artifacts.

1. PREFLIGHT — deterministic. Confirm item revision, `published` intake state,
   current typed `IntakeContract`, admitted-claim set, owner ratification and
   matching `IntakeReadinessReceipt` whose result is
   `ELIGIBLE_FOR_PUBLICATION`; reject missing, unpublished, stale,
   conflicted, invalid or hash/version-mismatched intake state. Then confirm dependencies, eligibility,
   repository/risk policy, base SHA, locks, budget, provider availability and
   manifest. Pin the starting tree and pre-existing dirty state. No model
   decides eligibility or repairs intake by assumption.

2. PLAN — fresh planner. For standard fleet work begin with K3-256K high; for
   high/critical risk use Sol high. Produce typed assumptions, ordered steps,
   component/file impact, invariants, risks, verification commands and
   AC-to-step mapping.

3. PLAN_GATE — deterministic schema/policy validation. Invoke a fresh,
   different-family plan critic only for configured risk classes such as
   security/auth, concurrency/distributed state, migrations/destructive work,
   public API compatibility, release/deploy or broad cross-subsystem change.

4. IMPLEMENT — fresh worker with write access only to the controller-owned
   worktree. K3-256K high is the normal standard multi-file route; full K3 high
   is the large-context capacity route; Flash is the trivial/local speed lane;
   Terra/Sol own high/critical routes. No push or lifecycle mutation. The
   controller validates the tree and records an exact candidate commit.

5. VERIFY — a deterministic per-candidate computation DAG outside the model.
   The initial `verification_diamond` fans the exact candidate out to required
   test, build/type, security/static and diff/scope nodes, then uses an
   all-required-inputs evidence join before audit. Repositories may serialize
   nodes whose tools or resources conflict, but may not omit a required input.
   Capture command, environment/image, exit status, bounded logs, baseline-
   relative syntax/LSP diagnostics and artifact hashes. A missing node, stale
   result, newly introduced syntax error or test failure blocks regardless of
   model opinion.

6. AUDIT — fresh independent model/process in a mechanically immutable,
   credential-free, network-denied profile. The runtime constructs and supplies
   a content-addressed `EvidenceManifest`; the worker never assembles the
   canonical packet. Withhold the worker's self-assessment. The auditor returns
   a native typed `AuditResult` bound to candidate tree and Run Manifest. Code
   validates it before rendering human text. An auditor never repairs.

7. REPAIR — a fresh worker receives evidence-backed findings. Prefer a
   different-family repair trajectory after a failed K3 attempt when policy
   warrants escalation. Any mutation creates a new candidate and invalidates
   verification/audit/approval receipts.
   Re-run verification and launch a fresh audit. Bound cycles, time, tokens and
   cost; detect plateau/oscillation; quarantine on exhaustion.

8. INTEGRATE — only after later promotion. The broker creates/updates the exact
   PR, reconciles CI, serializes integration and validates evidence again.
   Rebase or base advance invalidates candidate-bound receipts.

9. CLOSEOUT — only after exact candidate, verification, audit, CI, policy,
   approval/capability and merged-state predicates still match. WorkService
   records completion only after external merge is reconciled.

Initially disable recursive delegation and nested writer worktrees. Later, a
planner or implementer may launch a small allowlisted number of read-only scouts
with explicit budgets and forwarded telemetry. Final audit is always a
controller-launched top-level fresh process, never a worker-spawned child.

K3 stages have a stricter initial history policy. Begin K3 before the first
assistant turn of the stage; never switch a foreign transcript into K3 or
switch away and back. Until OMP proves preserved-thinking replay across normal
turns, tool loops, restart/resume and compaction, K3 stages are
`fresh_only_no_resume_no_compaction`. A crash, model/effort change or fallback
creates a new attempt rehydrated from immutable artifacts rather than
continuing the prior transcript.

ROLE AND MODEL POLICY

Use role aliases and policy tiers; do not hardcode vendor model IDs into state
machines. Freeze both requested and resolved provider/model/effort/fallback in
the attempt manifest.

Recommended initial routes:

- specifier/intake: `@intake` -> Claude Fable 5 high, owner-facing candidate
  claim extraction and question rendering only;
- optional intake alternate/scout: fresh `@fleet_worker` K3-256K high, or
  `@fleet_long` K3 1M high only when compiled input capacity requires it;
  read-only, non-authoritative and unable to admit claims, declare readiness or
  ratify intent;
- intake reasoner/readiness: deterministic NSI engine, not a model role;
- interactive owner planner: `@plan` -> GPT-5.6 Sol high;
- standard fleet planner: `@fleet_plan` -> Kimi K3-256K high;
- trivial/local implementer: `@default` -> Gemini 3.7 Flash high;
- standard multi-file implementer: `@fleet_worker` -> Kimi K3-256K high;
- repository-wide/long implementer: `@fleet_long` -> Kimi K3 1M high;
- exceptional long-horizon attempt: `@fleet_max` -> Kimi K3 1M max;
- high-risk implementer: `@high_worker` -> GPT-5.6 Terra high;
- critical/stuck implementer: `@slow` -> GPT-5.6 Sol xhigh;
- independent auditor: `@audit` -> Claude Opus 5 high;
- boundary advisor: `@advisor` -> GPT-5.6 Sol high;
- cheap read-only scout/task: `@task` -> Gemini 3.7 Flash medium;
- Engineering Manager: `@fleet_manager` -> Kimi K3 1M high, with max only for
  a new scheduled deep-synthesis attempt;
- adjudicator: a third family relative to worker and auditor; use Sol/Gemini
  when K3 implemented the candidate;
- commit text/low-risk transforms: GPT-5.6 Luna low.

Resolve exact selectors with the installed `/models` inventory and pin the
resolved route in the Run Manifest. Sol advice is event-triggered at high-value
boundaries such as plan handoff, first failed verification, material plan
deviation, unexpectedly broad diff and pre-audit; it is not a noisy always-on
completion gate.

A fallback is a recorded attempt transition, not a silent continuation. Audit
policy must reject any resolved auditor model/family that violates independence
from the worker. If worker and auditor disagree on evidence, use a third-family
adjudicator; do not majority-vote model opinions.

Do not put K3 roles in interactive `cycleOrder`: cycling continues an existing
mixed-model transcript. The interactive owner workflow should eventually add a
controller-owned `/implement` handoff that seals plan/context artifacts and
launches a fresh K3 stage. Until then, keep Flash as interactive `default` and
invoke K3 only through fresh named agents/processes.

Use `k3-256k` whenever the compiled context and expected tool trajectory fit
with safe headroom. Full `k3` consumes roughly twice the membership quota and is
a capacity route, not a quality upgrade inside 256K. Pin `high` throughout a
normal attempt and use `max` only in a fresh attempt. Authenticated model
discovery must show the effective Vivace entitlement, low/high/max effort and a
131,072 output cap before promotion. Initially cap provider concurrency at two
K3-256K workers plus one full-context K3 worker; raise it only from observed
rate-limit, shared-credit, latency and quality telemetry. Do not treat Kimi's
hosted Agent Swarm allowance as OMP fleet concurrency.

Validate these assumptions against the current official Kimi Code model and
membership documentation and against OMP's open K3 preserved-history work:

- https://www.kimi.com/code/docs/en/kimi-code/models.html
- https://www.kimi.com/help/membership/membership-overview
- https://github.com/can1357/oh-my-pi/issues/5847
- https://github.com/can1357/oh-my-pi/issues/6711

Use a separate fleet HOME/`PI_CODING_AGENT_DIR`, trusted fleet-owned agent
definitions, explicit extension/tool/skill allowlists and fleet doctrine. Do not
weaken the owner's interactive OMP profile. Repository-local instructions,
agents, skills, hooks and configuration are untrusted unless admitted by the
Run Manifest; they cannot shadow trusted fleet roles.

MECHANICAL RISK ROUTING

Implement a versioned deterministic policy engine that produces a typed
`TaskRisk` from admitted intake claims, recorded unknowns and repository/tool
facts before planning, then recomputes it after planning and implementation.
Raw issue prose or model narration may suggest an escalation but cannot lower
the claim-derived risk floor:

interface TaskRisk {
  level: "low" | "standard" | "high" | "critical";
  reasons: string[];
  requiresPlan: boolean;
  requiresIndependentAudit: boolean;
  requiresSandbox: boolean;
  requiresOwnerApproval: boolean;
  workerRole:
    | "default"
    | "fleet_worker"
    | "fleet_long"
    | "fleet_max"
    | "high_worker"
    | "slow";
  plannerRole: "plan" | "fleet_plan";
  modelHistoryPolicy: "fresh_only_no_resume_no_compaction" | "native_resume";
  specialistReviews: string[];
}

- Low: Flash high, deterministic checks, no Sol advisor unless triggered.
- Standard: fresh K3-256K high for multi-file planning/implementation,
  deterministic checks and independent Opus audit; Flash remains the
  trivial/local speed lane.
- High: Sol planning/advice, Terra high worker, hardened sandbox, Opus audit and
  relevant specialist review.
- Critical: Sol xhigh, owner authorization unless a narrow pre-authorized fleet
  policy explicitly covers it, hardened sandbox, Opus audit and adjudication.

New facts may only preserve or raise risk within an attempt. A model may suggest
an escalation but may not lower computed risk. Automatic triggers include two
failed verification loops, material plan deviation, security/auth changes,
destructive behavior, schema/data migration, public compatibility, concurrency/
distributed state, dependency execution, release/deployment, unexpectedly
broad diff, auditor BLOCKED, or a critical/high finding.

Retain independent audit for all fleet code work during qualification. Any
future low-risk audit sampling or omission requires ablation evidence and an
explicit promoted policy version.

Risk and context capacity are orthogonal. A large repository may select full
K3 without becoming high risk; a tiny authentication, migration or concurrency
change remains high/critical even if it fits in the 256K route.

AUTHORITATIVE CONTEXT, EVIDENCE AND AUDIT PROTOCOL

The harness, not a worker model, compiles canonical context and evidence.

`ContextManifest` identifies the exact Work item revision, intake contract and
receipt hashes, admitted claims, owner decisions, acceptance criteria,
ontology/rule versions, referenced source evidence, plan/hash, lifecycle/risk
state, admitted rule IDs, symbol-level repository map, selected files and
provenance, relevant failed attempts, tool/safety contract, ordering, redaction,
token budget and content hashes. Raw unadmitted issue prose remains a labeled
untrusted source artifact, never a control instruction or hidden premise.

`EvidenceManifest` identifies schema/run/work/stage/attempt, plan hash, base and
candidate commit/tree, dirty baseline, changed paths, content-addressed diff,
required verification commands and exit codes, stdout/stderr artifacts,
acceptance-criterion evidence references, and context/policy/model/sandbox/Run
Manifest hashes.

`AuditResult` identifies schema/run/candidate/manifest, PASS/NEEDS_FIX/BLOCKED,
typed severity findings with AC and evidence references, unverified claims,
recommended scope and confidence. WorkService stores the validated object and
the harness renders Markdown afterward through a sink adapter.

`GraphTemplate`, `ExecutionGraphManifest`, `NodeSpec`, `ArtifactEdge`,
`JoinPolicy`, `ResourceClaim`, `NodeResult` and `GraphEpoch` identify the
code-owned template, immutable topology, expected input cardinality, typed
artifact schemas, node policy/budget, resource exclusions, result identity and
candidate-bound invalidation rules.

`SandboxProfile` and `SandboxAttestation` identify intended versus observed
writable/read-only paths, process and syscall restrictions, egress, secret
exposure, image/runtime, resource ceilings and policy violations. Acceptance
is behavioral and backend-neutral; the contract must not assume that seccomp,
eBPF, a container, worktree, microVM or WASM alone proves containment.

`ContextCachePolicy` and `ProviderCacheTelemetry` identify the versioned stable
prefix layout, section/content hashes, provider/model eligibility, cache reads,
writes and hits when exposed, latency/token/credit effects and any fallback.
Provider caches are optimizations, never authority, and a cache miss never
changes lifecycle semantics.

Do not re-enable the current task-agent `outputSchema` path merely because a
typed protocol is desired; first fix and regression-test the transport that has
previously mangled headed reports. Until then, the strict headed-text parser is
a compatibility bridge, never the target protocol.

CONTEXT ENGINEERING AND POLICY REGISTRY

Do not solve context failures by accumulating more universal doctrine. Build a
deterministic task-specific context compiler with a compact symbol/signature
repository map informed by LSP/imports/references/tests/ownership/failures.
Carry only relevant previous attempts rather than the full transcript.

Compile canonically ordered, versioned stable sections before task-dynamic
sections so supported providers can reuse prompt caches without changing
meaning. Preserve exact omitted material behind content-addressed retrieval
handles. Measure provider-reported cache behavior and outcomes; do not hardcode
universal context percentages, cache lifetimes or vendor assumptions. Visual
or lossy compaction may be evaluated for a qualified model, but it is never the
canonical representation of source, policy, evidence or lifecycle state.

Refactor large skills into concise routing `SKILL.md` files with phase-specific
references and deterministic scripts. Every rule has a registry record:

interface HarnessRule {
  id: string;
  scope: string[];
  enforcement: "runtime" | "tool-policy" | "prompt" | "owner";
  originWorkItem?: string;
  evaluationId?: string;
  lastValidatedAt?: string;
}

When code/tool policy enforces a rule, remove its duplicated normative prompt
text apart from a short explanatory reference. Track context size, duplication,
truncation and per-model task outcomes in CI/evaluations; calibrate limits from
evidence rather than hardcoded folklore.

SECURITY AND CONTAINMENT

- One controller-owned worktree/sandbox per run/attempt; exact base/candidate
  identity; safe symlink/hardlink/path handling; no host home or Docker socket.
- Enforce and record a typed SandboxProfile/SandboxAttestation for every stage;
  filesystem, process, network, secret and resource boundaries require
  independent behavioral tests rather than trust in a named isolation
  technology.
- Network deny by default with manifest-pinned egress exceptions. Dependency
  installers, hooks, build scripts, tests and their output are hostile surfaces.
- Provider credentials may be available only to the trusted OMP/provider layer,
  never to model-visible environment, shell tools, repository processes,
  transcripts or artifacts.
- Work text, comments, repository files, `AGENTS`, tool output, logs, web/MCP and
  dependencies are untrusted data. Never interpolate them into trusted control
  instructions. Typed envelopes and host validation enforce control flow.
- Headless prompts, approvals or package-install confirmations fail closed.
- Tool contracts enumerate input/output schema, paths, egress, time/token/cost
  budget, retry class and terminal outcomes. Short, non-overlapping tool sets.
- Global, repository and work-item pause/drain/kill controls use durable stop
  epochs/fencing checked before every claim, transition and external effect.

ENGINEERING MANAGER

The Engineering Manager is not a long-lived privileged chat or the scheduler.
It is a periodic/event-triggered fresh reasoning stage over a bounded portfolio
projection. It returns versioned typed proposals such as:

- select/rank eligible work;
- decompose a draft into candidate children/dependencies;
- assign risk and model tier;
- retry, repair, block, quarantine or escalate;
- identify missing acceptance decisions.
- propose candidate intake claims, alternate interpretations or clarification
  intents for owner review.

WorkService/controller validates every proposal against revisions,
dependencies, locks, budgets, policy and safety, records proposal versus final
decision, and alone applies accepted effects. The EM has no SQL, GitHub, merge,
policy-promotion, kill/resume or credential capability. It cannot admit claims,
answer an owner question, waive a requirement, ratify an `IntakeContract` or
mint readiness. Missing product intent produces questions/drafts, never an
auto-ratified ready item.

The initial EM model route is fresh K3 1M high because repository/portfolio
context and long-horizon synthesis are its intended strengths. Use max only as
a new scheduled attempt. K3's tendency toward proactive decisions makes the
typed proposal/validation boundary mandatory, not optional.

Initially the EM may choose and parameterize only controller-owned templates
such as `direct`, `verification_diamond` and `read_discovery_diamond`;
`split_implementation` remains disabled until parallel writers are separately
qualified. The EM may not publish arbitrary graph code, create live sibling
state channels or authorize a graph revision after an epoch starts.

REQUIRED PROGRAM CHILDREN

Publish exactly one parent and these children unless the current-state
crosswalk proves an existing item should be linked instead. Preserve the
dependency graph; do not flatten it into a chain.

FLEET-1 — Authority, typed contracts and promotion policy

Define before implementation:
- consume and pin the qualified NSI `IntakeContract`, admitted-claim,
  `IntakeReadinessAssessment`, `RatificationReceipt`, `RatifiedFormalBinding`,
  positive `IntakeReadinessReceipt` and `IntakePublicationReceipt` schemas plus the exact downstream eligibility
  predicate, including `published` state and server-calculated receipt
  currentness; do not redefine intake authority;
- legal state machines for work, run, stage, attempt, candidate, verification,
  audit, external operation, integration and closeout;
- versioned RunManifest, StageInput/Result, TaskRisk, ContextManifest,
  EvidenceManifest, VerificationReceipt, AuditResult, HarnessRule, ModelRoute,
  ModelHistoryPolicy and external intent/receipt schemas;
- versioned GraphTemplate, ExecutionGraphManifest, NodeSpec, ArtifactEdge,
  JoinPolicy, ResourceClaim, NodeResult and GraphEpoch schemas, explicitly
  separate from the portfolio DAG, lifecycle state machines and resource
  constraints;
- versioned SandboxProfile/SandboxAttestation and ContextCachePolicy/
  ProviderCacheTelemetry schemas;
- authority/threat ADRs, eligibility and action-risk/capability matrices;
- rule registry with enforcement layer and evaluation provenance;
- Fleet Manager read/command/event contracts;
- promotion thresholds, complexity/deletion criteria and explicit non-goals;
- OMP/Robomp reuse-retirement and harness-package boundary ADRs.

Acceptance includes model-based transition tests, stale/missing/conflicted/
hash-mismatched intake receipt tests, and proof that no second ledger,
uncontrolled writer, intake reinterpretation or model authority is introduced.

Depends on: SQL-0 and NSI-6.

FLEET-2 — Versioned harness package and CI protection

Create `@theturtlecsz/omp-session-harness` or the repository-appropriate
equivalent containing lifecycle enforcement, role/risk routing, context/evidence/
audit schemas, policy registry, WorkService adapter boundary, agents, skills,
tests and evaluation fixtures. Keep only the minimum compatibility shim for OMP
hooks that cannot yet be upstreamed.

Package the qualified typed intake extension, schema/rule consumer bindings,
question renderer and compatibility tests from NSI rather than copying its
rules back into prompts. Fleet-facing code may query current intake state but
cannot expose an admission/ratification bypass.

Maintain a machine-readable inventory and review budget for every remaining
core-fork patch. Prefer public extension hooks, upstream generic seams and
versioned compatibility adapters over embedding fleet policy in upstream
runtime files.

Add source-controlled aliases/agents for `@fleet_plan`, `@fleet_worker`,
`@fleet_long`, `@fleet_max` and `@fleet_manager`. K3 agents require fresh top-
level sessions, explicit effort, no cross-model continuation and strict typed
input/output/tool contracts.

Refactor monolithic skills into concise routers with progressive references and
scripts while preserving parity for interactive `/intake`, `/plan`,
`/summary` and `/done`. WorkService is the sole production tracker adapter;
there is no active Linear fallback.

Add required fast CI for `session-system/**`, the harness package, `AGENTS.md`,
`.omp/**`, installer/configuration checks, typecheck/lint and compatibility
against both the pinned fork and a regularly tested upstream revision. Require
the fast job on main. Run expensive probabilistic evaluations on schedule or
promotion, not every pull request.

Depends on: FLEET-1.

FLEET-3 — WorkService FleetControl kernel

Extend the existing WorkService, without creating another tracker or generic
database API, to own:
- Fleet eligibility bound to `published` intake state, a current owner-ratified
  `IntakeContract`, admitted-claim set, all required current
  `RatifiedFormalBinding` records, matching `ELIGIBLE_FOR_PUBLICATION` receipt
  and current `IntakePublicationReceipt`;
- runs, stages, attempts, candidates and server-side eligibility;
- immutable graph epochs/topology, node attempts, expected input counts,
  artifact satisfaction, joins, node budgets, leases and fencing;
- atomic claims, expiring leases, monotonic fence epochs and CAS revisions;
- frozen manifest, policy, budget, risk and model-route snapshots;
- content-addressed context/evidence/verification/audit metadata;
- immutable receipts, quarantine and durable cancellation;
- pause/drain/stop epochs;
- external inbox/outbox intents and reconciliation state;
- durable event journal, cursor, audit, retention and consumer projections.

Validate schema versions and candidate/manifest bindings. Use short transactions.
Advisory locks or notifications may optimize but are not correctness. Multiple
controllers must be safe without process-local leadership.

Depends on: FLEET-1.

FLEET-4 — Mechanical risk and capability router

Implement the deterministic versioned TaskRisk engine described above. Compute
the risk floor from admitted intake claims, recorded unknowns and qualified
repository/tool observations before planning, then recompute after planning and
implementation. Risk may only
stay level or escalate within an attempt. Select required stages, role aliases,
containment, approval, specialist review, independent audit, retry ceilings and
external capability; freeze policy version and reasons in the Run Manifest.

Keep risk selection distinct from context/model-capacity selection. For
qualified standard work choose K3-256K; promote to full K3 only when compiled
context/tool-trajectory thresholds require it; retain Flash for trivial/local
work and Terra/Sol for high/critical risk. A K3 route always selects the
fresh-only history policy until separately qualified.

Critical work remains owner-gated or prohibited until a narrow policy is
separately qualified. Tests cover every escalation trigger, ambiguous
classification, model attempts to lower risk and policy-version changes.

Depends on: FLEET-1 and FLEET-2.

FLEET-5 — Context compiler and symbol-level repository map

Build a deterministic compiler producing a hashed ContextManifest and immutable
stage-specific context pack containing only exact Work/intake/AC revision,
current contract/ratification/readiness identities, admitted claims and their
referenced evidence, owner decisions, approved plan/hash, lifecycle/risk state,
admitted rules, stage tool/safety
policy, compact symbol map, files selected from imports/references/tests/
ownership/failures and relevant prior failed attempts.

Requirements:
- LSP/import/reference-aware symbol/signature map;
- provenance, precedence, token budgets, ordering, truncation and redaction;
- canonical stable-prefix/dynamic-section layout with section hashes,
  content-addressed retrieval handles and provider-cache telemetry, without
  fixed vendor-specific context percentages;
- discovery inventory for AGENTS, skills, commands, hooks, extensions, MCP and
  cross-ecosystem configuration before trust;
- no interpolation of untrusted content into trusted control instructions;
- deterministic injection, conflict, stale-context, huge-repository and
  secret-leakage tests;
- measured context duplication and per-model outcome telemetry.

Depends on: FLEET-2 and FLEET-4.

FLEET-6 — Stage runner and mechanical containment

Deliver fresh top-level OMP stage execution with:
- one immutable bundle and controller-owned worktree per attempt;
- OS/container sandbox enforcing writable paths, process capabilities and egress;
- network denied by default;
- trusted provider access without credential exposure to model shell processes;
- stage-specific tools, paths, budgets, role, prompt and compiled context;
- no WorkService/GitHub/controller/deployment credentials;
- exact cancellation, deadline, crash and artifact behavior;
- an immutable auditor profile with read-only candidate/refs, disposable scratch,
  no network, no patch-apply route and no general shell where a dedicated
  allowlisted inspection tool suffices;
- containment telemetry where any mutation attempt is a policy violation.

Every stage emits a SandboxAttestation bound to its profile, attempt, image and
Run Manifest. Implement containment by capability and verified behavior rather
than requiring a single Linux-specific mechanism.

Add a K3 compatibility qualification suite before K3 becomes the standard
worker. It must verify authenticated `k3`/`k3-256k` context, 131,072 maximum
output, low/high/max wire effort, normal and multi-tool reasoning-history
replay, cache/model/effort stability, and explicit behavior for crash, resume,
compaction and cross-model selection. Until native resume is proven, the runner
must reject K3 `--continue`, compaction and mixed-model history and instead
start a new artifact-fed attempt.

OMP task/worktree isolation alone is not proof of OS containment.

Depends on: FLEET-2.

FLEET-7 — Authoritative evidence, deterministic verification and typed audit

Implement the machine-owned protocol:
- controller constructs EvidenceManifest; worker never assembles its canonical
  evidence packet;
- runtime records item revision/AC hash, plan hash, dirty baseline, base and
  candidate commit/tree, changed paths, diff hash, verification argv/cwd/image,
  exit codes and stdout/stderr artifacts, AC evidence refs and context/policy/
  model/sandbox/Run Manifest hashes;
- deterministic verification executes outside the model against exact candidate;
- verification runs through the immutable `verification_diamond`; every node
  emits a typed, candidate-bound NodeResult and the join rejects missing,
  duplicate, failed, stale or wrong-epoch inputs;
- capture baseline parser/LSP diagnostics before mutation and candidate
  diagnostics afterward in a typed verification receipt; policy blocks newly
  introduced syntax errors while distinguishing pre-existing diagnostics;
- optionally return immediate parser/LSP feedback from a scratch/in-memory
  candidate to the editing tool, but do not make universal pre-write rejection
  authoritative until FLEET-9 demonstrates benefit across supported languages;
- auditor uses the immutable FLEET-6 profile and receives no worker self-defense;
- auditor returns native typed AuditResult bound to candidate/evidence/manifest;
- code validates and stores the object before canonical human rendering;
- WorkService receives the typed object directly through its adapter;
- any mutation, base advance, rebase, manifest or policy change invalidates
  candidate-bound evidence;
- repair creates a new candidate, re-verification and fresh auditor process;
- worker/auditor family independence is mechanically enforced.

Fix and adversarially regression-test RPC/task structured-output transport before
retiring the strict headed-text compatibility parser.

Depends on: FLEET-3, FLEET-5 and FLEET-6.

FLEET-8 — One-item, zero-external-write vertical slice

Hard-cap concurrency to one. Against one manually seeded low-risk canary item
with a `published` intake run, current owner-ratified contract, matching
`ELIGIBLE_FOR_PUBLICATION` receipt and `IntakePublicationReceipt`, prove that
planning is refused when state is unpublished or any contract/receipt is
missing, stale, conflicted, invalid or hash-mismatched, then prove:

claim -> mechanical risk -> context compile -> plan -> plan gate -> implement ->
exact candidate -> verification diamond/evidence join -> typed immutable audit
-> bounded repair -> CANDIDATE_READY or QUARANTINED.

No GitHub writes, merge, close, Engineering Manager, WebUI or nested writer
agents. Kill controller and runner before/after every durable boundary; recover
from WorkService/artifacts rather than conversation state. Repeated runs must
produce the same canonical input/evidence manifests for the same facts.

Use fresh K3-256K high as the primary standard worker in this slice only after
FLEET-6 K3 qualification passes. Include a forced process death proving that
recovery creates a new attempt from artifacts rather than resuming K3 history.

Depends on: FLEET-3, FLEET-4, FLEET-5, FLEET-6 and FLEET-7.

FLEET-9 — Outcome evaluation, ablation, auditor benchmark and fault qualification

Use OMP's metaharness instead of inventing another evaluation runner. Build
30–50 frozen historical tasks spanning localized bugs, ambiguous intake,
multi-file features, migrations, difficult debugging, resume, security/
concurrency and seeded defects.

Run fixed-worker arms:
- A: bare OMP plus repository instructions;
- B: A plus role routing;
- C: B plus intake and approved plan;
- D: C plus worker self-review, no independent auditor;
- E: C plus independent auditor, no self-review;
- F: current full text/evidence harness;
- G: typed context/evidence-native, mechanically contained revised harness.

Hold the worker model fixed for the first experiment; compare model routing as a
separate factor. The first routing matrix compares K3-256K high, Flash high and
Terra high on the same standard corpus. Test full K3 high/max only on the
large-context/long-horizon subset. Measure hidden/AC success, first/final pass,
intervention, scope drift, regressions, recovery, turns, tokens, cost, latency
subscription credit/rate-limit behavior and improvement over bare OMP per
dollar/minute.

Add a dedicated auditor corpus with functional, boundary, missing-test, security,
concurrency, scope-expansion, cross-file/interface and false-positive-bait
defects. Measure severity recall, unsupported findings, BLOCKED calibration,
evidence quality, adjudicated validity and cost per real defect.

Also include all fencing, idempotency, crash, stale-result, injection, sandbox,
credential, malformed-output, provider/database/GitHub and budget fault tests.
Use fast deterministic PR smoke, scheduled full evals, immutable promotion runs
and post-promotion shadow audits.

Add controlled experiments for:
- sequential verification versus `verification_diamond`, measuring critical-
  path improvement, orchestration overhead and identical evidence coverage;
- candidate-bound syntax/LSP verification versus immediate baseline-relative
  edit feedback, measuring repair loops, false rejections and final outcomes;
- existing prompt layout versus stable-prefix/cache-aware compilation,
  measuring provider cache reads/writes/hits when exposed, token/credit use,
  latency and task success.

Consume the qualified NSI-6 intake results and rerun a Fleet-specific intake
eligibility regression using the same frozen intake corpus:

- current prompt-owned intake;
- practitioner requirements interviewer/decision log;
- typed claims and code-owned rules;
- typed claims/rules plus only selectively qualified formal adapters.

Measure false-ready as the primary failure, critical omissions, provenance
closure, AC coverage, material/redundant questions, owner correction burden,
key-question efficiency, plan deviations and downstream audit findings caused
by intake. Fleet promotion requires zero false-ready outcomes on the versioned
seeded critical-omission corpus and complete provenance for every premise
contributing to a `READY_FOR_RATIFICATION` assessment;
do not invent the remaining thresholds before baseline data exists.

Graph fault qualification must cover missing/duplicate inputs, partial node
failure, stale or late node results, wrong candidate/epoch, topology mutation,
join replay after controller death and node/graph budget exhaustion. Promote no
graph or cache optimization solely from lower latency if correctness regresses.

Depends on: FLEET-8.

FLEET-10 — GitHub broker and reconciliation boundary

Deliver a credential-isolated broker with typed branch/push/PR/comment/check/
merge/close operations; exact repository/base/branch/candidate/manifest/fence/
risk/capability validation; stable operations; unknown-outcome reconciliation;
GitHub App or equally scoped credentials; durable inbox/outbox and receipts; and
no model-callable generic mutation or controller-held GitHub credential.

Development may proceed while qualification runs, but external writes remain
disabled until FLEET-9 passes.

Depends on: FLEET-3, FLEET-6 and FLEET-7.

FLEET-11 — One-item draft-PR-only canary

For one allowlisted low-risk item, permit only exact-candidate branch push and
draft PR create/update with sanitized evidence link. Merge and WorkService
completion remain manual. Prove duplicate/restart/timeout reconciliation and
evidence invalidation after base movement.

Depends on: FLEET-9 and FLEET-10.

FLEET-12 — Exact-SHA CI, integration, merge and closeout

Deliver exact workflow/SHA CI receipts, serialized integration, branch advance/
rebase/merge-conflict invalidation with complete reverify/re-audit, ambiguous
merge reconciliation, completion only after exact merged result is observed, and
capability progression from manual merge to allowlisted low-risk auto-merge.

Security/auth, migrations/destructive work, public compatibility, dependency
execution, release/deploy and secrets remain manual/prohibited until separately
qualified.

Depends on: FLEET-11.

FLEET-13 — Bounded multi-item scheduler

Add dependency-ready scheduling, cycle/error handling, fairness, explainable
“why not running”, repository/component/file collision claims, serialized
integration, global/provider/repository quotas, multiple-controller safety,
durable cancellation and stale-lease recovery. Begin with one active writer per
repository and raise concurrency only through promotion evidence. Keep resource
claims distinct from computation edges: a shared file, worktree, credential or
integration lock constrains scheduling but does not create fake data flow.

Depends on: FLEET-9 and FLEET-12.

FLEET-14 — Engineering Manager proposals and backlog refinement

Run a fresh, unprivileged EM over a bounded ContextManifest portfolio. It may
propose rank, decomposition/dependencies, risk/model tier, retry/repair,
block/quarantine/escalation and missing product decisions. WorkService/controller
validates and records proposal versus decision.

It may also select and parameterize an allowlisted, versioned GraphTemplate.
The controller validates topology, typed edges, joins, resource claims,
capabilities and budgets. Arbitrary model-authored topology and in-flight graph
mutation are rejected.

Promote offline fixtures -> shadow -> visible recommendations -> bounded,
reversible low-risk decisions. The EM may propose candidate claims, ambiguity
or clarification intents, but may not admit them, answer for the owner, waive a
gap, ratify an intake contract or mint readiness. Never grant independent
product ratification, policy promotion, merge or stop/resume authority.

Use fresh K3 1M high for normal EM proposals and a separately budgeted max
attempt for scheduled portfolio synthesis. Evaluate over-proactive or
unsupported decisions explicitly; model eloquence never counts as proposal
accuracy.

Depends on: FLEET-9 and FLEET-13.

FLEET-15 — Unattended operations and staged rollout

Deliver global/repository/item pause/drain/kill, health/lag/leases/dead letters/
cost/provider SLOs, alerting/audit/retention, backup/restore, upgrade/rollback,
chaos/outage/credential-rotation drills, incident runbooks, capability regression
rollback, safe operation with Fleet Manager offline and the final unattended
eligible-backlog drain gate.

Depends on: FLEET-9, FLEET-12, FLEET-13 and FLEET-14.

DEPENDENCY GRAPH

NSI nodes below are existing qualified prerequisites. Link their exact
WorkService IDs/receipts; do not recreate or publish them from this Fleet
program.

SQL-0 -> NSI-1
NSI-1 -> NSI-2, NSI-3
NSI-2 + NSI-3 -> NSI-4, NSI-5
NSI-4 + NSI-5 -> NSI-6
NSI-6 -> FLEET-1
FLEET-1 -> FLEET-2, FLEET-3
FLEET-1 + FLEET-2 -> FLEET-4
FLEET-2 + FLEET-4 -> FLEET-5
FLEET-2 -> FLEET-6
FLEET-3 + FLEET-5 + FLEET-6 -> FLEET-7
FLEET-3 + FLEET-4 + FLEET-5 + FLEET-6 + FLEET-7 -> FLEET-8
FLEET-8 -> FLEET-9
FLEET-3 + FLEET-6 + FLEET-7 -> FLEET-10
FLEET-9 + FLEET-10 -> FLEET-11
FLEET-11 -> FLEET-12
FLEET-9 + FLEET-12 -> FLEET-13
FLEET-9 + FLEET-13 -> FLEET-14
FLEET-9 + FLEET-12 + FLEET-13 + FLEET-14 -> FLEET-15

MANDATORY ADVERSARIAL CASES

Include at minimum:
- poisoned Work item/comment and acceptance text;
- forged owner claim, ratification, READY prose, readiness receipt or
  publication receipt;
- missing/stale `IntakePublicationReceipt` or receipt presented while intake
  state is not `published`;
- incomplete claim provenance, stale source/ontology/rule/contract binding and
  receipt whose contract hash does not match the planned work;
- satisfiable but semantically misratified formalization, solver
  UNKNOWN/ERROR/timeout and model agreement incorrectly presented as truth;
- poisoned README/AGENTS/config/hook/test output/dependency install script;
- duplicate, lost, delayed and out-of-order events;
- process death before and after each durable mutation;
- timeout after external success but before receipt;
- stale lease/fence and late result from an abandoned attempt;
- two controllers claiming the same item or component;
- force-push/base movement, rebase and merge conflict;
- audit PASS followed by any mutation;
- forged PASS prose with no valid typed AuditResult;
- EvidenceManifest/AuditResult candidate, plan, manifest or hash mismatch;
- missing/dangling evidence refs and unknown schema versions;
- auditor attempts to write candidate files, refs, host paths or scratch links;
- auditor attempts network, credential, lifecycle, patch-apply or external tools;
- fallback that would collapse auditor and worker independence;
- K3 selected after foreign assistant history, switched away/back, resumed
  after crash, compacted, or continued after lossy transcript conversion;
- K3 discovery reporting the wrong entitlement, effort set or output cap;
- K3/other-model fallback attempted inside one transcript instead of as a new
  fenced attempt;
- DB/provider/GitHub outage and rate limit;
- credential, path, symlink, artifact and egress exfiltration attempts;
- conflicting/discovered AGENTS, skill, hook, MCP and command precedence;
- stale, poisoned, over-budget or nondeterministic compiled context;
- missing, duplicate, failed, late or wrong-epoch graph inputs; cyclic,
  unbounded or mutated topology; ambiguous joins and conflicting resource
  claims;
- cache hit/miss or provider-cache behavior changing semantic context,
  provenance or lifecycle outcome;
- pre-existing parser/LSP diagnostics misclassified as regressions, and newly
  introduced syntax errors incorrectly accepted;
- malformed/huge typed outputs, serialization corruption and context exhaustion;
- budget, retry and repair-loop exhaustion;
- emergency stop during every stage and immediately before an external effect.

PUBLICATION REQUIREMENTS

For the parent and every child publish:
- stable key and idempotency key;
- problem and owner-ratified outcome;
- scope and non-goals;
- repository/component ownership;
- explicit inputs/outputs and acceptance criteria with IDs;
- exact required intake schema, `IntakeContract`, admitted-claim set,
  `IntakeReadinessAssessment`, `RatificationReceipt`, required
  `RatifiedFormalBinding`, `ELIGIBLE_FOR_PUBLICATION` receipt,
  `IntakePublicationReceipt` and `published`-state identities plus invalidation
  behavior;
- dependencies and external prerequisites;
- threat/risk classification;
- deterministic verification and fault tests;
- rollout/rollback/observability requirements;
- unresolved owner decisions;
- stop conditions and terminal outcomes.

Return the exact created IDs and dependency edges plus a reconciliation table
showing that publication matches the proposed manifest. On partial or ambiguous
publication, read WorkService and reconcile by idempotency key before retrying.

EXPLICIT NON-GOALS

- no second work tracker, SQL client, scheduler or SQLite authority;
- no parallel reimplementation of completed interactive bookends; extract and
  harden their contracts through the versioned harness package;
- no Fleet Manager UI in this program, only versioned consumer contracts;
- no DeepSeek Harness;
- no Agent Hub or `/agents` as durable fleet state;
- no agent credentials, direct SQL, lifecycle writes or GitHub mutations;
- no initial nested writers, free-form remote steering, shell/PTY exposure,
  arbitrary deployments/releases, concurrency, auto-merge or auto-close;
- no live sibling-agent state bus, arbitrary model-authored execution graph or
  automatic AST three-way merge/conflict resolution; integration always
  produces a new exact candidate that is fully reverified and re-audited;
- no fixed universal token-budget percentages, cache-lifetime assumptions,
  visual compression as canonical memory or named sandbox technology treated
  as proof by itself;
- no claim that an LLM evaluator replaces deterministic verification;
- no raw headed text or rendered Markdown directly advancing lifecycle state;
- no raw issue prose, model proposal, solver output or Engineering Manager
  decision substituting for admitted claims and owner ratification;
- no silent requirement invention to achieve a higher autonomy percentage.
- no assumption that a Vivace subscription is unlimited, that full 1M K3 is
  smarter than K3-256K inside 256K, or that Kimi Agent Swarm quotas authorize
  OMP fleet concurrency.

END-OF-INTAKE OUTPUT

Return:
1. live-head, migration and NSI-6 qualification/cutover evidence;
2. current-state/reuse crosswalk;
3. questions and owner answers;
4. ratified architecture and threat boundary;
5. exact parent/child manifest and DAG;
6. acceptance-criteria coverage;
7. publication result or precise BLOCKED reason;
8. recommended first `/plan` target, which must be FLEET-1.
```
