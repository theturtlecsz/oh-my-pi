# Research evidence and design disposition

## Status and authority

This appendix is a vetted research record for the PostgreSQL-backed OMP Intake
Compiler and Fleet programs. It is **non-normative**: it does not amend the
active SQL migration, authorize implementation, or replace the ratified
intakes, technical contract and operating policy in this package. Where this
appendix and a
ratified program file differ, the ratified program file controls.

The supplied harness report and graph-engineering article were used as sources
of testable ideas, not copied as requirements. Their ratings, comparisons and
architectural prescriptions are not evidence by themselves. Recommendations
below are accepted only where they are supported by inspected repository state,
primary documentation, or an explicit qualification experiment already present
in the Fleet program.

No work from this appendix belongs in SQL-0. Finish and prove the PostgreSQL /
WorkService migration first. The NSI `/intake` must then re-resolve the fork and
reconcile this appendix against live source before publishing NSI-1. The later
Fleet intake must consume the qualified intake contracts rather than skipping
directly from SQL-0 to FLEET-1.

## Evidence anchors inspected on 2026-08-16, 2026-08-22, 2026-08-28 and 2026-08-29

| Repository | Inspected HEAD | What the anchor establishes |
| --- | --- | --- |
| `theturtlecsz/oh-my-pi` | [`c3824395ab42d711d532f3b4beb97ab65a9fc84e`](https://github.com/theturtlecsz/oh-my-pi/commit/c3824395ab42d711d532f3b4beb97ab65a9fc84e) | Fork state used for the Work Ledger, session-system and harness observations in this appendix. The commit subject is `feat(work-ledger): PostgreSQL Work Ledger with Linear export and import (HOME-143, HOME-144, HOME-145, HOME-146)`. |
| `theturtlecsz/oh-my-pi` revalidation | [`cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8`](https://github.com/theturtlecsz/oh-my-pi/commit/cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8) | Current fork main inspected for the intake skill and WorkService-owned model-bookend behavior on 2026-08-22. Live intake must still re-resolve it. |
| `can1357/oh-my-pi` | [`37eee71978951fccf66b21f7e3e2b74596ac9d74`](https://github.com/can1357/oh-my-pi/commit/37eee71978951fccf66b21f7e3e2b74596ac9d74) | Upstream state used for OMP feature counts, task/isolation behavior, extension surfaces and runtime documentation. It is also the source commit for upstream release [`v17.3.5`](https://github.com/can1357/oh-my-pi/releases/tag/v17.3.5). |
| `theturtlecsz/oh-my-pi` v6 live HEAD | [`5086e48160364e9f4e2736d7a54d8fbf90ec0545`](https://github.com/theturtlecsz/oh-my-pi/tree/5086e48160364e9f4e2736d7a54d8fbf90ec0545) | Default-branch HEAD resolved on 2026-08-28 for v6. It is a rebaseline pointer, not a substitute for intake-time inspection. |
| `theturtlecsz/omp-webui` | [`12f8c1e549b4bc4e07d769e409eb9bd662ce2175`](https://github.com/theturtlecsz/omp-webui/tree/12f8c1e549b4bc4e07d769e409eb9bd662ce2175) | Existing React/Vite/Zustand client, Bun gateway, per-session OMP RPC supervision, replay and local control surface inspected for the native OMP Web decision. |
| `MoonshotAI/kimi-code` | [`9d2304c23ca30c781b1a39540971dcaef085a500`](https://github.com/MoonshotAI/kimi-code/tree/9d2304c23ca30c781b1a39540971dcaef085a500) | Current public CLI/server source and release documentation used to separate native packaging/session patterns from unavailable current frontend source. |
| `UditAkhourii/adhd` | [`53ab5576b77fb3d6e62739a1a285356261e5f568`](https://github.com/UditAkhourii/adhd/tree/53ab5576b77fb3d6e62739a1a285356261e5f568) | Current default-branch HEAD rechecked on 2026-08-29 for divergent-ideation mechanics, Claude SDK dependency, typed implementation, tests, cost guidance, evaluation and MIT license. It is a method/source anchor, not an OMP dependency or outcome proof. |

These hashes are reproducibility anchors, not permanent facts. Before relying
on this appendix, the next intake must:

1. resolve the live default-branch HEAD of both repositories;
2. record the exact commits and dirty state actually under review;
3. diff relevant Work Ledger, session-system, task, isolation, workflow, RPC,
   hook and test surfaces against these anchors;
4. classify each observation below as still true, changed or obsolete; and
5. update proposed acceptance criteria instead of silently carrying old counts
   or implementation assumptions forward.

## Verified repository state at the anchors

### Fork facts

- The fork HEAD contains the PostgreSQL Work Ledger migration commit, an
  operational runbook and a dedicated PostgreSQL integration job in CI. See
  [`docs/work-ledger-operations.md`](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/docs/work-ledger-operations.md)
  and [`.github/workflows/ci.yml`](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/.github/workflows/ci.yml).
- The same anchor still contains Linear-specific interactive bookends,
  including [`linear-now.ts`](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/session-system/extensions/linear-now.ts),
  the [intake skill](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/session-system/skills/intake/SKILL.md)
  and the [summary skill](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/session-system/skills/summary/SKILL.md).
  The commit therefore proves that PostgreSQL infrastructure exists; it does
  not, by itself, prove that the interactive workflow has completed its
  authority cutover or that every legacy Linear writer has been removed.
- [`model-bookends.ts`](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/session-system/extensions/model-bookends.ts)
  already routes the intake bookend and implements a fail-closed summary gate.
  The fork also contains a fresh task-agent
  [`auditor.md`](https://github.com/theturtlecsz/oh-my-pi/blob/c3824395ab42d711d532f3b4beb97ab65a9fc84e/session-system/agents/auditor.md)
  plus event-level lifecycle tests. These are reusable foundations.
- At this anchor, the summary gate validates a model-assembled, labeled text
  packet and forwards a headed-text report into a typed Linear review comment.
  That is not the same as a runtime-generated `EvidenceManifest`, a native
  typed `AuditResult`, or mechanically enforced read-only auditor containment.
  FLEET-6 and FLEET-7 correctly retain those as future work.

At the 2026-08-22 revalidation anchor, the intake skill already contains a
fixed 11-category taxonomy, visible pre-question scan, one-decision
`AskUserQuestion`, an ephemeral entity graph, exactly-one/exclusive/
allowed-values/transitive constraint prompts, a dangling-edge stop and a lint
before publication. The model bookend still routes `/intake` to Fable-high and
WorkService owns more of the audit launch/settlement boundary. These are strong
foundations, but the intake model still constructs, interprets and lints its
own ephemeral graph and Markdown remains its human publication artifact. That
is neuro-symbolic-shaped prompting, not yet mechanically governed admission,
reasoning or readiness.

### Upstream OMP facts

- The pinned upstream README reports **60+ providers, 31 built-in tools, 14 LSP
  operations, 28 DAP operations and approximately 80,000 lines of Rust core**.
  Those counts supersede the supplied report's 40+/32/13/27 snapshot. See the
  [README at the inspected commit](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/README.md).
- OMP already provides hash-anchored edits, LSP/DAP surfaces, TTSR, task agents,
  task output schemas, filesystem/worktree isolation modes, Agent Hub,
  Snapcompact, RPC/SDK integration and deterministic workflow helpers. Relevant
  primary sources include the [task tool](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/tools/task.md),
  [Agent Hub](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/tools/hub.md),
  [TTSR lifecycle](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/ttsr-injection-lifecycle.md),
  [Snapcompact source](https://github.com/can1357/oh-my-pi/tree/37eee71978951fccf66b21f7e3e2b74596ac9d74/packages/snapcompact)
  and [extension hook authoring](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/skills/authoring-hooks.md).
- OMP task isolation is a workspace/filesystem change-isolation mechanism. It
  is not evidence of an OS process, network, host-path or credential boundary.
  Structured task output is an available contract, not proof that every current
  agent invocation enables and validates it.
- Agent Hub supports live peer coordination. `agent://` is an addressing/output
  surface, not a durable authoritative message bus. Neither is suitable as the
  Fleet ledger, scheduler, dependency truth or lifecycle authority.

## Evidence-quality findings

The supplied report is useful as an idea inventory, but it is not a reproducible
audit. It does not identify a fixed scoring rubric, criterion weights, an
audited commit for each comparison, a task corpus, outcome measurements or an
independent replication. Repeated citation bundles combine primary and
secondary sources without showing which source establishes each sentence.
Accordingly, no numeric rating or vendor ranking from the report is retained as
a requirement.

Evidence classes used below:

- inspected repository source and official/normative documentation establish
  current mechanics within their pinned versions;
- peer-reviewed conference papers support patterns only within their evaluated
  domains and datasets;
- arXiv preprints are useful recent hypotheses/results that require stronger
  local qualification;
- practitioner articles and Reddit posts contribute techniques and failure
  hypotheses, not measured correctness claims for this system.

| Supplied claim area | Evidence disposition | Program consequence |
| --- | --- | --- |
| A harness materially affects an agent's coding performance | **Supported, with narrower wording.** The SWE-agent paper shows that a model-oriented agent-computer interface improved repository navigation, editing and testing in its evaluated setup. It does not establish that harness design is always the single primary determinant of production outcomes. | Treat harness components as measured interventions. FLEET-9 compares them against a bare-OMP baseline instead of assuming value. |
| Hashline reduces output tokens by up to 61% and improves model pass rates | **Supported only as a maintainer-run benchmark result.** The published experiment used mechanically mutated React edit tasks, fresh sessions and model-specific runs. The 61% figure is a best case reported for Grok 4 Fast, not a general repository-completion or cost claim. | Keep Hashline as a reuse primitive. Reproduce relevant edit results locally and measure end-to-end issue outcomes before generalizing the percentage. |
| Hash anchors eliminate concurrent-edit corruption | **Overstated.** Stale content anchors can reject many mismatched edits, but short line hashes are neither a transactional lock nor a proof against every race. | Retain candidate identity, worktree ownership, resource claims, fencing and exact-SHA verification. Do not replace concurrency control with Hashline. |
| Claude Code has seven permission modes and a general real-time ML risk classifier | **Needs qualification.** A reverse-engineering paper recorded seven values in a specific build, including internal or feature-gated modes. Current public documentation lists six public modes; the classifier is documented for Auto mode, not every invocation. | Borrow the principle of separating permissions from model judgment, not the unverified internal count or a universal classifier assumption. |
| Claude Code has a five-layer compaction pipeline | **Snapshot evidence only.** The reverse-engineering study documents a particular version and warns that flags and production prevalence may change. | Do not reproduce its internal layer count. Measure OMP's own context behavior and keep authoritative artifacts outside lossy conversation compaction. |
| Fixed `20/50/20/10` context zones optimize caching | **Unsupported.** Anthropic documents prefix matching and cache lifetimes, not those allocation percentages. Cache behavior also differs by access path and provider. | Reject universal percentages. FLEET-5/9 record exact stable-prefix hashes, provider cache telemetry, latency, tokens and outcomes. |
| Snapcompact bypasses token limits | **Incorrect.** It changes representation and can reduce text pressure, but images still consume model input capacity and the serialization can be lossy. | Use images only for navigation. Canonical acceptance criteria, plans, diffs, logs and evidence remain content-addressed text/binary artifacts. |
| Cursor/Windsurf lack headless or CI-capable operation | **False as a combined categorical claim.** Cursor documents a headless CLI and cloud agents. No Fleet decision depends on a Windsurf comparison. | Remove the assertion and avoid competitor feature tables that are not pinned and revalidated. |
| A `Seccomp-eBPF` profile can limit workspace writes for OMP's in-process shell | **Technically incorrect.** Linux seccomp filters system calls and cannot dereference path arguments. Applying a restrictive filter to an in-process shell also risks constraining the OMP host process itself. | FLEET-6 requires an out-of-process worker/container boundary with verified mount, namespace, network and credential policy. Landlock and seccomp may provide defense in depth inside that boundary; neither is accepted as the boundary by name alone. |
| `agent://` provides an inter-agent state bus | **Incorrect for the inspected OMP source.** Live coordination belongs to Hub/IRC-style peer messaging; output addressing is not durable state. | Artifact edges and WorkService state carry correctness. Sibling messages cannot satisfy dependencies, authorize transitions or prove completion. |
| OMP needs a new generic DAG engine because it only has flat fan-out | **Incorrect as stated.** OMP already exposes task batching, workflow helpers and peer coordination. What is missing for this program is durable, fenced, PostgreSQL-backed Fleet graph state and authoritative joins. | Reuse OMP execution primitives. Add only the controller/WorkService contracts required by the Fleet intake. |
| Every edit should be rejected before disk write if AST parsing fails | **Not supported as a universal policy.** Multi-edit changes can be temporarily invalid, parser coverage varies, and the inspected OMP edit path already has parse/repair feedback. | Compare baseline and candidate diagnostics and block candidate promotion on newly introduced supported-language syntax errors. Immediate scratch feedback remains optional and must be evaluated. |
| Automatic AST-aware three-way merging can safely reconcile concurrent workers | **Unsupported as a safety claim.** Structural merge output still requires integration and complete verification; semantic conflicts can survive a syntactically valid merge. | Prevent overlapping writers initially. Any future parallel writer output creates a new integrated candidate that is fully verified and independently audited. |
| Majority voting among agents establishes correctness | **Unsupported.** Correlated models can agree on the same error, and prose agreement is not execution evidence. | Prefer deterministic checks, exact artifacts, a fresh cross-family auditor and adjudication only when a real finding remains disputed. |
| `pi-headroom`, `headroom-retrieve` and a `stream-filter` hook are available OMP components | **Not established in the inspected upstream source.** | Exclude these names from requirements. Use only re-resolved, documented APIs or record a concrete hook gap for upstreaming. |

## Neuro-symbolic intake research disposition

### Research-supported architecture

The defensible pattern is:

```text
natural-language intent and repository evidence
  -> neural investigation and candidate semantic decomposition
  -> typed provenance-carrying requirement IR
  -> code-owned admission, ontology and rule evaluation
  -> selective deterministic formal compilation and solver checks
  -> concrete gaps/conflicts/witnesses
  -> targeted owner clarification
  -> pre-ratification assessment (READY_FOR_RATIFICATION or failure)
  -> owner ratification of exact meaning
  -> WorkService revalidation and positive current receipt
  -> explicit publishIntake transition and published state
  -> planner/Fleet eligibility
```

The symbolic layer proves properties relative to its encoding. It does not
prove that the encoding captured the owner's intent. This semantic gap is a
first-class status, UI and receipt boundary—not a documentation footnote.

Keep the intake claim/provenance graph separate from the Work-item dependency
DAG, lifecycle state machine, per-attempt execution DAG and resource/capability
constraints. The package's “no mega-graph” rule still applies.

### Evidence map and limitations

| Source | Supported use | Limitation carried into design |
| --- | --- | --- |
| [Requirements-Sufficiency-Gated Automation (RE 2026)](https://conf.researchr.org/details/RE-2026/RE-2026-Research-Papers/23/Requirements-Sufficiency-Gating-for-LLM-Assisted-Automation) | Strongest direct support for blocking downstream automation on an explicit sufficiency gate, structured constraints/assumptions and decision trace. | The conference page does not establish repo-scale OMP outcomes or a universal completeness proof. Reproduce locally. |
| [Orchid](https://arxiv.org/abs/2604.21505) | Ambiguity causes divergent implementation and capable models do not reliably resolve it without questions. | ArXiv preprint and function-level task setting; it does not define OMP readiness. |
| [ClarifyCodeBench](https://arxiv.org/abs/2607.00711) | Separates coding skill from clarification skill and motivates key-question efficiency/round adherence. | Early preprint; details/taxonomy are not treated as settled or universal. |
| [Logic-LM](https://aclanthology.org/2023.findings-emnlp.248/) | LLM translation plus an external symbolic solver and structured error-driven repair. | Logic benchmark gains do not transfer directly to software requirements; formalization remains the bottleneck. |
| [SymBa](https://arxiv.org/abs/2402.12806) | Symbolic controller drives proof/backward chaining and calls the LLM when premises are missing—directly analogous to code-selected intake gaps. | Reasoning benchmarks, not production requirements sufficiency. |
| [ToolGate](https://aclanthology.org/2026.findings-acl.470/) | Typed state plus pre/postcondition admission supports moving control decisions out of prose. | Tool-execution domain, not complete requirements elicitation. |
| [Req2LTL](https://arxiv.org/abs/2512.17334) | Neural hierarchical decomposition plus a deterministic compiler is safer than arbitrary model-authored solver code. | Temporal/aerospace setting and imperfect semantic accuracy; domain phrases remain ambiguous. |
| [NeuroNL2LTL](https://arxiv.org/abs/2605.22874) | Direct evidence that syntax/satisfiability/non-triviality and semantic equivalence are different gates. | Recent preprint; reported results cannot be generalized beyond its corpus. The direction nevertheless argues strongly against calling SAT faithful. |
| [Neurosymbolic Requirements Auditing](https://arxiv.org/abs/2605.13817) | Alternative formalizations, global consistency, vacuity, violatability, redundancy, unsat cores and counterexamples can reveal material ambiguities. | Recent domain-specific preprint; sampled agreement is an ambiguity signal, not proof. |
| [Roundtrip Verification and Repair](https://arxiv.org/abs/2604.25031) | Formalize/explain/reformalize/equivalence can localize likely drift. | Both directions may preserve the same wrong meaning. Advisory evidence only. |
| [LLMs as ASP Programmers](https://aclanthology.org/2026.findings-acl.1151/) | ASP and compact solver feedback are promising for genuine defaults and exceptions. | Reasoning benchmarks do not justify ASP for every intake. |
| [AgentSpec](https://conf.researchr.org/details/icse-2026/icse-2026-research-track/29/AgentSpec-Customizable-Runtime-Enforcement-for-Safe-and-Reliable-LLM-Agents) | Ratified preconditions/prohibitions can later compile into code-owned runtime enforcement. | Imperfect generated-rule recall is a direct reason not to let models author authoritative production rules. |
| [W3C PROV-O](https://www.w3.org/TR/prov-o/) | Entity/activity/agent, derivation, attribution and revision concepts help define provenance. | It is a normative interchange ontology, not a requirement to run RDF/OWL storage. |
| [Z3 guide](https://microsoft.github.io/z3guide/docs/logic/propositional-logic/) | SAT/UNSAT, cardinality, witnesses and unsat-core mechanics for bounded hard constraints. | Z3 does not interpret natural language; cores need not be minimal; unsupported problems can be unknown. |
| [Reddit requirements-interviewer post](https://www.reddit.com/r/ChatGPTPromptGenius/comments/1vrp7zw/i_used_ai_as_a_requirements_interviewer_on_a/) | Preserve exact source wording, ask for missing decisions, do not let the model answer itself, maintain a decision log and use bounded options when honest. | Unverified single-user anecdote with no ground truth, controlled comparison or established defect-rate effect. Question volume is not evidence of quality. |

### Adopted now, after SQL-0

- Fable produces candidate typed claims tied to exact source spans; WorkService
  validates origin/authority/provenance before admission.
- The current 11-category vocabulary becomes a small versioned ontology with
  code-owned cardinality, exclusivity, allowed-value, graph, applicability,
  conflict, coverage and pre-ratification assessment rules.
- The reasoner produces missing premises/conflicts/counterexamples and selects
  one material question. Fable phrases it; the owner decides.
- Original wording, normalized interpretation, rejected alternatives,
  assumptions, non-goals and decisions remain separately traceable.
- Typed ACs map every admitted desired/prohibited behavior to an observable
  oracle or legal owner waiver.
- The owner ratifies an exact `IntakeContract` semantic-closure hash;
  WorkService recomputes, issues a positive-only current readiness receipt and
  performs an explicit publish transition. Markdown is a view.
- Readiness verdicts remain distinct from formal results:

```text
READY_FOR_RATIFICATION | NEEDS_SPEC | CONFLICTED | STALE | INVALID

HOLDS_RELATIVE_TO_DRAFT_FORMAL_MODEL | COUNTEREXAMPLE | UNSAT | UNKNOWN |
NOT_FORMALIZABLE | NEEDS_OWNER_DECISION | SOLVER_ERROR
```

The pre-ratification formal result uses the draft-model term above. Only an
exact per-property post-ratification formal binding may state
`VERIFIED_RELATIVE_TO_RATIFIED_MODEL`; the overall governance receipt states
`ELIGIBLE_FOR_PUBLICATION` and does not imply every clause was formally proved.

### Qualified or deferred

- Fresh K3 alternate interpretations/formalizations for large or high-risk
  intakes: measure ambiguity precision and owner burden; never vote on truth.
- Z3 only for bounded hard constraints where typed rules become inadequate.
- ASP only for real defaults/exceptions; temporal model checking only for
  high-risk lifecycle/concurrency/safety models.
- Round-trip and multi-formalization agreement only as advisory drift signals.
- W3C PROV-inspired vocabulary/interchange only where it improves actual
  integration; PostgreSQL remains the authority.

### Rejected

- One-shot free-form natural language to authoritative Z3/Lean/LTL.
- Treating parsing, SAT, proof success, multiple-model agreement, round-trip
  agreement or an unsat core as proof of owner intent.
- Letting the same model extract, admit, reason, lint and declare itself ready.
- A single sufficiency score that overrides a missing critical premise.
- General Neo4j/RDF/OWL/PDDL/theorem-prover/differentiable-logic infrastructure
  or an intake swarm solely for the neuro-symbolic label.
- Forty-question batches, closed options for open domains, specification bloat
  and question count as success.

### NSI-6 evaluation

Compare on the same frozen tasks, models and context limits:

1. current intake;
2. practitioner requirements interviewer plus decisions log;
3. typed claims/provenance plus code-owned rules;
4. typed claims/rules plus selectively qualified formal adapters.

Use real historical work plus seeded omissions, contradictions, ambiguous
scope, missing security/rollback/concurrency behavior, stale sources,
formalization drift and prompt injection. Measure false-ready first, critical
omissions, provenance closure, AC coverage, material/redundant questions,
owner corrections, key-question efficiency, plan deviations and downstream
audit findings caused by intake, tokens and time.

Promotion requires zero false-ready outcomes on the versioned seeded
critical-omission corpus and complete provenance for every premise contributing
to a `READY_FOR_RATIFICATION` assessment. Other
thresholds are calibrated from baseline data rather than invented here.

## Bounded intake exploration research disposition

### What the inspected ADHD project actually implements

At `53ab5576`, the Node/TypeScript implementation optionally asks a model to
rewrite the problem without perceived incidental anchors, selects roughly five
random cognitive frames, runs fresh Claude Agent SDK calls for divergence, asks
a model to score and cluster the resulting ideas, removes candidates labeled as
traps from its shortlist and deepens up to three survivors once. The default
weighted score is 35% novelty, 40% viability and 25% fit. This is one fan-out
plus one expansion, not a general recursive reasoning engine.

Positive implementation facts:

- divergent calls are separate and the Node runner disables built-in tools;
- generator and critic postures are mechanically separate calls;
- schemas validate basic output shapes;
- concurrency is bounded;
- the repository CI tests Node 18, 20 and 22, typechecks/builds, has an MIT
  license and committed evaluation artifacts; and
- project documentation candidly describes the large context/call cost and its
  evaluation limitations.

Material limitations for OMP:

- the library/CLI depends directly on `@anthropic-ai/claude-agent-sdk`; generic
  Codex/other-agent support means installing the prompt skill, not a portable
  multi-provider runtime;
- automatic anchor stripping defaults on and can remove a genuine requirement;
- frame selection uses unseeded `Math.random()` despite documentation implying
  deterministic seeded selection;
- supplied `context` reaches reframe/divergence but not score, cluster or
  deepen, so later viability judgments can omit repository constraints;
- a model-generated nonempty trap string removes a candidate from the shortlist
  even though model criticism is not factual verification;
- structured score/cluster output does not fully enforce complete, unique,
  exact input references;
- several thrown provider failures reject the complete parallel operation,
  while some parse failures silently become empty branches/results;
- no durable run, expected revision, staleness, cancellation, overall timeout,
  token/dollar cap, provider-outcome reconciliation or usage receipt exists;
- current tests contain one conventional unit test, verifying that built-in
  tools are disabled; and
- current source has materially evolved beyond parts of the committed
  evaluation/documentation, including anchor stripping, heterogeneous critic
  fields and stale links to nonexistent split source files. Main still reports
  package version `0.1.4` but is 26 commits beyond tag `v0.1.4`; installing that
  tag/npm version does not reproduce the inspected HEAD.

### Evidence quality

The project's committed comparison uses six hand-selected open-ended
engineering prompts, one ADHD run versus one single-shot baseline, and a
same-family LLM judge. The structured ADHD answer visibly includes breadth and
trap sections that the rubric explicitly rewards. It reports large breadth,
novelty and trap-detection gains but only a modest builder-usefulness difference.
Its own documentation acknowledges the tiny set, same-family judging and that
human-in-the-loop benefit is unproven. It measures ideation presentation—not
owner decision quality, implementation rework, defect escape or audit outcome.

The broader [Tree of Thoughts paper](https://arxiv.org/abs/2305.10601) supports
searching multiple reasoning paths on its evaluated Game of 24, creative-writing
and mini-crossword tasks. It does not prove that this particular frame library, scoring formula or
ten-call workflow improves OMP requirements decisions. The ADHD preprint and
repository evaluation are preliminary design input; local qualification is
required.

### Adopted with substantial adaptation

The valuable owner outcome is a temporary design panel for a costly, genuinely
open decision—not “more agents” by default. `NSI-E1` through `NSI-E4` and
`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md` therefore adopt:

- an optional question-bound **Explore alternatives** action;
- deterministic reviewed perspectives, isolated proposal branches and separate
  synthesis;
- one identical frozen, provenance-bearing input manifest for every stage;
- one shared OMP/WorkService bounded-model-job substrate rather than a second
  exploration scheduler;
- code-owned typed schema/reference/exact-duplicate/explicit-constraint
  screening before synthesis and again on synthesized/deepened output;
- a small neutral option set, tradeoffs, assumptions and watch-outs;
- separately owner-authorized deepening;
- exact-answer confirmation through ordinary `recordOwnerDecision`;
- durable attempts, hard call/token/time and enforceable currency-or-resource limits,
  provider-specific egress receipts, cancellation, partial-failure honesty,
  staleness/fencing, usage receipts and safe Web rendering; and
- a post-publication advisory planning handoff outside semantic closure.

Only the exact confirmed owner answer may become owner-decision input.
Unselected suggestions are neither rejected meanings nor non-goals. Model
scores, agreement and recommendations remain advisory. Base NSI/Fleet never
depends on the extension.

### Rejected or deferred

Reject wholesale installation, the direct Claude runtime, automatic anchor
rewriting, unrecorded/random frames, fixed numeric model-score pruning,
trap-driven deletion, raw/private reasoning display, explicit-invocation safety
bypass, general remote brainstorming and use in deterministic verification or
final audit.

Initial release requires per-run owner confirmation and an enforceable maximum.
Automatic usage-consuming execution remains prohibited. System offers are deferred until
`NSI-E4` measures selector precision and owner value; any later preauthorized
budget requires a new owner-ratified policy/program rather than a quiet default.

### Qualification

Compare X-A qualified intake without alternatives; X-B one Sol-high pass; X-C0
four unframed Flash-medium branches plus identical Sol synthesis; X-C the same
width with reviewed frames plus the same Sol route, prompt and limits as X-C0;
and X-D a randomized deepening offer. Report
intention-to-treat and self-selected deepening cohorts separately. Tune only on
a pilot, then freeze a holdout; randomize option order, normalize presentation,
blind arm identity where practical and report/equalize compute.

Measure material options actually selected, critical conflicts incorrectly
presented as compliant/selectable/admitted,
unsupported facts, owner correction/reversal/time/abandonment, plan changes,
implementation rework, downstream audit findings, duplicate/noisy branches,
offer precision, tokens, actual cost, latency, provider failure and
cancellation. N4 requires zero authority, containment, secret/egress,
currentness, fencing, idempotency or limit-enforcement violations; zero critical
conflicts presented as compliant, exposed as selectable or admitted into
owner/semantic state; zero option submission after staleness; preregistered
non-inferiority on false-ready, critical omissions, provenance closure and
owner-correction burden; stable material benefit over X-A and an equal-compute
control; owner-confirmed currency/resource limit compliance; and proven
rollback on the holdout.

## Native OMP Web and remote-agent UX disposition

### Existing local foundation

The current `omp-webui` is a working local client, not a mockup. It already has
a React application, Bun daemon, one supervised OMP RPC worker per session,
SQLite/JSONL replay and broad chat/tool/file/Git/provider/model/PTY commands.
Promotion is therefore more valuable than replacement.

That same breadth is why the local daemon cannot simply be exposed remotely.
Its local trust model and broad protocol are not a remote authorization design.
The accepted architecture keeps the useful local client, adds a separately
authenticated capability-reduced Remote Workbench gateway and retains the
separate least-privileged Fleet gateway.

Relevant implementation anchors:

- [Current command surface](https://github.com/theturtlecsz/omp-webui/blob/12f8c1e549b4bc4e07d769e409eb9bd662ce2175/packages/daemon/src/protocol.ts)
- [Current server](https://github.com/theturtlecsz/omp-webui/blob/12f8c1e549b4bc4e07d769e409eb9bd662ce2175/packages/daemon/src/server.ts)
- [Current architecture decisions](https://github.com/theturtlecsz/omp-webui/blob/12f8c1e549b4bc4e07d769e409eb9bd662ce2175/docs/omp-webui/DECISIONS.md)

### Competitor lessons

| Source | Value adopted | Boundary retained |
| --- | --- | --- |
| Kimi Code Web | A CLI-launched browser, exact session handoff, coordinated packaging, strong conversation/tool/diff UX, mobile behavior and explicit recovery can feel native without running agents in the browser. | Current Kimi frontend source is not present in the public repository. Reimplement patterns; do not copy compiled/source-unavailable assets or branding. |
| Kimi Remote Control | The August 27, 2026 experimental release supports demand for securely checking a host session from another device. | Experimental status is not security evidence. OMP uses its own threat model, identity and capability gates. |
| Orca | Headless host access, mobile UX, activity/attention views and annotated diffs are useful owner experiences. | Worktrees and worker completion reports do not satisfy Fleet containment, evidence or authority. |
| Agent Orchestrator | Attention-first dashboard, durable event/replay concepts, PR/CI observation and exact-head guards are useful cockpit patterns. | Its scheduler/database/model orchestration do not replace WorkService or the deterministic Fleet controller. |

Accepted direction:

- Promote `omp-webui` to official **OMP Web** with `omp web`, `/web`, canonical
  sessions and one version-matched Web build per OMP release.
- Keep its source repository/process separate if useful; “native” is a product,
  distribution, session and release property.
- Reimplement Kimi-inspired session/workspace organization, rich tool/diff
  cards, background status, failure recovery and responsive mobile behavior.
- Add Open, Needs You and Done views, durable cursor replay, revocable
  notifications and authenticated deep links.
- Use one visual shell with server-enforced `local_owner`,
  `remote_restricted`, `work_owner` and `fleet_supervisory` profiles, each
  backed by the appropriate separate gateway/service identity.
- Bind review feedback to exact candidate SHA/diff identity and reverify after
  mutation.

| Surface | Earliest live stage | Authority |
| --- | --- | --- |
| Local OMP Web | OWEB-L1 | Existing OMP session/core APIs |
| Restricted Remote Workbench | OWEB-R1/R2 | Narrow session projections and typed attention actions |
| Work/Intake pages | OWEB-N1 after NSI-6 | WorkService intake contracts and receipts |
| Read-only Fleet cockpit | OWEB-F1 after FLEET-8/WFM-7 | WorkService/controller projections |
| Fleet review/controls | OWEB-F2 after FLEET-12 and matching WFM handlers | Revision/SHA-bound typed controller/broker commands |

The browser never becomes scheduler, evidence generator, receipt issuer,
database authority or credential holder. A unified product does not imply a
unified trust boundary.

Rejected:

- copying Kimi's compiled/source-unavailable frontend, assets or branding;
- replacing the existing React application merely for visual similarity;
- exposing the broad local daemon/static token publicly;
- general remote PTY, arbitrary filesystem/Git/provider controls or direct
  GitHub/WorkService credentials;
- Orca or Agent Orchestrator as a Fleet database/controller; and
- worktree disposal, worker `done`, same-prompt races or model voting as proof.

Primary references:

- [Kimi browser guide](https://www.kimi.com/code/docs/en/kimi-code-cli/guides/web.html)
- [Kimi server API](https://www.kimi.com/code/docs/en/kimi-code-cli/reference/server-api.html)
- [Kimi repository/frontend packaging guide](https://github.com/MoonshotAI/kimi-code/blob/main/AGENTS.md)
- [Kimi release notes](https://www.kimi.com/code/docs/en/kimi-code/whats-new.html)
- [Orca remote servers](https://www.onorca.dev/docs/remote-servers)
- [Orca mobile](https://www.onorca.dev/docs/mobile)
- [Orca annotated diff](https://www.onorca.dev/docs/review/annotate-ai-diff)
- [Agent Orchestrator architecture](https://aoagents.dev/docs/architecture/)
- [Agent Orchestrator dashboard](https://aoagents.dev/docs/dashboard/)
- [Agent Orchestrator remote access](https://aoagents.dev/docs/configuration/remote-access/)

## Graph-engineering research disposition

The [original graph-engineering article](https://x.com/AnatoliKopadze/article/2080668775796314331)
is a practitioner account, not a controlled benchmark of this OMP Fleet. Its
case studies demonstrate useful orchestration patterns, but they do not prove
that more agents, more graph depth or same-model voting improve correctness.
The applicable primary references are Claude Code's documented
[dynamic workflows](https://code.claude.com/docs/en/workflows) and the
[Bun Rust migration case study](https://bun.com/blog/bun-in-rust). Their
results occurred under their own decomposition, verification and supervision
conditions and must not be imported as Fleet performance expectations.

The article contributes five evidence-compatible workflow rules:

1. Every computation node has explicit, versioned inputs and typed outputs.
2. An edge represents a real artifact/data dependency. It does not stand in for
   a lifecycle permission, file lock, worktree lease, credential or concurrency
   limit.
3. Fan-out is bounded and useful only where work is genuinely independent.
   Fan-in consumes typed artifacts through a deterministic join rather than
   concatenating every transcript into one context.
4. Deterministic verification and fresh independent audit remain stronger than
   same-model voting.
5. Budgets, retry caps and owner/controller gates stay outside model judgment,
   especially at irreversible boundaries.

The resulting design rule is:

> A state machine controls authority; bounded DAGs control computation.

Four structures therefore remain separate:

| Structure | Meaning | Authoritative owner |
| --- | --- | --- |
| Work-item DAG | Dependencies between backlog items | WorkService |
| Lifecycle state machine | Legal item/run/stage transitions | WorkService plus deterministic controller policy |
| Execution DAG | Computation inside one frozen attempt/epoch | Controller-owned, versioned graph template |
| Resource/capability constraints | Files, components, worktrees, credentials, quotas and concurrency | Scheduler, leases/fences and capability policy |

There is no combined “mega graph.” A file collision does not create a fake data
edge; a model-produced edge does not grant authority; and a lifecycle state is
not inferred from agent messages.

### First accepted graph

The first accepted graph is the fixed `verification_diamond` already assigned
to FLEET-7 and exercised in FLEET-8:

1. seal one exact candidate and graph epoch;
2. run independent required verification nodes for the repository's approved
   test, build/type, security/static and diff/scope policies;
3. emit typed `NodeResult` artifacts bound to candidate, manifest, policy and
   epoch identities;
4. join only when every expected result is present exactly once, current,
   successful and correctly bound;
5. construct the runtime-owned `EvidenceManifest`; and
6. invoke one fresh, mechanically isolated auditor against that evidence.

Missing, duplicate, failed, stale or wrong-candidate inputs reject the join.
Repair or any candidate mutation creates a new candidate/graph epoch and
invalidates downstream verification and audit. The first vertical slice has one
writer and no external writes.

This is an evidence-collection graph, not an agent swarm. It improves possible
critical-path latency without weakening the all-required evidence rule. FLEET-9
must compare it with sequential verification for identical evidence coverage,
or the graph is not promoted.

### Later graph use is qualification-gated

- Bounded parallel read-only discovery may be evaluated after the verification
  diamond proves joins, recovery, budgets and context reduction.
- Multiple writers remain disabled until disjoint ownership, stable interfaces,
  isolated worktrees, an explicit integration node, resource claims and full
  post-integration verification/audit have all passed FLEET-9 and FLEET-13
  promotion gates.
- The Engineering Manager may initially select only code-owned templates such
  as `direct`, `verification_diamond` and a qualified read-discovery template,
  with typed parameters. It may not invent arbitrary topology or mutate a
  running epoch.
- Free-form sibling chat is never a correctness dependency. Necessary data is
  emitted as a typed, content-addressed artifact on a declared edge.

## Recommendation disposition

### Accepted

These research-derived changes are supported and already have an exact home in
the NSI and Fleet programs:

- typed source snapshots, claims, evidence, decisions, derivations and
  acceptance traceability through WorkService;
- code-owned intake ontology/rules/pre-ratification assessment with gap-directed
  questions;
- exact owner semantic-closure ratification plus server-generated positive
  readiness receipt and explicit published state;
- selective formal adapters with explicit unknown/not-formalizable/error states;
- runtime-generated, candidate-bound `EvidenceManifest` and deterministic
  verification receipts;
- native validated `AuditResult` stored before human rendering;
- a fresh auditor in a mechanically read-only, network-denied,
  credential-isolated execution profile;
- typed, bounded graph templates with exact-input, fail-closed joins and frozen
  graph epochs;
- task/node-specific context compilation with provenance, stable prefix hashes,
  redaction and provider-specific cache telemetry;
- baseline-relative parser/LSP diagnostics at the candidate/stage boundary;
- an overlay/versioned harness package with fast CI and compatibility tests;
- exact candidate identity, fencing, immutable artifacts and invalidation after
  any mutation;
- fixed-worker ablations, seeded auditor benchmarks, containment/fault tests
  and measured promotion gates; and
- a symbol-level repository map and progressively loaded policy/context rather
  than adding more universal prompt doctrine.

### Accepted with modification

| Research suggestion | Accepted form |
| --- | --- |
| Use an LLM requirements interviewer | Preserve exact quotes, one missing decision at a time and a decision log, but let code select gaps and forbid the model from answering/ratifying. |
| Formalize requirements to prove correctness | Formalize only suitable clauses with a reviewed deterministic compiler. Report results relative to the encoding and retain owner semantic authority. |
| Build a requirements knowledge graph | Use typed relational claims/edges/provenance in WorkService; keep it distinct from portfolio/lifecycle/execution/resource graphs. |
| Reject syntactically invalid edits immediately | Permit atomic/staged edits and useful scratch diagnostics; compare baseline and sealed-candidate parser/LSP results; block promotion on newly introduced supported-language syntax errors. |
| Add DAG subagent orchestration | Persist controller-owned graph epochs, typed artifact edges, deterministic joins, budgets and recovery in WorkService. Reuse OMP task/workflow execution rather than adding an agent-controlled scheduler. |
| Add an eBPF sandbox to the shell | Execute untrusted stages out of process in a verified OS/container boundary. Use mount/filesystem policy, network denial, credential isolation and optional kernel defenses as an attested profile. |
| Optimize prompt caching | Stabilize and hash immutable request prefixes, observe provider-reported behavior where available and measure task outcomes. Do not assign universal context percentages or TTL assumptions. |
| Use Snapcompact for long history | Use it as non-authoritative navigation only. Preserve original content-addressed artifacts for recovery, evidence and audit. |
| Use graph fan-out for more agent coverage | Start with deterministic verification fan-out. Add read-only discovery only after qualification; keep writers serialized initially. |
| Use multiple agents to verify results | Require deterministic checks and one fresh independent audit. Agent count and majority agreement are not proof. |
| Make fork customization modular | Extract the session harness behind documented extension APIs and keep only demonstrated hook gaps in the fork. Test both the pinned fork and a re-resolved upstream target. |

### Deferred behind existing promotion gates

These are not authorized work now. They remain disabled until the named Fleet
gate produces the required evidence:

- optional Z3/ASP/LTL adapters beyond the precise qualified NSI use cases;
- stochastic alternate formalizations and round-trip checks as production
  ambiguity signals until NSI-6 measures their precision and owner burden;
- parallel read-discovery graphs: after the fixed verification diamond passes
  FLEET-8 recovery and FLEET-9 correctness/latency comparison;
- more than one writer per repository: after FLEET-9 fault qualification and
  FLEET-13 resource-collision, integration and concurrency evidence;
- `split_implementation` or another writer graph: only after disjoint ownership,
  exact integration and complete re-verification/re-audit are proven;
- greater graph fan-out or new templates: only through a versioned template,
  bounded budgets and a new qualification result;
- bounded Engineering Manager template selection: only through FLEET-14's
  offline, shadow and reversible promotion stages;
- critical unattended work and broad remote exposure: only through their
  separate risk, operations and threat-review gates.

Deferral is not an instruction to build speculative mechanisms. If a later
intake cannot identify a current need, supported API and measurable acceptance
test, the deferred item is removed rather than carried forward ceremonially.

### Rejected or excluded

- universal formalization, model-owned readiness/ratification, or any claim that
  a solver/model proves owner intent;
- general graph/ontology/theorem-prover/differentiable-logic infrastructure
  solely for the neuro-symbolic label;
- question volume, specification length or multi-model votes as intake quality;
- All subjective harness scores, weighted ratings and unsupported vendor
  rankings.
- Fixed `20/50/20/10` context allocation and unmeasured universal cache rules.
- Fictional or unverified OMP components such as `pi-headroom`,
  `headroom-retrieve` and `stream-filter`.
- “Seccomp-eBPF workspace sandboxing,” or any mechanism name used as proof of
  containment without behavioral tests and attestation.
- `agent://`, Agent Hub, transcripts, GitHub state or SQLite as Fleet authority.
- Same-model majority voting, arbitrary recursive swarms and agent count as a
  quality metric.
- Automatic AST-aware merge/conflict resolution as a safety boundary.
- The categorical claim that IDE agents lack headless/CI operation.
- Graph edges used as lifecycle authorization, resource locks or scheduler
  truth.
- A model-authored arbitrary graph, an in-flight topology mutation, or free-form
  sibling messages as required state.
- Any attempt to interrupt, expand or couple graph work into the active SQL-0
  migration.

## Exact mapping into the existing Fleet program

This edition adds no new FLEET number, but it adds the prerequisite NSI-1–NSI-6
program and changes the cross-program dependency from `SQL-0 -> FLEET-1` to
`SQL-0 -> NSI-1..6 -> FLEET-1`.

| Intake item | Vetted research mapping | Boundary retained |
| --- | --- | --- |
| **NSI-1 — Ontology and contracts** | Turns the current taxonomy/graph vocabulary into small typed schemas and explicit owner/model/repository/rule authority. | No general ontology platform and no model-authored production rules. |
| **NSI-2 — Claim/provenance ledger** | Persists exact source spans, proposals, admitted claims, owner decisions, derivations and supersession. | PostgreSQL/WorkService remains sole authority; Markdown is a view. |
| **NSI-3 — Code-owned reasoner** | Implements existing constraints plus applicability/conflict/coverage/pre-ratification assessment; adds only qualified formal adapters. | Solver results are relative to the encoding and cannot ratify meaning. |
| **NSI-4 — Gap-directed questioning** | Backward-chains readiness premises and asks one material owner decision using Fable rendering. | Model never invents necessity or answers itself. |
| **NSI-5 — Acceptance/ratification/readiness** | Builds claim-linked ACs and the exact sequence: assessment -> owner exact-hash ratification -> WorkService revalidation/current positive receipt -> `publishIntake`/published. | Semantic authority remains human; lifecycle authority remains WorkService. |
| **NSI-6 — Evaluation/cutover** | Four-arm intake ablation, false-ready corpus, shadow rollout and sole publication path. | No promotion from prose quality or question count. |

The optional exploration extension consumes those contracts without changing
the base `NSI-6 -> FLEET-1` edge:

| Exploration item | Vetted research mapping | Boundary retained |
| --- | --- | --- |
| **NSI-E1 — Durable run and budget contracts** | Converts the useful fan-out idea into owner authorization, one frozen manifest, immutable attempts and hard call/token/time/currency-or-resource controls on a shared bounded-model-job substrate. | No upstream runtime, hidden spend, second scheduler, model-selected authority or mutation of core NSI state. |
| **NSI-E2 — Frames, branches, screening and synthesis** | Uses deterministic reviewed perspectives, isolated tool-free proposals, typed pre/post-synthesis screening and a separate advisory synthesizer. | No automatic anchor rewriting, random unrecorded frames, branch cross-talk or model-score deletion. |
| **NSI-E3 — Owner-decision and presentation handoff** | Presents two to four neutral options and routes an exact confirmed owner answer through ordinary NSI admission; may create a post-publication planning artifact. | Unselected ideas are not requirements/non-goals, numeric confidence is not truth, and planning advice stays outside semantic closure. |
| **NSI-E4 — Qualification and canary** | Compares X-A/X-B/X-C0/X-C/X-D using pilot-then-holdout, equal/reported compute, identical X-C0/X-C synthesis route/prompt/limits, randomized presentation/deepening offer and owner/outcome/safety/currency-or-resource measures. | No hidden/automatic usage-consuming execution; N4 requires the full zero-critical, non-inferiority, value, limits and rollback predicate in the controlling contract. |

The later Fleet mapping consumes those qualified outputs:

| Program item | Vetted research mapping | Boundary retained |
| --- | --- | --- |
| **FLEET-1 — Authority, typed contracts and promotion policy** | Consumes NSI contract/ratification/readiness schemas, then defines `GraphTemplate`, `GraphManifest`, `GraphEpoch`, typed node/edge/join/artifact/resource contracts, `EvidenceManifest`, `AuditResult`, risk and policy identities. | Models propose judgment and bounded parameters; current typed contracts and policy decide legality. |
| **FLEET-2 — Versioned harness package and CI protection** | Extracts the overlay harness, progressive skills, template definitions/linters, policy registry and pinned-fork/upstream compatibility tests. | Core fork changes require a demonstrated hook gap; no second runtime or tracker. |
| **FLEET-3 — WorkService FleetControl kernel** | Enforces published intake state plus matching current positive receipt, then persists immutable graph epochs, node attempts, expected inputs, artifact satisfaction, joins, leases, fencing, idempotency, budgets and durable recovery. | PostgreSQL through WorkService remains sole authority; OMP Hub and conversation state do not substitute. |
| **FLEET-4 — Mechanical risk and capability router** | Derives a risk floor from admitted intake claims/unknowns and computes allowed topology, stages, models, containment and approvals. | Raw prose or a model cannot lower risk, authorize capability or select unbounded topology. |
| **FLEET-5 — Context compiler and symbol map** | Compiles the published contract, admitted claims, exact evidence, owner decisions and matching current positive receipt plus node/stage-specific repository context, provenance, redaction, stable-prefix hashes and cache telemetry. | No unadmitted prose or transcript concatenation as authority; no fixed context percentages. |
| **FLEET-6 — Stage runner and mechanical containment** | Runs each stage/node in an attested process/container profile with exact mounts, network, credentials, tools and candidate identity. Supplies the immutable auditor profile. | OMP worktree isolation alone is insufficient; sibling chat is never required state. |
| **FLEET-7 — Evidence, verification and typed audit** | Implements the fixed `verification_diamond`, exact-input join, baseline/candidate diagnostics, machine-generated evidence, fresh isolated typed audit and graph-epoch invalidation. | Every required node must pass for the exact candidate; repair starts a new evidence epoch. |
| **FLEET-8 — One-item zero-write vertical slice** | Refuses unpublished, missing or stale intake state/receipts, then exercises one eligible writer and the fixed verification diamond end to end, including controller death and artifact-based recovery. | No GitHub mutation, merge, WebUI, EM or parallel writer. |
| **FLEET-9 — Outcome and fault qualification** | Regresses NSI false-ready/omission gates, compares sequential and diamond verification, and evaluates graph faults, syntax feedback, cache layout, harness ablations and auditor performance. | Lower latency or better prose cannot promote a change if correctness/evidence regresses. |
| **FLEET-10 — GitHub broker** | Carries exact candidate, graph/evidence and policy identity through credential-isolated external intents and receipts. | Graph completion cannot write GitHub directly. |
| **FLEET-11 — Draft-PR canary** | Proves the first externally visible exact-candidate flow and invalidation after base movement. | Draft PR only; merge and completion remain manual. |
| **FLEET-12 — Exact-SHA CI/integration/closeout** | Binds CI, integration, evidence, audit and closeout to the exact SHA. Base movement or integration creates a new candidate/epoch and full re-verification. | No stale audit survives mutation or rebase. |
| **FLEET-13 — Bounded multi-item scheduler** | Adds resource/collision claims, explainable scheduling and qualified graph concurrency. Begins with one writer per repository. | Resource locks are separate from artifact edges; writer concurrency rises only by promotion evidence. |
| **FLEET-14 — Engineering Manager proposals** | Allows a fresh, unprivileged EM to propose portfolio/template/intake refinements. The controller validates topology, edges, joins, resources, capabilities and budgets. | No arbitrary graph, owner answers, claim admission, contract ratification, policy promotion, merge authority or in-flight topology mutation. |
| **FLEET-15 — Unattended operations** | Adds node/join health, dead-letter handling, graph budgets, drain/kill/recovery, alerts and rollback for promoted capabilities. | Only previously qualified work classes run unattended. |

### OMP Web / Remote Workbench / Work-Intake / Fleet Manager mapping

Official OMP Web does not receive graph scheduling authority. Its local Chat
surface may retain qualified rich local tools. Its restricted Remote Workbench
uses a narrow session gateway. After producer contracts exist, its Fleet mode
may render read-only projections of:

- source/evidence, proposed/admitted/rejected claims, owner decisions, gaps,
  conflicts, counterexamples, AC traceability, contract/ratification/readiness
  identity and invalidation;
- run, graph epoch, node and join state;
- expected versus received artifacts;
- exact candidate/evidence/audit identity;
- budgets, leases, fences and “why blocked/not running” reasons; and
- server-calculated allowed actions.

Later Fleet commands travel through the separate Fleet gateway and existing
WorkService/controller command contracts. Fleet mode never mutates graph state
directly, holds runner credentials, constructs authoritative evidence or
publishes the broad local Chat daemon. Remote session actions enter through the
different restricted gateway and cannot advance Fleet lifecycle.

A later owner-only question-answer or exact-hash ratification command is bound
to the current intake revision and high-assurance identity. It does not let the
WebUI, gateway, operator or Engineering Manager create readiness. Those owner
mutations enter only through the separate `WORK_OWNER` Work/Intake BFF after
NSI-6; neither the Remote Session gateway nor Fleet gateway may proxy them.

## Primary-source register

Use these sources to revalidate the corresponding claim; do not substitute the
secondary scorecard or a copied summary.

| Topic | Primary or closest authoritative source | Scope |
| --- | --- | --- |
| Requirements sufficiency gating | [RSGA at RE 2026](https://conf.researchr.org/details/RE-2026/RE-2026-Research-Papers/23/Requirements-Sufficiency-Gating-for-LLM-Assisted-Automation) | Peer-reviewed support for a blocking structured sufficiency gate; requires local OMP evaluation. |
| Ambiguity and clarification | [Orchid](https://arxiv.org/abs/2604.21505) and [ClarifyCodeBench](https://arxiv.org/abs/2607.00711) | Recent preprints supporting targeted clarification and key-question metrics; not a readiness proof. |
| Neural translation plus symbolic deduction | [Logic-LM](https://aclanthology.org/2023.findings-emnlp.248/) and [SymBa](https://arxiv.org/abs/2402.12806) | Supports separating model interpretation from code/solver reasoning and requesting missing premises. |
| Typed admission/runtime gating | [ToolGate](https://aclanthology.org/2026.findings-acl.470/) and [AgentSpec](https://conf.researchr.org/details/icse-2026/icse-2026-research-track/29/AgentSpec-Customizable-Runtime-Enforcement-for-Safe-and-Reliable-LLM-Agents) | Related enforcement evidence; not requirements-completeness proof. |
| NL-to-temporal formalization | [Req2LTL](https://arxiv.org/abs/2512.17334) and [NeuroNL2LTL](https://arxiv.org/abs/2605.22874) | Supports typed IR/deterministic compilation and, critically, separating satisfiability from semantic equivalence. |
| Requirements formalization diagnostics | [Neurosymbolic requirements auditing](https://arxiv.org/abs/2605.13817) and [Roundtrip verification](https://arxiv.org/abs/2604.25031) | Counterexample/ambiguity/drift techniques; recent preprints and advisory only. |
| Defaults and exceptions | [LLMs as ASP Programmers](https://aclanthology.org/2026.findings-acl.1151/) | Peer-reviewed reasoning evidence; qualify only for real defeasible requirements. |
| Provenance concepts | [W3C PROV-O](https://www.w3.org/TR/prov-o/) | Normative vocabulary; does not mandate RDF/OWL storage. |
| Bounded constraint solver mechanics | [Z3 guide](https://microsoft.github.io/z3guide/docs/logic/propositional-logic/) | Official SAT/cardinality/unsat-core mechanics; no natural-language or intent-fidelity guarantee. |
| Practitioner requirements interview | [Supplied Reddit post](https://www.reddit.com/r/ChatGPTPromptGenius/comments/1vrp7zw/i_used_ai_as_a_requirements_interviewer_on_a/) | Anecdotal technique only: exact quotes, missing decisions, owner answers and decision log. |
| Divergent ideation implementation | [`UditAkhourii/adhd` at `53ab5576`](https://github.com/UditAkhourii/adhd/tree/53ab5576b77fb3d6e62739a1a285356261e5f568), [engine](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/src/engine.ts), [Claude SDK dependency/version](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/package.json), [single conventional test](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/tests/llm.test.ts), [evaluation limitations](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/documentation/evals.md), [cost guidance](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/documentation/when-to-use.md), [benchmark sources](https://github.com/UditAkhourii/adhd/tree/53ab5576b77fb3d6e62739a1a285356261e5f568/bench), [preprint](https://adhdstack.github.io/) and [MIT license](https://github.com/UditAkhourii/adhd/blob/53ab5576b77fb3d6e62739a1a285356261e5f568/LICENSE) | Closest sources for implementation, cost and preliminary comparison claims. Main is ahead of tag/npm `v0.1.4`; useful pattern source only, not an OMP dependency or proof of owner/outcome benefit. |
| Multi-path reasoning research | [Tree of Thoughts](https://arxiv.org/abs/2305.10601) | Supports deliberate exploration on evaluated Game of 24, creative-writing and mini-crossword tasks; does not validate ADHD's frame set, scoring formula or OMP intake value. |
| Agent-computer interface effects | [SWE-agent paper](https://arxiv.org/abs/2405.15793) | Evidence that interface/harness choices affected results in the evaluated repository tasks. |
| OMP source and current capabilities | [OMP at `37eee719`](https://github.com/can1357/oh-my-pi/tree/37eee71978951fccf66b21f7e3e2b74596ac9d74) | Pinned implementation and documentation, including current feature counts. |
| Current omp-webui implementation | [`omp-webui` at `12f8c1e5`](https://github.com/theturtlecsz/omp-webui/tree/12f8c1e549b4bc4e07d769e409eb9bd662ce2175) | Existing browser/daemon/RPC/replay foundation and broad local command surface; not evidence that it is safe to expose remotely. |
| Kimi Web and packaging | [Browser guide](https://www.kimi.com/code/docs/en/kimi-code-cli/guides/web.html), [server API](https://www.kimi.com/code/docs/en/kimi-code-cli/reference/server-api.html) and [repository guide](https://github.com/MoonshotAI/kimi-code/blob/main/AGENTS.md) | Supports one-command Web, session handoff and separately developed bundled UI; does not license unavailable frontend code/assets. |
| Kimi Remote Control | [August 2026 release notes](https://www.kimi.com/code/docs/en/kimi-code/whats-new.html) | Evidence of product demand and an experimental release, not proof of OMP security architecture. |
| Orca remote/mobile/review UX | [Remote servers](https://www.onorca.dev/docs/remote-servers), [mobile](https://www.onorca.dev/docs/mobile) and [annotated diff](https://www.onorca.dev/docs/review/annotate-ai-diff) | Product interaction patterns only; unsafe/default orchestration semantics are not adopted. |
| Agent Orchestrator cockpit | [Architecture](https://aoagents.dev/docs/architecture/), [dashboard](https://aoagents.dev/docs/dashboard/) and [remote access](https://aoagents.dev/docs/configuration/remote-access/) | Attention/replay/exact-head lessons only; its authority stack does not replace OMP's. |
| Hashline benchmark | [Maintainer report](https://stencil.so/blog/the-harness-problem) and [benchmark package](https://github.com/can1357/oh-my-pi/tree/main/packages/typescript-edit-benchmark) | Maintainer-run, task/model-specific edit benchmark; not independent end-to-end issue evidence. Re-pin the package commit before reproduction. |
| OMP task and isolation behavior | [Task documentation](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/tools/task.md) | Task contracts, isolation configuration and output behavior at the inspected upstream commit. |
| OMP peer coordination | [Agent Hub documentation](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/tools/hub.md) | Live coordination surface; not durable Fleet authority. |
| OMP TTSR | [TTSR injection lifecycle](https://github.com/can1357/oh-my-pi/blob/37eee71978951fccf66b21f7e3e2b74596ac9d74/docs/ttsr-injection-lifecycle.md) | Actual stream-rule lifecycle at the pinned commit. |
| Claude Code internal snapshot | [Reverse-engineering study](https://arxiv.org/html/2604.14228v1) | Version-specific observations; internal/feature-gated details are not stable public contracts. |
| Claude Code public permissions | [Permission modes](https://code.claude.com/docs/en/permission-modes) and [Auto mode](https://code.claude.com/docs/en/auto-mode-config) | Current public modes and scope of classifier-based Auto mode. Recheck at intake time. |
| Anthropic prompt caching | [Claude Code caching](https://code.claude.com/docs/en/prompt-caching) and [Anthropic API caching](https://platform.claude.com/docs/en/build-with-claude/prompt-caching) | Prefix matching, TTL and cache behavior; no support for fixed context percentages. |
| Cursor headless operation | [Headless CLI](https://cursor.com/docs/cli/headless) and [Cloud Agents](https://cursor.com/docs/cloud-agent) | Direct counterexample to the categorical no-headless/no-CI claim. |
| Cursor indexing | [Secure codebase indexing](https://cursor.com/blog/secure-codebase-indexing) | Vendor account of Merkle synchronization, syntactic chunks, embeddings and background indexing. |
| Linux syscall filtering | [Linux seccomp filter documentation](https://docs.kernel.org/userspace-api/seccomp_filter.html) | Seccomp capabilities and explicit inability to dereference syscall pointer arguments. |
| Linux filesystem restriction | [Linux Landlock documentation](https://docs.kernel.org/userspace-api/landlock.html) | Optional unprivileged filesystem/network access controls; one layer, not complete sandbox proof. |
| Graph-engineering article | [Original article](https://x.com/AnatoliKopadze/article/2080668775796314331) | Practitioner design input, not a controlled OMP benchmark. |
| Dynamic graph workflows | [Claude Code workflows](https://code.claude.com/docs/en/workflows) | Documented graph/workflow concepts and controls. |
| Large migration case study | [Bun's Rust migration report](https://bun.com/blog/bun-in-rust) | Case-study evidence under Bun's own tests and supervision; not a Fleet outcome guarantee. |

## Revalidation rule

This appendix remains research, not truth carried forward by repetition. At the
next NSI or Fleet intake, every accepted delta must point to:

- a still-current source or inspected implementation;
- a current NSI/Fleet item and acceptance criterion;
- a deterministic contract or explicit experiment;
- a named failure mode and stop condition; and
- evidence that the delta does not reopen SQL-0 or create a second authority;
  and
- for NSI, exact schema/ontology/rule/compiler/solver/corpus versions plus local
  semantic-faithfulness and false-ready evidence.

If any of those is missing, classify the delta as `NEEDS_EVIDENCE` or remove it.
Do not preserve it because it appeared in a prior report, competitor comparison
or numerical score.
