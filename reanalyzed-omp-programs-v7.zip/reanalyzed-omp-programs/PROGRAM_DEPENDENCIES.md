# Cross-program dependency and promotion map

## Programs

```text
SQL-0  PostgreSQL/WorkService migration (active until PROVEN)
  |
  v
NSI-1  Intake ontology, IR and authority contracts
  |\
  | +--> NSI-2 claim/evidence/decision/provenance ledger
  +----> NSI-3 code-owned reasoner + selective formal adapter seam
             \                         /
              \                       /
               +--> NSI-4 gap-directed questioning
               +--> NSI-5 ACs, owner ratification and readiness receipts
                           \             /
                            v           v
                         NSI-6 evaluation, shadow and cutover
                                      |
                                      v
FLEET-1  Authority, typed contracts and promotion policy
  |\
  | +--> FLEET-2 versioned harness package + CI
  |         |\
  |         | +--> FLEET-4 risk router --> FLEET-5 context compiler
  |         +----> FLEET-6 stage runner + mechanical containment
  |
  +----> FLEET-3 WorkService FleetControl kernel
                 \                 /
                  \               /
                   v             v
              FLEET-7 graph verification + authoritative evidence + typed audit
                            |
                            v
              FLEET-8 one local item + verification diamond, zero external writes
                            |
                            v
              FLEET-9 ablation/auditor/intake/fault qualification
                          /   \
                         /     + FLEET-10 GitHub broker
                        v
              FLEET-11 one draft-PR canary
                            |
                            v
              FLEET-12 exact-SHA CI/integration
                            |
                            v
              FLEET-13 bounded multi-item scheduler
                            |
                            v
              FLEET-14 Engineering Manager proposals
                            |
                            v
              FLEET-15 unattended operations

OWEB-1/2 + NSI-6 + FLEET-1 -> WFM-1 -> WFM-3; their DAG unlocks WFM-2/4/5
NSI-6 + FLEET-3/7/8 --------> WFM-6..WFM-7 private read-only live UI
matching Fleet handlers ------> WFM-8/9/10 typed controls and stop/policy UX
FLEET-12 ---------------------> WFM-11 exact-SHA GitHub/CI integration
WFM-9/10/11 ------------------> WFM-12 hardening; FLEET-15 gates unattended use
```

Native OMP Web is a parallel product-surface graph. It does not alter the
authority chain above:

```text
                       OWEB-1 live rebaseline / product charter
                              /                         \
                  SQL-0 PROVEN                   SQL-0 PROVEN
                             v                           v
                 OWEB-2 packaging/commands      OWEB-3 sessions/handoff
                              \                         /
                               v                       v
                          OWEB-4 native local experience
                                      |
OWEB-1 + OWEB-3 ----------------> OWEB-5 restricted remote gateway
             OWEB-3 + OWEB-4 + OWEB-5 -> OWEB-6 Needs You/replies
SQL-0 + NSI-6 + OWEB-5 + OWEB-6 -----> OWEB-7 typed remote Intake
N4 + OWEB-7 --------------------------> remote Explore alternatives
OWEB-4 + WFM fixtures ----------------> OWEB-8 shared Fleet shell
OWEB-4 --------------------------------> OWEB-9 local lane
OWEB-5 + OWEB-6 -----------------------> OWEB-9 private-remote lane
OWEB-7 --------------------------------> OWEB-9 intake lane
OWEB-8 --------------------------------> OWEB-9 Fleet lane
```

- While SQL-0 is active, only OWEB-1 fixture/design work isolated in
  `omp-webui` may proceed, and only if it does not modify OMP core, WorkService,
  Fleet state or the migration.
- `SQL-0: PROVEN` plus OWEB-1 is a mechanical dependency of OWEB-2 and OWEB-3;
  live local packaging/session integration cannot start from prose permission.
- OWEB-7 cannot run before NSI-6.
- Remote **Explore alternatives** additionally requires N4; ordinary OWEB-7
  Intake remains available without the extension.
- OWEB-8 fixtures consume WFM-3/5; live read-only Fleet requires WFM-7 and
  FLEET-8; matching controls require WFM-8/10/11 and FLEET-12.
- OWEB-9 is one umbrella work item with independently closable local, private-
  remote, Intake and Fleet qualification lanes. Later lanes never block release
  of a proven earlier lane.
- OMP Web may be entirely offline without changing Fleet safety or recovery.

## Exact Native OMP Web graph

```text
SQL-0 + OWEB-1 -> OWEB-2, OWEB-3
OWEB-2 + OWEB-3 -> OWEB-4
OWEB-1 + OWEB-3 -> OWEB-5
OWEB-3 + OWEB-4 + OWEB-5 -> OWEB-6
SQL-0 + NSI-6 + OWEB-5 + OWEB-6 -> OWEB-7
NSI-E3 + OWEB-4 -> local Explore alternatives client fixtures
NSI-E4 + local client fixtures -> manual local exploration canary
N4 + OWEB-4 local client -> normal local Explore alternatives
N4 + OWEB-7 -> remote Explore alternatives
OWEB-4 + WFM-3 + WFM-5 -> OWEB-8 fixtures
OWEB-8 + WFM-7 + FLEET-8 -> OWEB-8 live read-only Fleet
OWEB-8 + WFM-8/10/11 + FLEET-12 -> corresponding Fleet controls
OWEB-4 -> OWEB-9 local lane
OWEB-5 + OWEB-6 -> OWEB-9 private-remote lane
OWEB-7 -> OWEB-9 Intake lane
OWEB-8 -> OWEB-9 Fleet lane
```

## Exact intake graph

```text
SQL-0 -> NSI-1
NSI-1 -> NSI-2, NSI-3
NSI-2 + NSI-3 -> NSI-4
NSI-2 + NSI-3 -> NSI-5
NSI-4 + NSI-5 -> NSI-6
NSI-6 -> FLEET-1
```

NSI-2 and NSI-3 may proceed in parallel only after NSI-1 freezes their shared
schemas/authority. NSI-4 and NSI-5 each require both the durable claim ledger
and reasoner. NSI-6 qualifies/cuts over the integrated path; an isolated solver
demo does not satisfy it.

## Optional bounded-exploration graph

The exploration extension consumes core NSI contracts but is not part of the
base authority chain and does not gate FLEET-1:

```text
NSI-1 + NSI-2 + NSI-3 -> NSI-E1
NSI-E1 + NSI-4 -> NSI-E2
NSI-E2 + NSI-5 -> NSI-E3
NSI-E3 + NSI-6 -> NSI-E4
NSI-E3 + OWEB-4 -> local Explore alternatives client fixtures
NSI-E4 + local client fixtures -> manual local exploration canary
NSI-E4 -> N4 owner-confirmed exploration
N4 + OWEB-4 local client -> normal local Explore alternatives
N4 + OWEB-7 -> remote Explore alternatives
```

- `NSI-E1` adds durable run, authorization, frozen-manifest, route/egress,
  currency-or-resource and usage contracts without changing claim or readiness
  authority. It requires the shared bounded-model-job substrate and exact MIT
  attribution/provenance if source material is copied.
- `NSI-E2` adds deterministic reviewed frames, isolated tool-free branches,
  code-owned schema/reference/duplicate/hard-constraint screening both before
  and after separate advisory synthesis, plus separately authorized one-option
  deepening.
- `NSI-E3` adds server/CLI contracts, neutral owner presentation, exact-answer
  confirmation through ordinary `recordOwnerDecision`, and the optional
  post-publication planning handoff outside semantic closure. The `omp-webui`
  repository owns the generated-contract local client sub-lane with OWEB-4.
- `NSI-E4` runs owner-approved offline evaluation, offer-only/no-model selector
  shadow and explicit local owner canaries before N4. It cannot authorize
  hidden or automatic usage-consuming execution.
- `NSI-6 -> FLEET-1` remains the base edge. Absence, failure or disabling of
  the extension cannot make ordinary intake or Fleet ineligible.

## Exact Fleet graph

```text
NSI-6 -> FLEET-1
FLEET-1 -> FLEET-2, FLEET-3
FLEET-1 + FLEET-2 -> FLEET-4
FLEET-2 + FLEET-4 -> FLEET-5
FLEET-2 -> FLEET-6
FLEET-3 + FLEET-5 + FLEET-6 -> FLEET-7
FLEET-3 + FLEET-4 + FLEET-5 + FLEET-6 + FLEET-7 -> FLEET-8
FLEET-8 -> FLEET-9
FLEET-3 + FLEET-6 + FLEET-7 -> FLEET-10
FLEET-9 + FLEET-10 -> FLEET-11
FLEET-11 -> FLEET-12
FLEET-9 + FLEET-12 -> FLEET-13
FLEET-9 + FLEET-13 -> FLEET-14
FLEET-9 + FLEET-12 + FLEET-13 + FLEET-14 -> FLEET-15
```

## Cross-program contracts

| Producer | Consumer | Contract |
| --- | --- | --- |
| SQL-0 | NSI-1/2 and FLEET | WorkService authority, API/schema versions, actor identity, idempotent mutation, durable events, content-addressed evidence seam, backup/restore and migration proof |
| NSI-1 | NSI-2/3/4/5 | Versioned ontology, predicates, typed claim/requirement IR, authority matrix, unknown/waiver semantics, canonicalization and schema compatibility |
| NSI-2 | NSI-3/4/5 | Frozen snapshots, exact evidence spans, candidate/admitted/superseded claims, decisions, derivations, conflicts and provenance closure |
| NSI-3 | NSI-4/5/6 | Code-owned reason IDs, gaps, conflicts, coverage, deterministic readiness inputs and selectively qualified formal results |
| NSI-4 | NSI-6 and owner UX | One current gap-directed question, exact deciding evidence, answer schema, immutable owner decision and resumable agenda |
| NSI-5 | NSI-6/Fleet/WFM | Typed ACs, canonical IntakeContract, pre-ratification IntakeReadinessAssessment, owner RatificationReceipt, per-property RatifiedFormalBinding, `ELIGIBLE_FOR_PUBLICATION` receipt, IntakePublicationReceipt/published state, currentness/invalidation and Markdown projection |
| NSI-6 | FLEET-1, WFM-1/3 and OWEB-7 | Qualified schema versions, corpus/results, zero-critical-false-ready proof, sole-path cutover/rollback and generated consumer fixtures |
| NSI-1/2/3/4 | NSI-E1/E2 | Current question identity, admitted constraints/provenance, deterministic eligibility, frozen context inputs and owner-decision APIs |
| NSI-E1 | NSI-E2 | Durable authorized run, identical content-addressed manifest, deterministic frame bundle, limits, reservations and attempt schema |
| NSI-E2 | NSI-E3 | Isolated stage/branch attempts, deterministic screening, neutral advisory synthesis, partial-failure plus reconciling/outcome-unknown state, conservative accounting and fresh-authorized replacement semantics |
| NSI-E3 | NSI-E4 and OWEB-4/7 clients | Generated offer/run/status/option/owner-action projections and fixtures, neutral option presentation, exact owner answer/source linkage, planning-handoff artifact and proof that only ordinary NSI-5 owner-decision admission can change semantic state |
| NSI-E4 | N4 | Versioned X-A/X-B/X-C0/X-C/X-D results, owner-value/selector/currency-or-resource evidence, security/fault evidence, manual local canary, promotion policy and rollback proof |
| FLEET-1 | All Fleet/WFM | State transitions, TaskRisk, intake eligibility, portfolio/lifecycle/execution-graph separation, graph/sandbox/context/evidence/audit schemas, action-risk matrix and versioned read/command/event requirements |
| FLEET-2 | FLEET-4/5/6 | Versioned harness package, qualified intake integration, progressive skills, policy registry, CI and OMP compatibility boundary |
| FLEET-3 | FLEET-7/8 and WFM-6 | Contract/receipt eligibility, claims/fencing, immutable graph epochs/nodes/edge satisfaction/joins, operations/events, projections, stop epoch and server-calculated allowed actions |
| FLEET-4/5 | FLEET-7/8/14 and WFM-7 | Claim-derived risk reasons, ContextManifest, stable section/prefix hashes, cache telemetry, symbol map and admitted-policy provenance |
| FLEET-6 | FLEET-7/8 | Mechanically contained stage profiles, SandboxProfile/Attestation, immutable auditor environment and qualified fresh-only K3 transport/history behavior |
| FLEET-7 | FLEET-8/9/10 and WFM-6/7 | Graph/node receipts, all-required verification join, runtime EvidenceManifest, parser/LSP diagnostics, VerificationReceipt, typed AuditResult and exact invalidation rules |
| FLEET-10/12 | WFM-11 | GitHub/PR/CI/merge exact-SHA projections, broker operations and reconciliation receipts |
| WFM-3 | WorkService/Fleet | Consumer-driven NSI/Fleet contract tests and generated-client compatibility |
| OWEB-1 | OWEB-2/3/4/5 | Live OMP/omp-webui capability inventory, product charter, trust surfaces, session ownership, Kimi/Orca/AO disposition and desktop/mobile journeys |
| OWEB-2 | OMP release + OWEB-4/9 | `omp web`/`/web`, immutable bundle manifest, reproducible build, readiness and core/RPC/browser capability-version negotiation |
| OWEB-3 | OWEB-4/5/6 | Canonical OMP session identity, driver lease, per-session events/cursors, replay/reconnect, cancellation and honest lifecycle |
| OWEB-5/6 | Owner remote-session UX and OWEB-7 identity prerequisites | Separate restricted Session gateway, identity/device grants, sanitized session projections, typed AttentionItem, notifications and exact revision-bound replies; no WorkService mutation path |
| OWEB-7 | WorkService/NSI | Separate least-privileged Work/Intake BFF/origin/service identity and generated NSI client; no Remote Session, Fleet or GitHub authority |
| NSI-6 | OWEB-7 | Generated intake draft/question/contract/ratification/readiness/publication projections and exact owner-action contracts |
| WFM/Fleet | OWEB-8 | Generated Fleet projections/events/commands and exact candidate review identities; OMP Web remains a consumer |

## Activation gates

| Gate | Required proof | Newly allowed capability |
| --- | --- | --- |
| G0 — SQL authority | Migration reconciliation, complete interactive workflow, typed extension seams, backup/restore and no legacy writer | Publish/plan NSI and begin OWEB-2/3 native-local work after OWEB-1; no Work/Intake mutation or Fleet authority |
| N1 — Intake contracts/provenance | Versioned schemas, canonical hashes, authority and complete source/claim/decision/derivation storage | Run deterministic reasoner in shadow |
| N2 — Intake reasoning/interaction | Rule/property tests, unknown/conflict behavior, every question maps to a gap, owner ratification, positive receipt currentness and exact publish transition | Run full revised intake in shadow/advisory mode |
| N3 — Intake qualification | Zero false-ready on seeded critical omissions, complete provenance for premises contributing to `READY_FOR_RATIFICATION`, deterministic/security/fault gates and rollback | Typed intake sole publication path; only published positive-receipt work may publish/plan Fleet program |
| N4 — Owner-confirmed exploration | X-A/X-B/X-C0/X-C/X-D holdout; zero authority, containment, secret/egress, currentness, fencing, idempotency or limit-enforcement violations; zero critical conflicts presented as compliant, exposed as selectable or admitted into owner/semantic state; zero option submission after staleness; preregistered non-inferiority on false-ready, critical omissions, provenance closure and owner-correction burden; stable material benefit over X-A and an equal-compute control; owner-confirmed currency/resource limit compliance; proven rollback; and durable partial/cancel/unknown-outcome semantics | Optional owner-triggered Explore alternatives locally; remotely only with OWEB-7. No automatic usage-consuming execution. |
| G1 — Harness foundation | Versioned package/CI, deterministic risk/context, current intake receipt validation, graph contracts/persistence, OS containment with attestation, machine evidence, immutable typed auditor and authenticated fresh-only K3 qualification | Run one zero-write candidate |
| G2 — Local single item | Restart-safe exact candidate, fixed verification diamond with all-required join, immutable typed audit and no stale/duplicate effects | Outcome/fault qualification |
| G3 — Qualification | A–G same-worker ablation, intake receipt regression, sequential-vs-graph, syntax-feedback and cache-layout experiments, seeded auditor thresholds and perfect containment/fencing/idempotency | Draft-PR canary |
| G4 — PR-only canary | Exact candidate PR, no ambiguous duplicates, manual merge | Exact-SHA CI/integration |
| G5 — Merge canary | Rebase invalidation, CI, merge and closeout reconcile correctly | Allowlisted low-risk auto-merge |
| G6 — Scheduler | Dependency/lock/budget/failover evidence, initially one writer/repo | Slowly raise multi-item concurrency |
| G7 — EM shadow | Proposal quality and policy validation meet calibrated threshold; no owner impersonation | Recommendations, then bounded reversible decisions |
| G8 — Operations | Kill/drain, backup/restore, chaos, alerts, rollback and runbooks proven | Unattended eligible-backlog drain |
| UI-1 — Fleet fixture | Separate Fleet gateway/origin, authz harness and hostile NSI/Fleet fixtures | No live access |
| UI-2 — Fleet private read-only | Scoped projections, durable cursor/replay and sanitized typed evidence | Private remote Fleet observation |
| UI-3 — Fleet operator canary | Idempotent Fleet commands, revisions, immutable Fleet challenges, stop/fencing and audit | Allowlisted Fleet operations; Intake owner actions remain OWEB-N1 |
| UI-4 — Fleet public exposure | Separate threat review and private operational evidence | Broader Fleet network exposure, if desired |
| OWEB-F0 — Fixture | Rebaseline, journeys, schemas and hostile fixtures; no remote listener or authoritative mutation | Build official-Web components safely |
| OWEB-L1 — Native local | Bundled matching assets, `omp web`, exact `/web` handoff, loopback, replay and cross-session isolation | Supported local OMP Web |
| OWEB-R1 — Private read-only | Separate gateway/origin, identity, device revocation, sanitized transcript/attention projections | Private remote observation |
| OWEB-R2 — Needs You canary | Exact revision-bound answer, safe cancel, bounded approval kinds, privacy-preserving notifications | Allowlisted remote interaction |
| OWEB-N1 — Typed Intake | NSI-6, collecting draft, exact ratification and WorkService publication gates | Remote New Work without bypassing readiness |
| OWEB-F1 — Fleet cockpit | FLEET-8 and WFM-7 live projections; proof Web can fail offline | Live read-only Fleet in OMP Web |
| OWEB-F2 — Fleet controls | Matching WFM/Fleet handlers, fencing, candidate/revision checks and qualification | Only the corresponding typed controls |
| OWEB-P1 — Public exposure | Separate threat review after private operational evidence | Broader exposure only if still desired |

## Risk and model policy

| Function/risk | Initial policy |
| --- | --- |
| Intake interview | Fable high candidate claims/questions; no readiness authority |
| Large/high-risk intake alternate | Fresh K3-256K high, full K3 only for capacity; ambiguity/formalization proposals only |
| Intake reasoning | Deterministic NSI engine; selective formal adapters by code-owned profile |
| Intake ratification | Authenticated owner only |
| Intake exploration generation | Four fresh Flash-medium tool-free branches under deterministic reviewed frames and one identical frozen manifest; explicit owner authorization and enforceable currency-or-resource limits |
| Intake exploration synthesis | Fresh Sol-high separate critic/synthesizer; code screens schema, references, duplicates and known hard constraints first; output is neutral advice |
| Intake exploration deepening | Fresh K3-256K high only after a separate owner request and budget authorization; never automatic |
| Low execution | Flash high, deterministic checks; independent audit retained during qualification |
| Standard execution | Fresh K3-256K high for multi-file planning/implementation; Flash remains trivial/local; Opus audit |
| Standard with large context | Fresh full K3 high when compiled context/tool trajectory requires capacity |
| High | Sol plan/advice, Terra high worker, hardened sandbox, Opus audit and specialist |
| Critical | Sol xhigh, owner authorization unless narrowly pre-authorized, hardened sandbox, Opus audit and adjudication |

Risk derives from admitted claims, recorded unknowns and qualified repository/
tool facts. It may only stay level or rise within an attempt. K3 routes are
initially `fresh_only_no_resume_no_compaction`; full K3 is a capacity route, and
max is a new attempt. When K3 implements and Opus audits, use Sol or Gemini for
third-family adjudication.

## Graph separation and topology policy

- The intake claim/provenance graph, Work-item dependency DAG, legal lifecycle,
  per-attempt execution DAG and resource/capability constraints are separate.
- Models may propose claims or bounded graph parameters; they do not admit
  claims, ratify meaning, execute arbitrary topology or mutate a live epoch.
- Exploration branch graphs are code-owned, immutable per run and advisory.
  Branches cannot see one another, use tools, alter the input manifest, delete
  candidates by model score or feed directly into readiness.
- The Fleet controller begins with code-owned execution templates. The first
  graph is a verification diamond whose all-required join fails closed.
- A changed source/claim/contract invalidates intake readiness; a changed
  candidate/plan/input invalidates the affected Fleet graph descendants.
- Parallel read-only discovery is qualified after the verification diamond.
  Parallel writers remain deferred until disjoint ownership, isolated
  worktrees, integration and complete post-integration verification are proven.
- Agent messages may aid exceptional coordination but are never claim,
  dependency, completion or authorization truth.

Keep these owner-gated or prohibited until separately qualified:

- unresolved product semantics or missing acceptance decisions;
- authentication, authorization, secrets and security boundaries;
- schema/data migrations and destructive operations;
- concurrency/distributed-state invariants;
- public API/protocol compatibility;
- dependency/supply-chain execution or new egress;
- release, deployment, infrastructure and production configuration;
- billing, privacy, compliance and access-control policy.

## Stop rules

Any of the following prevents advancement and produces evidence:

- missing owner decision, unresolved material claim or incomplete provenance;
- intake verdict `NEEDS_SPEC`, `CONFLICTED`, `STALE` or `INVALID`;
- missing/mismatched ratification, positive readiness or publication receipt,
  or intake state other than `published`;
- required formal result `UNKNOWN`, `NOT_FORMALIZABLE`, `SOLVER_ERROR`, UNSAT or
  counterexample not resolved according to policy;
- unmet/mutated acceptance contract;
- stale work revision, lease, fence, Run/Context/Evidence Manifest, plan, base,
  candidate, graph epoch or node input;
- cycle, missing/duplicated required input, ambiguous join cardinality,
  conflicting resource claim or attempted in-flight topology mutation;
- required deterministic verification failure;
- unavailable mechanically independent auditor;
- malformed/unsupported typed result, dangling evidence or forged PASS/READY;
- auditor containment/mutation/network/credential violation;
- unknown external outcome not yet reconciled;
- budget/deadline/retry/repair exhaustion;
- policy, risk, capability, lock, provider or stop-epoch denial;
- context conflict, stale compilation, prompt injection or secret-leak event.
- exploration input/manifest/question/policy revision mismatch, missing owner
  authorization, cap exhaustion, malformed or dangling candidate references,
  attempted lifecycle mutation, or an exact answer that was not confirmed.

The scheduler may continue other independent eligible work. A blocked item never
pressures the system into guessing.
