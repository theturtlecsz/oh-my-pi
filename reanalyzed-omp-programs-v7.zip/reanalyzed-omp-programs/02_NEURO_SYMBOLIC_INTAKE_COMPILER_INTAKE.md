# Paste-ready intake: Neuro-symbolic Intake Compiler

Run this in a fresh OMP session rooted in the `theturtlecsz/oh-my-pi` checkout
only after the PostgreSQL migration reports `SQL-0: PROVEN`. This program is
the new prerequisite for the Autonomous Fleet Kernel. It hardens the existing
interactive `/intake`; it does not replace its owner-facing experience with a
formal-methods UI.

This v7 intake also defines an optional, separately promoted **Explore
alternatives** extension. Its normative additive contract is
`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`. Exploration helps the owner
compare answers to a current material question or, after publication, compare
implementation approaches. It is never required for base intake readiness or
Fleet eligibility.

```text
/intake Existing plan/draft — program-level intake.

PROGRAM TITLE

Neuro-symbolic Intake Compiler and Requirements-Sufficiency Gate

CONTEXT AND PROCESS

This intake concerns:

- https://github.com/theturtlecsz/oh-my-pi
- the completed PostgreSQL/WorkService migration program and its live records;
- the current `session-system/skills/intake` skill, model-bookends extension,
  workflow client, WorkService APIs/schemas and their tests;
- the later Autonomous Fleet Kernel only as a consumer of a ratified contract.

Begin by resolving and recording the actual repository HEAD, installed OMP
version, WorkService API/schema version, `SQL-0` completion receipt, current
intake implementation and related published work. Do not assume the commits or
line references in this prompt remain current. Inspect source, documentation,
tests, generated contracts and effective runtime configuration.

At package research time, the fork's main was inspected at
`cad0e2d12100aa22ec3b4e3eb28b7f8f8d5764c8`. Its intake already had a fixed
11-category taxonomy, a visible scan, one-question-at-a-time
`AskUserQuestion`, an ephemeral entity graph, exactly-one/exclusive/
allowed-values/transitive constraints, a dangling-edge stop and a lint before
publication. Its `/intake` bookend routed to `@intake` at high effort. Treat
these as evidence anchors to revalidate, not facts to assume.

Run this as an Existing plan/draft intake. Do not implement anything and do not
publish automatically. Complete the repository scan, present-state crosswalk,
authority/threat pass and Socratic pass first. Ask only decisions whose answers
materially change product meaning, authority, data safety, security,
compatibility, rollout or scope.

Before proposing children, query WorkService for related work. For every
capability classify it as PRESENT_AND_PROVEN, PRESENT_NOT_PROVEN, MISSING or
NOT_APPLICABLE with concrete evidence. Reuse/link existing work rather than
duplicating it. Use one stable program idempotency key and deterministic child
keys.

After owner ratification, publish exactly one parent program and the smallest
dependency-linked children defined below through WorkService. If `SQL-0` is not
PROVEN, WorkService publication is unavailable, or Linear/SQLite remains an
active work authority, do not implement and do not partially publish. Produce
a deterministic publication-ready manifest and stop with BLOCKED plus the
exact unmet prerequisite.

OWNER-RATIFIED OUTCOME

Upgrade `/intake` from neural interpretation plus symbolic prompting into a
genuine neuro-symbolic control loop:

owner request and repository evidence
  -> neural semantic proposals
  -> typed, provenance-carrying claims
  -> code-owned ontology, rules and constraints
  -> deterministic conflicts, missing premises and counterexamples
  -> one gap-directed owner question
  -> optional owner-confirmed bounded exploration of that exact question
  -> owner decision and recomputation
  -> traceable acceptance criteria
  -> owner ratification of an exact contract hash
  -> pre-ratification assessment, then server-generated positive receipt
  -> explicit publishIntake transition
  -> Markdown rendered as a human view

The existing daily interaction should remain simple: the owner runs `/intake`,
answers one material question at a time, reviews the interpreted contract and
ratifies it. The machinery underneath becomes deterministic and auditable.
When a consequential question has several valid answers, the owner may instead
choose **Explore alternatives**, inspect a small neutral comparison and then
confirm the exact answer that enters the same decision loop.

CORE DOCTRINE

Neural models investigate, interpret, decompose, propose and explain.
Deterministic symbolic code validates explicitly modeled constraints. The owner
ratifies meaning. WorkService owns revisions, evidence, decisions, derivations,
readiness and publication truth.

A solver result is always relative to an explicit encoding. It never proves
that the encoding captured the owner's intent or that informal requirements
are universally complete. No UI, receipt, model response or documentation may
collapse those different claims into `CORRECT` or `PROVEN`.

NON-NEGOTIABLE AUTHORITY MODEL

1. PostgreSQL through WorkService is the sole durable authority for intake
   runs, frozen source snapshots, typed entities and claims, evidence spans,
   decisions, derivations, conflicts, clarification questions, acceptance
   criteria, readiness assessments, ratification, positive readiness receipts
   and publication revisions.

2. The intake model may propose interpretations and clauses. A model proposal
   is never an owner statement, repository fact, admitted policy or readiness
   decision merely because the model is confident or multiple models agree.

3. Owner answers establish product intent. Repository/tool evidence establishes
   observations about an exact artifact or commit. Neither silently substitutes
   for the other. Absence is `unknown`, not `false`.

4. Code owns ontology versions, rule bundles, schema validation, namespace and
   type checks, cardinality, conflict detection, graph traversal, applicability,
   coverage and readiness. Production rule bundles are reviewed source, not
   arbitrary model output.

5. WorkService mints readiness and ratification receipts server-side from an
   expected work/intake revision and exact hashes. A model cannot submit a
   fabricated PASS, ratification or receipt.

6. Markdown is a deterministic projection from canonical typed records. It is
   never reparsed to recover lifecycle truth and cannot authorize a mutation.

7. The future planner, worker, auditor, Engineering Manager and Fleet Manager
   may consume typed projections according to policy. They cannot retroactively
   rewrite the owner request, admit a missing owner premise or self-ratify.

8. Every authoritative mutation uses actor identity, expected revision,
   idempotency key, canonical request hash and an append-only event/receipt.
   Unknown outcomes are read and reconciled before retry.

9. Every reasoning pass binds to a frozen source snapshot, ontology version,
   rule-bundle hash and engine version. Source, rule or contract drift makes a
   prior readiness result `STALE`; it is never silently reused.

10. Untrusted work text, repository content, comments, tool output and model
    proposals remain data. They cannot add rules, change authority, invoke a
    solver profile, waive a gate or cause a WorkService mutation outside the
    typed command being evaluated.

PRESERVE AND HARDEN THE CURRENT INTAKE UX

Preserve where current-state evidence confirms them:

- `/intake` as the single owner entry point and the existing Fable-high
  bookend;
- the fixed 11-category vocabulary as the starting domain ontology;
- issue-archetype-aware visible scanning rather than a universal questionnaire;
- repository inspection before owner questions;
- exactly one decision per `AskUserQuestion` and waiting for its answer;
- complete deciding data inside the question/dialog;
- explicit options only when the choices are genuinely bounded and symmetric;
- exact source wording, decisions log, acceptance criteria and coverage view;
- two-phase preview/owner confirmation before publication;
- fail-closed publication when WorkService is unavailable.

Change these semantics:

- the entity graph becomes a versioned typed WorkService artifact, not only an
  ephemeral model-maintained note;
- the same model no longer constructs, interprets and certifies its own graph;
- every question must reference an unresolved symbolic premise or material
  conflict produced by code;
- an eligible question may expose a secondary owner-confirmed exploration
  action, but no model call starts automatically and the direct-answer path
  remains primary;
- repository-discoverable facts go to tools before the owner;
- a question budget limits interaction but never converts unresolved critical
  gaps into readiness; exhaustion yields `NEEDS_SPEC` with a resumable agenda;
- `--publish <blueprint>` bypasses conversational interviewing only, never
  schema admission, provenance, consistency, owner ratification or readiness;
- the current prompt lint becomes a renderer/compatibility check after
  machine-owned validation, not the authoritative proof of sufficiency.

REQUIREMENTS-INTERVIEWER PRACTICES TO ADOPT

Use the supplied Reddit post only as practitioner inspiration, not scientific
evidence. Adopt the parts that fit the authority model:

- retain the owner's exact words as content-addressed evidence;
- normalize interpretations beside, never instead of, the source wording;
- do not let the model answer missing owner decisions for the owner;
- ask about one missing decision and record the resulting decision explicitly;
- show alternatives, examples or counterexamples when they expose materially
  different behavior;
- preserve assumptions, non-goals and rejected interpretations;
- make final review a semantic ratification, not a ceremonial approval.

Do not adopt question count, specification length or model verbosity as success
metrics. Do not issue a forty-question batch, force every question into closed
choices, or expand a small issue into an encyclopedic specification.

CANONICAL PIPELINE

1. BEGIN — WorkService creates an intake run from an expected Work revision and
   freezes source artifacts, repository commits, schema version, ontology
   version and rule-bundle hash.

2. INVESTIGATE — tools collect repository facts with exact commit/path/span or
   artifact hashes. The intake model may request investigation but cannot label
   its own recollection as observed evidence.

3. PROPOSE — Fable submits typed candidate entities, atomic claims,
   requirement clauses, interpretations, non-goals and evidence links. All are
   `proposed` until admission rules accept them or owner action ratifies them.

4. ADMIT — WorkService validates schemas, IDs, namespaces, predicate types,
   source spans, authority requirements and revision/hash bindings. Invalid
   proposals are rejected with structured diagnostics.

5. REASON — a deterministic reasoner applies the frozen ontology and rule
   bundle. It derives applicable requirement dimensions, consequences,
   missing premises, conflicts, coverage gaps and risk lower bounds. Optional
   formal adapters may add bounded solver results but never replace admission.

6. QUESTION — the gap engine removes tool-discoverable gaps, ranks remaining
   owner decisions by materiality and downstream fan-out, and emits one typed
   `ClarificationQuestion`. Fable may render the question and explain its
   consequence; it may not invent why it is required.

6A. EXPLORE OPTIONAL — for a current eligible question, code may create an
   `ExplorationOffer`. Only the owner can authorize its exact budget. Fresh,
   isolated, tool-free branches receive the same frozen input manifest under
   reviewed frames; deterministic code screens malformed, duplicate and
   hard-conflicting proposals and labels unsupported factual assertions; a
   separate model produces a concise neutral comparison. Exploration itself records no owner answer,
   claim, gap resolution or readiness result.

7. DECIDE — the owner's answer is preserved exactly, normalized into candidate
   claims, shown back when interpretation is nontrivial and admitted as an
   owner decision only through a typed expected-revision mutation. Rules rerun.

8. DRAFT ACCEPTANCE — Fable drafts observable acceptance criteria from admitted
   desired/prohibited claims. Code verifies traceability, coverage, oracle,
   boundary/negative cases and conflict with non-goals.

9. RATIFY — present original wording, normalized contract, assumptions,
   non-goals, unresolved/semantic-only clauses, examples/counterexamples,
   acceptance criteria and exact contract hash. Only the owner may accept the
   semantic mapping.

10. RECEIVE — after ratification, WorkService recomputes against the same exact
    semantic closure and expected revision. It either mints a positive-only
    readiness receipt or returns the run to a typed failure assessment/state.

11. PUBLISH — an authenticated, idempotent `publishIntake` command requires the
    current positive receipt and matching ratification, then transitions the
    run to `published`. A receipt that was never published grants no planner or
    Fleet capability.

12. PROJECT — render canonical Markdown and downstream planner/context views.
   Render failure does not alter typed state.

12A. EXPLORE APPROACHES OPTIONAL — only after successful publication, the
    owner may authorize a contract-bound implementation-approach exploration.
    Its artifact is labeled advisory planning context, excluded from the
    semantic closure and invalidated by contract/snapshot drift.

13. INVALIDATE — a material owner edit, source revision change, ontology/rule
    change, acceptance change or dependency change invalidates affected
    derivations and readiness. Recompute; never patch the old receipt.

MINIMUM TYPED DOMAIN

Ratify versioned schemas, semantically equivalent to the normative contract in
`03_NEURO_SYMBOLIC_INTAKE_TECHNICAL_CONTRACT.md`, for at least:

- `IntakeSnapshot` and `IntakeRun`;
- `IntakeOntology`, `PredicateDefinition` and `RequirementDimension`;
- `EntityRef`, typed values and `IntakeClaim`;
- `EvidenceArtifact`, `EvidenceSpan` and claim-evidence links;
- `DerivationReceipt`, `Conflict` and `Gap`;
- `OwnerDecision` and `ClarificationQuestion`;
- `RequirementClause`, `AcceptanceCriterion` and trace links;
- `Formalization`, `FormalCheckResult`, `RatifiedFormalBinding` and solver
  receipts;
- `IntakeContract`, `IntakeReadinessAssessment`, `RatificationReceipt`,
  positive-only `IntakeReadinessReceipt` and `IntakePublicationReceipt`.

When the optional exploration extension is enabled, additionally ratify the
`ExplorationPolicy`, eligibility, offer/authorization, input-manifest, frame,
budget policy/ledger/reservation, provider data-handling/egress/ingress,
authorization consumption, stage-attempt/invocation-intent/reconciliation,
run/branch/deepening, candidate/option/assertion screening, synthesis/usage,
separate `OwnerDecisionExplorationLink` and advisory
`PlanningExplorationArtifact` contracts in
`03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`. These types are not required
for base NSI cutover or FLEET-1.

Claims must distinguish at minimum:

- origin: owner statement, repository observation, tool receipt, model proposal
  or rule derivation;
- state: proposed, admitted, rejected or superseded;
- epistemic/modality: observed, desired, required, prohibited, possible or
  unknown as appropriate;
- polarity and scope;
- source evidence, derivation inputs/rule identity and content hash.

Required invariants:

- model proposals cannot satisfy owner-authority premises;
- owner intent cannot masquerade as repository observation;
- contradictory supported claims remain visible until resolved;
- last-write-wins never erases disagreement or provenance;
- supersession creates a new revision and invalidates affected derivations;
- every repository observation is bound to an exact source revision;
- every premise contributing to a `READY_FOR_RATIFICATION` assessment has
  complete provenance;
- every admitted desired/prohibited behavior is covered by an acceptance
  criterion or explicit owner waiver where policy permits;
- an acceptance criterion has an observable outcome and oracle;
- waivers identify the owner, exact premise, reason and decision revision;
- critical security, migration, destructive, compatibility or product-semantic
  gaps cannot be waived by a model or hidden by a completeness score.

ONTOLOGY AND RULE POLICY

Begin with the current 11 categories. Convert them into a small versioned
ontology with stable IDs, predicates, allowed subject/object types,
cardinality/exclusivity rules, applicability conditions, materiality,
authority requirements and waiver policy. Specialize applicability for actual
issue archetypes such as bug, feature, migration, security, refactor and
operational change; do not ask every category mechanically on every issue.

Implement the current exactly-one, exclusive, allowed-values, transitive,
dangling-edge and coverage rules in typed deterministic code with property
tests. Add readiness/risk rules only when they have explicit IDs, tests,
explanations and ownership. Keep a registry recording rule ID/version, scope,
enforcement layer, source issue/decision and evaluation coverage.

Do not let negation over incomplete data create false facts. Missing is
`unknown`. A readiness rule must enumerate its supporting claims, missing
premises and conflicts.

SOLVER ROUTING — SELECTIVE, CODE-OWNED AND FAIL-CLOSED

Do not add a solver merely to earn the neuro-symbolic label. Start with schemas,
database constraints, typed rules and deterministic graph algorithms. Introduce
formal adapters only for a concrete requirement class with fixtures and a
measured advantage.

- Type/schema/cardinality/exclusivity/applicability: normal typed code and
  database constraints.
- Dependency closure/cycles/missing prerequisites: deterministic graph
  algorithms.
- Bounded Boolean, arithmetic, resource, cardinality, string or relational
  contradictions: Z3/SMT only when ordinary validation is inadequate.
- Defaults with genuine layered exceptions: explicit precedence first; qualify
  ASP only if real corpus cases justify it.
- Temporal/lifecycle/concurrency/safety properties: LTL/model checking only for
  high-risk work with an explicit state/event model.
- UX taste, architecture quality, maintainability and open-ended product value:
  `NOT_FORMALIZABLE`; retain semantic owner/auditor review.

The controller selects the allowed formal profile from typed risk/claim data.
The model may propose a formalization IR but may not emit arbitrary executable
solver code into production. Use a deterministic compiler from a reviewed IR.
Execute external solvers in a bounded, network-denied worker with version,
timeout, input hash, output artifact and resource receipt. Preserve `UNKNOWN`,
`NOT_FORMALIZABLE` and `SOLVER_ERROR`; never coerce them into PASS.

Pre-ratification formal-result vocabulary:

- HOLDS_RELATIVE_TO_DRAFT_FORMAL_MODEL
- COUNTEREXAMPLE
- UNSAT
- UNKNOWN
- NOT_FORMALIZABLE
- NEEDS_OWNER_DECISION
- SOLVER_ERROR

Use witnesses, counterexamples and conflict/unsat cores to explain a gap. An
unsat core need not be minimal and is not automatically the optimal question.
No solver result may silently modify owner-ratified intent. After ratification,
WorkService may create a per-property `RatifiedFormalBinding` with
`VERIFIED_RELATIVE_TO_RATIFIED_MODEL` only when it binds the exact draft result
and formalization to the exact owner-ratified semantic closure. It creates no
such binding for semantic-only or unverified properties.

READINESS AND RATIFICATION

Readiness verdicts:

- READY_FOR_RATIFICATION — machine checks pass for the current draft, but the
  owner has not ratified its meaning;
- NEEDS_SPEC — material premises remain unknown or the question budget ended;
- CONFLICTED — supported claims cannot jointly stand without a decision;
- STALE — inputs, rules, schema or sources changed;
- INVALID — malformed/unauthorized/untraceable content prevents evaluation.

After owner ratification, WorkService may issue a separate positive-only current
readiness receipt stating `ELIGIBLE_FOR_PUBLICATION` for the exact ratified
contract under the frozen rule bundle and publication policy. This is a
governance result, not a claim that semantic-only clauses were formally proved.
Failed post-ratification revalidation creates a new assessment/state, not a
negative receipt. Keep semantic ratification and rule sufficiency as separate
receipts. Publication requires both; planner/Fleet eligibility additionally
requires the run to be `published` plus every policy-required formal property
to have a current ratification-bound result.

The pre-ratification assessment binds gaps/conflicts and its exact assessment
hash. The positive receipt must bind at minimum: work/intake revision, semantic
closure, contract and snapshot hashes, ontology/rule/engine versions, matching
assessment and owner-ratification receipt, satisfied rules, required formal
property/binding references, explicit semantic-only clauses, derivation hash,
result and issuance time. Successful publication
atomically binds that receipt into an `IntakePublicationReceipt` and the
`published` state.

MODEL AND AGENT BOUNDARIES

- `@intake` / Fable-high remains the owner-facing interviewer and primary
  semantic decomposer.
- A fresh K3 long-context agent may act as a read-only repository/spec scout,
  ambiguity detector or alternate formalization proposer for large or high-risk
  intake. It returns typed proposals and divergent interpretations only.
- Bounded intake exploration, when owner-authorized, uses fresh isolated
  generator/synthesizer/deepening roles through OMP's existing broker. Every
  output remains a model proposal. Web/CLI deterministically render the typed
  option set without reordering or another model call; Fable may explain it
  conversationally without changing it. Only the owner's exact confirmed
  answer enters `recordOwnerDecision`.
- K3 cannot ask in place of the owner-facing interviewer, admit claims, choose
  production rules, declare sufficiency or ratify meaning. Multi-model agreement
  is an ambiguity signal at most.
- The deterministic reasoner owns gap and pre-ratification assessment
  computation.
- The owner ratifies the semantic contract.
- The Sol planner consumes only a `published` run with a matching current
  positive receipt and ratified contract; it does not repair missing intake by
  assumption.
- The independent auditor later checks implementation semantics and evidence;
  it does not replace intake sufficiency.

No default or unbounded intake swarm is required. Use bounded exploration only
for a current eligible decision and only after explicit owner authorization;
promote routes, width and deepening only when `NSI-E4` demonstrates value.

REQUIRED PROGRAM CHILDREN

Publish one parent, the six required NSI children and—when the owner ratifies
the optional exploration scope—the four separately gated NSI-E children below,
unless the crosswalk proves an existing item should be linked. Do not flatten
the graph and do not make NSI-E a Fleet prerequisite.

NSI-1 — Ontology, intermediate representation and authority contracts

Extract the current taxonomy, entity/edge/constraint vocabulary, source
provenance, status model and lint invariants into versioned schemas and ADRs.
Define owner/repository/model/rule authority, unknown semantics, waiver policy,
semantic-only handling, ratification/readiness separation and the stable typed
contracts listed above. Preserve current UX through compatibility fixtures.

Acceptance includes schema fixtures, compatibility/upgrade tests, authority
matrix tests and proof that Markdown/model prose cannot become canonical state.

Depends on: SQL-0.

NSI-2 — Claim, evidence, decision and provenance ledger

Extend WorkService with immutable/revisioned intake snapshots, entities, atomic
claims, exact evidence spans, claim-evidence links, owner decisions,
supersession, derivations, conflicts, questions, AC trace links, contracts and
receipts. Use relational authority with versioned typed values; do not create a
second graph database or give agents direct SQL.

Expose narrow typed operations with expected revision, idempotency, request
hash, actor authority, event journal and timeout reconciliation. Preserve the
owner's exact wording and artifact hashes. Add projections/renderers after the
canonical API.

Depends on: NSI-1.

NSI-3 — Code-owned reasoner and selective formal adapters

Move exactly-one, exclusivity, allowed-values, transitive closure, dangling
edges, applicability, conflicts, coverage and readiness from prompt self-lint
into deterministic versioned code. Produce reason IDs, input claim IDs,
derivation receipts, missing premises and conflicts.

Create a formal-adapter interface and one bounded qualification spike only if
the historical/adversarial corpus contains requirements that ordinary typed
rules cannot adequately check. Z3 is the first candidate for bounded hard
constraints. ASP and temporal/model-checking adapters remain disabled unless
their specific corpus and promotion gate justify them.

Acceptance includes property/metamorphic tests, unknown-vs-false behavior,
stale invalidation, deterministic replay, resource limits and no model-authored
production rule/solver execution.

Depends on: NSI-1.

NSI-4 — Gap-directed questioning and owner decision loop

Generate a typed question agenda by backward-chaining readiness premises,
removing tool-discoverable facts and ranking material owner decisions. Preserve
the visible scan and one-question `AskUserQuestion` UX. Every question carries
blocked premise/rule IDs, consequence, expected answer schema and evidence.

Fable renders concise neutral wording/options. Open-ended answers remain legal
when the domain is not closed. Ambiguous answers produce explicit alternative
interpretations and owner confirmation; they never become silent assumptions.
Budget exhaustion yields resumable `NEEDS_SPEC`, never false readiness.

Depends on: NSI-2 and NSI-3.

NSI-5 — Acceptance compilation, semantic ratification and readiness receipts

Draft acceptance criteria from admitted claims, then enforce traceability,
observable oracle, negative/boundary coverage, non-goal compatibility and
waiver rules. Present original/normalized meaning, assumptions, examples,
counterexamples, formalization scope and unresolved semantic-only clauses for
owner ratification of an exact hash.

WorkService recomputes a pre-ratification assessment, records owner ratification,
then may mint a separate positive-only readiness receipt. Implement the
authenticated `publishIntake` transition. Render Markdown from typed state.
Update `/plan`, `/summary`, `/done` and future Fleet eligibility seams to require
the `published` state plus matching current contract/receipts without
implementing the Fleet controller here.

Depends on: NSI-2 and NSI-3.

NSI-6 — Evaluation, shadow cutover and sole-path promotion

Build a frozen historical/adversarial corpus and compare:

- A: current intake;
- B: practitioner requirements-interviewer prompt/decision log;
- C: typed claims plus code-owned rules, no optional solver;
- D: C plus selectively qualified formal adapters.

Measure false-ready rate, critical omissions, acceptance-criterion coverage,
material and redundant questions, owner correction burden, plan deviations
caused by missed requirements, downstream audit findings attributable to
intake, key-question efficiency, tokens and elapsed time. Hold task/model
conditions constant before comparing model routes.

Seed omitted rollback, security and failure behavior; contradictory claims;
ambiguous scope; unreachable/vacuous constraints; stale sources; provenance
tampering; prompt injection; alternative interpretations; and false-positive
bait. Include paraphrase/reordering metamorphic cases.

Run current and revised intake in shadow, compare canonical projections and
exercise rollback. Promote the typed path only after zero false-ready outcomes
on the seeded critical-omission corpus, complete provenance for every premise
contributing to a `READY_FOR_RATIFICATION` assessment,
deterministic/fault/security gates and owner review. Calibrate all
other thresholds from the corpus rather than inventing them in intake.

After promotion, make the typed path the sole publication route and keep a
time-bounded renderer compatibility path only. Document rollback and version
migration.

Depends on: NSI-4 and NSI-5.

OPTIONAL BOUNDED INTAKE EXPLORATION EXTENSION

The following children implement `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`.
They do not alter the base `SQL-0 -> NSI-1..6 -> FLEET-1` sequence. Publish
them with the same parent when the owner ratifies this extension, but track and
promote them separately so ordinary intake and Fleet never wait for ideation.

NSI-E1 — Exploration contracts, policy and frame registry

Define the exact authority, target, offer, authorization, input-manifest,
policy/limits, frame registry/selection, durable run/attempt, candidate,
screening, synthesis, usage, separate decision-attribution and planning-artifact
contracts.
Every object is versioned and content-hashed. Exploration output is always a
model proposal; only the existing owner-decision mutation may introduce the
owner's exact confirmed answer.

Acceptance includes schema/canonicalization/currentness tests, deterministic
frame selection, hard maximums, no automatic usage-consuming run, compatibility fixtures
and proof that exploration artifacts cannot satisfy a premise, change intake
state or enter a planning contract except through the specified advisory seam.
If any prompt, frame, schema or substantial source is copied from the inspected
MIT-licensed upstream, CI also requires its full license notice, pinned source
commit and dependency/SBOM provenance before release.

Depends on: NSI-1, NSI-2 and NSI-3.

NSI-E2 — Bounded runner, deterministic screening and advisory synthesis

Compile one least-context, secret-scanned, content-addressed manifest for a
current target. Run fresh isolated tool-free branches through OMP's broker with
all-settled persistence, exact route/prompt/input hashes, reservations,
cancellation, retries, reconciliation and usage receipts. Apply code-owned
schema/reference/duplicate/hard-constraint screening before any model
comparison. The synthesizer receives the complete frozen manifest and every
valid branch artifact. Re-parse and re-screen synthesized options before they
can be selected. Deepening is a separately owner-authorized immutable child run
for one option, with its own route/egress/budget/usage/screening records.

Acceptance includes branch isolation, identical context except reviewed frame,
provider/parse/timeout/429/unknown-outcome faults, process death between every
stage, stale/fence rejection, no duplicate automatic model call, durable
`reconciling` then non-selectable `outcome_unknown` when provider reconciliation
is impossible, conservative maximum accounting, fresh warned authorization for
any replacement, late-result exclusion and
no ambient tool, filesystem, SQL, WorkService, GitHub or credential access.

Depends on: NSI-E1 and NSI-4.

NSI-E3 — Owner decision, CLI and generated Web contracts

Add `/intake --explore`, current-question `/explore`, status/cancel and the
post-publication approaches outcome, adapting syntax to current CLI
conventions. Show estimated time plus the exact currency, metered-quota or
fixed call/token/time limits before authorization; durable
phase/count progress; two to four neutral options; evidence/assumption status;
watch-outs; accessible full disclosure; and an exact-answer confirmation.
Partial, cancelled, failed, `outcome_unknown`, stale or unranked output is
view-only. **Use this
option**, **Combine options**, **Write my own answer**, **None of these fit**,
**Decide later** and separately authorized **Explore this option further** are
the consistent actions.

Acceptance proves that card selection alone changes nothing, only the confirmed
answer reaches `recordOwnerDecision`, unselected options do not become
non-goals, planning exploration stays outside the semantic closure, and mobile,
keyboard, screen-reader, reconnect and hostile-rendering cases work in generated
consumer fixtures. This `oh-my-pi` child owns server/CLI behavior and generated
contracts; the `omp-webui` OWEB-4 sub-lane owns the native local client, with
manual canary in NSI-E4 and normal activation after N4.

Depends on: NSI-E2 and NSI-5.

NSI-E4 — Exploration evaluation, offer-only shadow and opt-in promotion

Compare qualified intake alone, one-pass alternatives, equal-width unframed
branches, framed parallel generation plus the same synthesis route, prompt and
limits as the unframed arm, and separately
requested deepening on frozen eligible decisions and negative controls. Match
or report compute explicitly; use a pilot for tuning and a frozen holdout for
qualification.
Measure useful selected options, constraint violations, unsupported facts,
owner corrections/reversals, decision time, plan changes, rework, downstream
audit findings, duplicate/noisy branches, offer precision, tokens, actual cost,
latency, failures and cancellation. Regress the base false-ready and provenance
gates.

Promote `N4` only after zero authority, containment, secret/egress, currentness,
fencing, idempotency or limit-enforcement violations; zero critical conflicts
presented as compliant, exposed as selectable or admitted into owner/semantic
state; zero option submission after staleness; preregistered non-inferiority on
false-ready, critical omissions, provenance closure and owner-correction
burden; stable material benefit over X-A and an equal-compute control;
owner-confirmed currency/resource limit compliance; and proven rollback. Before
N4, live selector shadow is offer-only with no model call, provider egress or
resource use and canary runs are explicit local owner actions. N4 permits
contextual no-model-call offers and owner-confirmed local runs; remote use additionally
requires OWEB-7. It never permits automatic usage-consuming execution.

Depends on: NSI-E3 and NSI-6.

DEPENDENCY GRAPH

SQL-0 -> NSI-1
NSI-1 -> NSI-2, NSI-3
NSI-2 + NSI-3 -> NSI-4
NSI-2 + NSI-3 -> NSI-5
NSI-4 + NSI-5 -> NSI-6

NSI-1 + NSI-2 + NSI-3 -> NSI-E1
NSI-E1 + NSI-4 -> NSI-E2
NSI-E2 + NSI-5 -> NSI-E3
NSI-E3 + NSI-6 -> NSI-E4
NSI-E3 + OWEB-4 -> local Explore alternatives client fixtures
NSI-E4 + local client fixtures -> manual local exploration canary
NSI-E4 -> N4 owner-confirmed exploration
N4 + OWEB-4 local client -> normal local Explore alternatives
N4 + OWEB-7 -> remote Explore alternatives

The Autonomous Fleet Kernel may be published only after NSI-6 proves the
versioned `IntakeContract`, `IntakeReadinessAssessment`, `RatificationReceipt`,
`RatifiedFormalBinding`, positive `IntakeReadinessReceipt` and
`IntakePublicationReceipt` consumer contracts. Fleet execution remains disabled
until it requires a `published` run with a current owner-ratified contract, all
policy-required formal bindings, matching `ELIGIBLE_FOR_PUBLICATION` receipt and
current publication receipt.

The base Fleet program depends on NSI-6, not N4. A missing, disabled or failed
exploration extension cannot block ordinary intake publication, `/plan` or
Fleet. Remote **Explore alternatives** additionally requires OWEB-7 and N4.

MANDATORY ADVERSARIAL AND FAULT CASES

Include at minimum:

- repository/issue text instructing the model to mark itself ready, add a rule,
  waive owner approval, reveal a secret or mutate WorkService;
- fabricated owner quotes, shifted source spans and changed artifact hashes;
- model proposal mislabeled as owner statement or repository observation;
- omitted critical security, migration, rollback, data-loss or compatibility
  premise hidden behind a high completeness score;
- unknown treated as false; contradictory claims overwritten by last-write;
- duplicated questions, a question with no blocked premise and a
  repository-discoverable fact asked of the owner;
- non-exhaustive closed options, ambiguous free text and later owner correction;
- stale repository commit, work revision, ontology, rule bundle, compiler or
  contract reused after change;
- same idempotency key/different body, partial publication, timeout after
  success and replay;
- cyclic/transitive/dangling graph cases and cardinality/exclusivity conflicts;
- solver timeout, `unknown`, malformed output, resource exhaustion, incorrect
  profile selection, arbitrary generated solver code and unsat core that is not
  minimal;
- satisfiable but semantically wrong formalization; two models agreeing on the
  same wrong interpretation; round-trip agreement preserving drift;
- AC with no source claim, no oracle, tautology/vacuity, conflict with non-goal,
  or uncovered admitted behavior;
- Markdown edited to claim READY or ratified while typed state disagrees;
- question-budget exhaustion and session restart/resume;
- changed source after ratification and before `/plan` or fleet eligibility.
- exploration output claiming owner identity, admitting a claim, inventing a
  rule/waiver/receipt, declaring READY or attempting a lifecycle mutation;
- automatic anchor stripping, unrecorded/random frames, one branch seeing a
  sibling, or the synthesizer/deepener missing the frozen manifest;
- generated candidate IDs that are duplicate, missing, cross-run, unknown or
  forged; hard-constraint conflicts presented as compliant;
- model scores, consensus, novelty or a trap label affecting admission,
  readiness or automatic deletion;
- duplicate exploration starts, owner direct-answer races, stale question/gap/
  snapshot/policy/frame inputs, late results after cancel and one failed branch;
- provider timeout/429/refusal/malformed output/unknown outcome, synthesis
  failure, process restart, budget exhaustion and cancellation at every stage;
- secret/prompt-injection/hostile-rendering cases, raw reasoning exposure and
  cross-principal/repository exploration access.

EXPLICIT NON-GOALS

- no general knowledge-graph platform;
- no Neo4j, RDF, OWL or generic ontology server solely for the label;
- no trained differentiable-logic model;
- no universal theorem prover or one-shot natural-language-to-Z3/Lean/LTL
  authority;
- no PDDL/general planner for ordinary intake;
- no model-authored production ontology, rule bundle or runtime policy;
- no automatic conversion of confidence/model agreement into fact;
- no universal SMT/ASP/LTL pass on every issue;
- no single sufficiency score that overrides a critical gap;
- no default, recursive, self-authorizing or unbounded intake swarm and no
  second work ledger; bounded owner-confirmed exploration is the only exception;
- no standalone `adhd-agent`/Claude Agent SDK orchestration path, automatic
  requirement rewriting, raw chain-of-thought UI or usage-consuming auto-run;
- no claim that syntax, satisfiability, proof success, round-trip agreement or
  solver agreement proves owner-intent fidelity;
- no replacement of owner semantic ratification or independent implementation
  audit;
- no Fleet scheduler, GitHub broker, remote-control UI or autonomous backlog
  drain in this program.

PUBLICATION REQUIREMENTS

For the parent and every child publish:

- stable key/idempotency key, exact dependencies and repository ownership;
- problem, owner-ratified outcome, scope and non-goals;
- inputs/outputs with schema identities;
- acceptance criteria with stable IDs and deterministic evidence;
- authority/threat model and risk classification;
- migration/compatibility, rollout, rollback and observability;
- qualification corpus, tests and promotion/stop conditions;
- unresolved owner decisions and external prerequisites.

Return exact created IDs/edges plus a reconciliation table. On partial or
ambiguous publication, read WorkService by idempotency key before any retry.

END-OF-INTAKE OUTPUT

Return:

1. live repository/SQL-0/WorkService evidence;
2. present-state and reuse crosswalk against current `/intake`;
3. questions and owner answers;
4. ratified authority, ontology, solver and threat boundaries;
5. exact parent/child manifest and dependency DAG;
6. acceptance-criteria coverage and research-to-design disposition;
7. publication result or precise BLOCKED reason;
8. recommended first `/plan` target, which must be NSI-1.
```
