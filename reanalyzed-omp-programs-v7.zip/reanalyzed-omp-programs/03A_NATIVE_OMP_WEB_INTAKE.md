# Paste-ready intake: Native OMP Web

Run this in a fresh OMP session with current `theturtlecsz/oh-my-pi` and
`theturtlecsz/omp-webui` checkouts available. Coordinate the parent from
`oh-my-pi`; assign each child to the repository that owns its implementation.

This program promotes the existing WebUI into OMP's official browser client.
It does not replace SQL-0, the Neuro-Symbolic Intake Compiler, the Fleet Kernel
or Remote Fleet Manager. Do not hide it inside the active PostgreSQL migration.

Fixture-only product/design work in `omp-webui` may proceed beside SQL-0 if it
does not modify OMP core, WorkService, migration state or Fleet authority.
Core packaging and live integration begin only after `SQL-0: PROVEN`. Remote
typed intake requires `NSI-6: QUALIFIED_AND_CUT_OVER`; live Fleet pages require
the corresponding Fleet and WFM gates.
Optional remote **Explore alternatives** additionally requires the separately
qualified `N4: OWNER_CONFIRMED_EXPLORATION` gate. It is not part of base
OWEB-N1.

```text
/intake Existing plan/draft — program-level intake.

PROGRAM TITLE

Native OMP Web — official browser, restricted remote workbench and Fleet shell

CONTEXT AND LIVE REBASELINE

This intake concerns:

- https://github.com/theturtlecsz/oh-my-pi
- https://github.com/theturtlecsz/omp-webui
- the proven PostgreSQL/WorkService foundation;
- the Neuro-Symbolic Intake Compiler and its typed contracts;
- the Autonomous Fleet Kernel; and
- the Remote Fleet Manager program.

Resolve and record before proposing work:

- exact HEAD, release and license of both repositories;
- current OMP CLI/TUI commands, session identity, persistence and RPC protocol;
- current omp-webui React/Bun/RPC/WebSocket/SQLite/JSONL implementation;
- worker supervision, event routing, replay, files, Git, tools, approvals,
  models/providers and optional PTY behavior;
- packaging, upgrade, cross-platform and test behavior;
- current remote authentication, authorization and listener behavior;
- live WorkService, NSI, Fleet and WFM contract versions; and
- related published WorkService items and idempotency keys.

Do not assume this prompt is current. Inspect source, documentation, tests,
releases and effective configuration. Classify each required capability as
PRESENT_AND_PROVEN, PRESENT_NOT_PROVEN, MISSING or NOT_APPLICABLE.

Treat Kimi Code Web, Orca and Agent Orchestrator as interaction references,
not dependencies or correctness authorities. Inventory public patterns worth
reimplementing. Do not copy proprietary or source-unavailable bundles,
branding, icons, assets or text. Reuse or repair existing omp-webui code before
proposing replacement.

Run a capability crosswalk, user-journey and information-architecture pass,
distribution pass, local/remote threat model, session/recovery pass,
mobile/accessibility pass, authority/ownership pass and Socratic pass. Ask only
questions that change product behavior, authority, security, compatibility,
deployment, data loss or scope.

Do not implement or publish automatically. After owner ratification, publish
one parent and the dependency-linked children below through WorkService using
stable idempotency keys. Reuse or link existing work instead of duplicating it.
If WorkService publication is unavailable, do not fall back to Linear or a
WebUI database; emit a deterministic publication-ready manifest and stop.

OWNER-RATIFIED OUTCOME

Make omp-webui the official browser experience for OMP. A normal user installs
OMP once and can:

- run `omp web` to start the matching browser application;
- run `/web` in a live terminal session to open that exact session;
- use the same workspaces, sessions, history, models and settings;
- close/reopen the browser without silently stopping the OMP session;
- use a polished conversation, tool, diff and background-work experience;
- securely check work and answer bounded questions from a phone or browser;
- receive a concise Needs You notification only when input is required;
- after NSI qualification, create and ratify typed intake work remotely;
- for a current consequential intake question, optionally authorize a bounded
  exploration, leave/reconnect, compare a few neutral alternatives and confirm
  the exact answer that enters ordinary intake; and
- after Fleet qualification, use the same visual shell to monitor and control
  Fleet through its separate security boundary.

The user does not clone, install, launch or version-match a second product.
`omp-webui` may remain a separate source repository, but each OMP release pins,
bundles, tests and supports exactly one compatible Web build.

“Native” is an installation, command, session and release contract. It does not
mean running the model loop in React, combining every process, sharing every
credential or weakening trust boundaries.

PRODUCT AND TRUST SURFACES

Present one coherent OMP product while mechanically separating four surfaces.

1. LOCAL OMP WEB — LOCAL_OWNER
   - Starts through `omp web` and binds to loopback by default.
   - Uses canonical OMP session identity and the current OS-user trust model.
   - Preserves the useful local chat, tool, file, diff, Git, model/provider,
     approval and optional PTY capabilities allowed by OMP policy.
   - Keeps one OMP RPC subprocess per interactive session unless live evidence
     proves a stronger compatible boundary.
   - Treats WebUI SQLite/search/replay state as derived and rebuildable.

2. REMOTE OMP WORKBENCH — REMOTE_RESTRICTED
   - Uses a separate remote gateway, listener, route registry and origin.
   - Starts disabled and is private-network-first.
   - Initially exposes sanitized session status/transcript, Needs You,
     notifications, exact-question replies and safe cancel/pause.
   - Does not expose raw OMP RPC, general PTY, arbitrary files/Git operations,
     provider credentials, account switching or browser-supplied tool results.
   - Treats generic remote prompting as a later, separately qualified high-risk
     capability with an explicit control lease and server-enforced tool policy.

3. WORK/INTAKE — WORK_OWNER
   - Uses a separate least-privileged Work/Intake BFF, route registry and origin.
   - Reuses reviewed identity/session UI components but not Remote Workbench
     service credentials or privileged session routes.
   - Reaches WorkService only through generated NSI contracts for collecting
     drafts, evidence projections, exact questions, ratification and publish.
   - After N4, may use generated exploration contracts for offer, authorize,
     status, cancel, optional deepen, sanitized results and exact-answer
     confirmation. It neither runs branches nor holds provider credentials.
   - Cannot reach local OMP RPC, session caches, Fleet control or GitHub.
   - Is disabled until `NSI-6: QUALIFIED_AND_CUT_OVER`.

4. REMOTE FLEET MANAGER — FLEET_SUPERVISORY
   - Uses the separately specified Fleet gateway/BFF and Fleet origin.
   - Reads and commands WorkService only through generated typed contracts.
   - Never reaches local OMP RPC, WebUI SQLite, local files/worktrees, provider
     credentials or GitHub credentials.
   - Remains an optional consumer: Fleet continues safely when all Web
     processes are stopped, upgrading, disconnected or compromised.

The surfaces may share reviewed React components, design tokens, generated
schemas, SSO primitives and navigation. They must not share bearer credentials,
service identities, privileged route registries, database handles, authority
modules or implicit capability.
Server policy authorizes every action; hiding or showing a control is not
enforcement.

OFFICIAL DISTRIBUTION AND COMMANDS

Provide these stable outcomes, adapting syntax only to live CLI conventions:

- `omp web`: start the matching local service, wait for machine-readable
  readiness, open the browser unless `--no-open`, and bind loopback by default.
- `omp web --session <id>`: open/resume the exact permitted session; never
  silently create a similarly named replacement.
- `/web`: create a short-lived one-time loopback handoff to the exact live
  session without placing durable credentials in a URL or log.
- `omp web status`: report build identity, compatibility, listener, trust mode,
  readiness and actionable failures without secrets.
- `omp web stop`: stop the Web service according to explicit session policy;
  never claim an in-flight action was cancelled without terminal evidence.
- `omp web remote enable|disable|status`: manage only the restricted gateway;
  never turn the full local daemon into a public listener.

Every OMP release includes an immutable matching bundle or reproducible pinned
artifact and a manifest equivalent to:

interface OmpWebBundleManifest {
  schemaVersion: string;
  ompVersion: string;
  ompCommit: string;
  webVersion: string;
  webCommit: string;
  rpcProtocolMin: string;
  rpcProtocolMax: string;
  browserProtocolVersion: string;
  featureSetHash: string;
  assetTreeHash: string;
  builtAt: string;
}

Negotiate protocols and capabilities explicitly. Unknown or incompatible
versions fail with an actionable message; they do not silently omit controls or
reinterpret fields. Require a reproducible build, lockfile, asset checksums,
SBOM, cross-version CI and coordinated release manifest. Repository merger is
not an acceptance criterion.

SESSION AUTHORITY, ISOLATION AND HANDOFF

- OMP session state/history is authoritative for local interactive Chat.
- WorkService is authoritative for Work, NSI and Fleet state.
- WebUI caches/indexes are derived; no browser/model narration can mint
  completion, permission, readiness, verification or publication.
- Every event carries exact session identity, schema version, correlation ID
  and monotonic cursor or equivalent replay identity.
- Prove session A prompts, events, approvals and tool results cannot reach
  session B; eliminate global event broadcasting.
- Browser disconnect does not stop a worker. Process death records an honest
  terminal state; unknown side effects are reconciled before retry.
- Resume uses only supported OMP session and model-history policy. Web handoff
  cannot bypass fresh-only/no-resume/no-compaction rules for Fleet K3 stages.

Represent at least STARTING, RUNNING, AWAITING_USER, IDLE, CANCELLING, DONE,
FAILED, EXITED and UNVERIFIABLE. A missed heartbeat is not success.

Only one surface holds an interactive driver lease unless multi-controller
behavior is separately proven:

interface SessionControlLease {
  sessionId: string;
  leaseId: string;
  holderId: string;
  surface: "TERMINAL" | "LOCAL_WEB" | "REMOTE_WEB";
  acquiredAt: string;
  expiresAt: string;
  sessionRevision: number;
}

`/web` states whether terminal control transfers or remains a viewer. Take-back
is explicit. Stale clients and leases cannot prompt, answer, approve or cancel.

LOCAL USER EXPERIENCE

Use the existing React application. Reimplement the best Kimi-like patterns in
OMP's own design:

- Open, Needs You, Done and Workspaces navigation;
- global session/workspace search;
- primary conversation and background-work panels;
- bounded tool, diff, file, plan, approval and terminal-output cards;
- explicit running, retrying, cancelled, failed, disconnected and stale states;
- safe resume only when the backend declares it legal;
- model, effort and permission visibility;
- supported file/folder/skill mentions and fork/archive/rename behavior;
- direct access to current changes and review; and
- responsive mobile, keyboard, touch and screen-reader behavior.

The first screen answers: what is running, what needs me, what finished or
failed, and which workspace/session can I continue? Do not require a solo user
to understand graph epochs, leases, cursors or receipt jargon in normal use.

ATTENTION AND BOUNDED REMOTE ACTIONS

Create a durable server-side projection, not a guess from model prose:

interface AttentionItem {
  schemaVersion: string;
  attentionId: string;
  sessionId: string;
  sessionRevision: number;
  type: "QUESTION" | "PERMISSION" | "AUTH_REQUIRED" | "CONFLICT" |
        "FAILED" | "COMPLETED" | "REVIEW_READY";
  summary: string;
  createdAt: string;
  expiresAt?: string;
  sourceEventId: string;
  allowedResponses: readonly AttentionResponseSpec[];
  status: "OPEN" | "ANSWERED" | "EXPIRED" | "INVALIDATED";
}

Every answer binds to the attention ID, session revision and source event.
Changed/expired items reject and reload. Initial private remote mutations are
an exact current answer, safe typed cancel, marking notification seen and a
qualified bounded approval. Raw shell/provider/credential/tool forwarding
remains local.

Notifications are optional and revocable per device, deduplicated by attention
identity, privacy-preserving on lock screens, authenticated on deep link, and
updated when answered/invalidated. Delivery never implies action completion.

REMOTE SECURITY AND DEPLOYMENT

The restricted gateway is disabled by default. Start with Tailscale/WireGuard,
an identity-aware proxy or equivalent private deployment. Use OIDC Authorization
Code + PKCE where applicable, server-side tokens/sessions, Secure HttpOnly
SameSite cookies, exact Host/Origin checks, CSRF on mutations, rotation and
revocation, service identity to the local bridge, resource/action capabilities,
rate/body/stream limits, restrictive browser headers and immutable
server-derived actor audit.

Enrollment is initiated on the trusted host with a short-lived challenge and a
revocable device grant. Never put access tokens in URLs or browser storage. The
browser cannot choose backend URL, host path, workspace root, provider endpoint
or credential.

Connect through a narrow authenticated projection/action contract. Never expose
the full local WebSocket protocol, raw RPC, worker environment, arbitrary file,
Chat SQLite, provider, generic Git, PTY or shell APIs. Treat transcript, tool,
Markdown, ANSI, diff, filename, link and artifacts as hostile input; sanitize,
bound and isolate rendering.

`REMOTE_CHAT_CONTROL` is separate from read, answer and cancel. If later
qualified it requires recent owner authentication, private deployment, current
driver lease, repository allowlist, visible worker/tool policy, immutable audit,
no approval escalation, exact revision binding and a local emergency revoke.
Public Internet exposure is a separate evidence/threat decision.

Expose non-secret readiness as a discriminated surface-specific document:

interface OmpWebReadinessBase {
  schemaVersion: string;
  state: "READY" | "DEGRADED" | "NOT_READY";
  webVersion: string;
  browserProtocolVersion: string;
  boundOrigin: string;
  advertisedOrigin?: string;
  featureSetHash: string;
  capabilities: readonly string[];
  reasons: readonly { code: string; summary: string }[];
}

type OmpWebReadiness =
  | (OmpWebReadinessBase & {
      trustMode: "LOCAL_OWNER" | "REMOTE_RESTRICTED";
      ompVersion: string;
      rpcProtocolVersion: string;
      runnerHostId: string;
    })
  | (OmpWebReadinessBase & {
      trustMode: "WORK_OWNER";
      workServiceApiVersion: string;
      nsiContractVersion: string;
    })
  | (OmpWebReadinessBase & {
      trustMode: "FLEET_SUPERVISORY";
      workServiceApiVersion: string;
      fleetContractVersion: string;
    });

Bound and advertised origins are distinct. A listening process is not
necessarily ready. Missing runtimes, invalid assets, unreachable identity or
unsupported versions produce stable failure codes.

REMOTE NEURO-SYMBOLIC INTAKE

Blocked until `SQL-0: PROVEN` and `NSI-6: QUALIFIED_AND_CUT_OVER`.

New Work runs through a separate least-privileged Work/Intake BFF—not the
Remote Session gateway and not the Fleet gateway. It selects an allowlisted
repository, records desired outcome plus
optional constraints/non-goals/evidence, creates a collecting IntakeDraft,
shows admitted investigation evidence, asks one code-selected gap question,
shows exact claims/decisions/unknowns/ACs/hash, obtains the owner's exact
ratification challenge, lets WorkService revalidate/mint readiness and then
requires explicit publication.

interface BeginIntakePayload {
  repositoryId: string;
  desiredOutcome: string;
  constraints?: readonly string[];
  nonGoals?: readonly string[];
  evidenceRefs?: readonly string[];
}

The browser/model cannot upload READY, ELIGIBLE_FOR_PUBLICATION, ratification or
publication truth. Every owner action binds to the current intake revision and
question/contract/receipt hash. The BFF uses a narrowly scoped WorkService
service identity and generated NSI client; it has no session/Fleet/GitHub
authority. This UI consumes NSI contracts; it does not recreate the ontology,
reasoner, ledger or publication transition.

Send `BeginIntakePayload` as the payload of the existing NSI
`MutationEnvelope`, which remains the sole location for `idempotencyKey`,
`canonicalRequestHash`, `expectedRevision` and payload. Authenticated principal,
capabilities and owner challenge come from server-controlled request/session
context, never the payload. Do not create a nested idempotency or actor field.

The Work/Intake BFF independently enforces exact Host and Origin, CSRF on every
mutation, opaque server-side sessions, rotation/revocation, rate/body/stream
limits, restrictive browser headers and immutable server-derived actor audit.
Ratification, waiver and publication require current revision/hash binding plus
recent-auth/step-up (WebAuthn or the deployment IdP's qualified equivalent).
Shared auth libraries do not imply shared cookies, service identity or route
authority with Remote Session or Fleet gateways.

OPTIONAL INTAKE EXPLORATION UX

This surface consumes `03B_BOUNDED_DIVERGENT_EXPLORATION_CONTRACT.md`; it does
not implement its own orchestrator. The normal direct-answer flow stays primary.
For a current code-selected eligible question, show a secondary **Explore
alternatives** action. Never auto-run a usage-consuming exploration; currency,
quota and resource-only subscription modes all require confirmation.

CLI outcomes, adapting spelling only to live command conventions:

- `/intake --explore ...` asks intake to offer exploration at the first
  qualifying question; it does not pre-authorize model calls;
- `/explore` targets the exact current question;
- `/explore status` shows durable progress and actual usage;
- `/explore cancel` requests safe cancellation; and
- `/explore approaches` is a later post-publication advisory handoff to
  `/plan`, excluded from intake contract/readiness hashes.

`/explore status` presents the same currently legal recovery actions as Web:
**Keep waiting** while reconciliation can still progress, or **Authorize a
replacement call** after an unknown outcome. The latter only opens a fresh
offer/limits confirmation; it is never a one-click retry.

If no current question/route is eligible, CLI and Web say `No eligible open
intake decision right now`, add one deterministic reason/current question when
safe, make no model call and leave the direct-answer path unchanged—for example,
`This is a repository fact; OMP will inspect the code instead.` `/intake
--explore` continues normal intake if none appears. A hidden/disabled button is
not the only explanation.

Before **Run exploration**, lead with estimated time, estimated cost and maximum
spend/usage. Put provider account/destination/region, sent data classes,
training use, cache mode/duration, retention duration, deletion support, route
identities, calls/tokens, frozen-source identity and budget source under
Details. State that this run compares N perspectives and
further detail is not included or automatic. A usage-billed canary requires a
broker-enforced currency cap. For metered quota, show its maximum units plus
calls/tokens/time. For a resource-only subscription, say that dollar and quota
limits are unavailable and show fixed calls/tokens/time. Require confirmation in
all three modes. The
completed view shows actual provider-reported usage; cancellation cannot refund
completed or already accepted calls.

Progress is driven by typed backend state and counts, never a fake percentage:

| Internal state | User label |
| --- | --- |
| `queued` | Preparing |
| `diverging` | Exploring n of N perspectives |
| `screening` | Checking constraints |
| `synthesizing` | Comparing alternatives |
| `reconciling` | Checking provider result |
| `ready` | Alternatives ready |
| child `queued/running/reconciling` | Preparing detail / Adding detail / Checking provider result |
| `partial` | Incomplete exploration |
| `outcome_unknown` | Provider result unknown |
| `cancel_requested` | Stopping |
| `cancelled` | Exploration cancelled |
| `failed` | Exploration failed |
| `stale` | Outdated |
| `superseded` | No longer needed — answered directly |

The browser may leave and reconnect. Cancel remains visibly **Stopping** until
backend terminal evidence exists. A changed question, intake revision,
gap/evidence/snapshot, rules, policy or frame registry makes the run Outdated
and disables selection.

Every outcome updates the same question card and Needs You item; do not create a
second inbox item. Deduplicate notification by intake/question/run. Incomplete,
failed, cancelled, Provider result unknown and Outdated states show **Write my
own answer** and, when legal, **Run exploration again**. Every rerun fetches a
fresh current offer and requires new limits confirmation. Outdated names what
changed. While provider lookup remains possible, show **Keep waiting**. If it
cannot be resolved, separate known provider-reported usage from a mode-specific
warning: count up to `$Z` against a currency limit, count up to `Q units`
against a metered-quota limit, or keep the authorized `N calls / M tokens / T
minutes` encumbered for resource-only subscription use. The resource-only view
also warns that replacement may duplicate subscription usage. **Authorize a
replacement call** requires a fresh offer and the matching duplicate currency,
quota or subscription-use warning. No option from an unresolved invocation is
selectable.

For an owner decision, show two to four neutral options with tradeoffs, risks,
evidence/assumption status and watch-outs. Do not lead with a starred winner or
display numeric confidence. Optional advisory analysis may be expanded only
after the alternatives are visible. Preserve **Use this option**, **Combine
options**, **Write my own answer**, **None of these fit**, **Decide later** and
the separately authorized **Explore this option further**. The full branch set is a collapsed, accessible list
grouped by perspective—not a mandatory graph canvas—and contains concise
artifacts, never raw prompts, private reasoning or provider traces.

Using, combining or writing opens an exact-answer preview. Only explicit confirmation
submits the normal revision-bound `recordOwnerDecision`; option selection alone
changes nothing and does not admit model rationale. Unselected options do not
become rejected claims or non-goals. Partial, cancelled, synthesis-failed and
unranked results are visibly incomplete and view-only; the owner can still
answer the original question directly.

**None of these fit** returns to direct answer and creates no decision;
**Decide later** leaves the question blocked. If the owner answers while calls
are active, confirm `Answer now and stop exploration? Calls already sent may
still finish and consume money, quota or subscription usage.` Late results
never become selectable.

A complete post-publication planning exploration may show one clearly advisory
recommendation. It is stored outside semantic closure and is discarded when
the published contract/snapshot becomes stale.

Remote operations use only the `WORK_OWNER` BFF with owner scope, current
revision, CSRF, budget capability and generated contracts. The browser cannot
submit a raw exploration prompt, choose frames/models/providers/endpoints,
steer branches, approve tools or access files, shell, Git or credentials. The
BFF compiles no context and runs no model; server-side NSI services bind the
current target and broker the frozen manifest. A privacy-safe notification says
only “Exploration ready” and opens an authenticated Work/Intake deep link.

Cancel never requires step-up. Start and **Explore this option further** require
the owner capability and exact preview; recent authentication is required only
when session assurance is stale or the server budget/risk threshold requires
it. Option submission uses normal owner-decision authentication. Ratification
keeps its existing stronger step-up.

Do not overload Remote Session `AttentionItem` or Fleet commands. WorkService/
NSI owns an intake-inbox projection; the shared shell may merge its presentation
only. Fleet mode may deep-link to the exact Work/Intake item but cannot start,
cancel, deepen or submit an exploration-backed answer.

Mobile/accessibility requirements include stacked cards, at least 44-by-44
CSS-pixel targets,
safe-area and virtual-keyboard handling, keyboard-only operation, semantic
heading/disclosure lists, visible-text currency/resource-limit information, focus restoration,
focus to an error summary after failed confirmation, polite live-region phase
announcements, color-independent status, contrast and reduced motion. Announce
phase changes, not token streams.

FLEET SHELL INTEGRATION

OMP Web owns packaging, navigation, interactive Chat, restricted workbench and
shared presentation. WorkService/NSI owns work and readiness. The deterministic
controller owns execution. WFM owns Fleet BFF/projections/authorization/events.
The GitHub broker owns GitHub mutations.

After their producer gates, the same visual shell may show Chat, Work, Runs,
Needs You, Review and Settings. Fleet review feedback is candidate-bound:

interface SubmitReviewFeedbackRequest {
  workId: string;
  attemptId: string;
  candidateSha: string;
  diffHash: string;
  comments: readonly { path: string; line?: number; body: string }[];
}

interface ReviewFeedbackBatch extends SubmitReviewFeedbackRequest {
  feedbackId: string;
  authorId: string;
  createdAt: string;
  requestHash: string;
}

Accepted feedback creates a new repair attempt; any candidate mutation
invalidates prior verification/audit receipts. Preview artifacts are sanitized,
candidate-bound and isolated; they are review aids, not correctness proof.
The browser submits only `SubmitReviewFeedbackRequest` inside the existing
revision/idempotency operation envelope. The server derives `feedbackId`,
`authorId`, `createdAt` and `requestHash`; caller-supplied values are ignored or
rejected.

REQUIRED PROGRAM CHILDREN

OWEB-1 — Live rebaseline, product charter and trust model
- Exact architecture/capability/defect inventory and ownership map.
- Local Owner, Remote Restricted, Work Owner and Fleet Supervisory boundaries.
- Kimi/Orca/AO adopt/adapt/reject matrix; desktop/mobile journeys.
- Session authority, driver lease, recovery and staged rollout policy.

OWEB-2 — Official packaging, commands and compatibility
- `omp web`, `/web`, status/stop/remote commands and exact-session behavior.
- Immutable bundle manifest, reproducible build, checksums/SBOM and CI.
- Version/capability negotiation and machine readiness.
- Proof no separate WebUI install or manual version matching is required.
Depends on: `SQL-0: PROVEN` and OWEB-1.

OWEB-3 — Session isolation, replay and handoff
- Isolated workers, shared canonical IDs, per-session routing/cursors.
- Driver lease, exact `/web` handoff, reconnect, cancel and honest failure.
- Rebuildable caches and cross-session contamination tests.
Depends on: `SQL-0: PROVEN` and OWEB-1.

OWEB-4 — Kimi-inspired local experience
- Open/Needs You/Done/Workspaces, search, conversation/background panels.
- Rich bounded cards, diff/review, failure/retry and responsive accessibility.
- Preserve or improve every current qualified local omp-webui capability.
- The optional local **Explore alternatives** client is an independently
  releasable OWEB-4 sub-lane owned by `omp-webui`; it consumes generated NSI-E3
  contracts. NSI/WorkService owns offers/runs and OMP's broker owns dispatch.
  Manual local canary belongs to NSI-E4; ordinary local activation waits for
  N4. This sub-lane never delays base OWEB-4.
Depends on: OWEB-2 and OWEB-3.

OWEB-5 — Restricted Remote Workbench gateway and PWA
- Separate process/listener/origin, narrow IPC, identity/device enrollment.
- Private-network-first deployment, scoped capabilities and sanitized streams.
- Proof remote routes cannot reach local privileged routes.
Depends on: OWEB-1 and OWEB-3.

OWEB-6 — Needs You, notifications and bounded replies
- Typed AttentionItem lifecycle, privacy-preserving notifications/deep links.
- Exact revision-bound answer, safe cancel and qualified approval kinds.
- Optional generic remote prompting remains disabled until separate evidence.
Depends on: OWEB-3, OWEB-4 and OWEB-5.

OWEB-7 — Typed remote New Work and neuro-symbolic intake
- Collecting draft, questions, exact contract review, owner ratification,
  WorkService readiness and explicit publication using generated contracts.
- After N4, question-bound exploration offer, currency-or-resource preview and limits,
  owner authorization,
  phase/count progress, cancel/reconnect, neutral results, optional deepen and
  exact-answer confirmation using generated NSI-E contracts. The BFF/browser
  has no provider credential, raw prompt, frame/model picker or runner path.
- Partial/stale/failed/outcome-unknown exploration is view-only; unselected
  ideas never become requirements/non-goals; accessible mobile and privacy-safe
  notification/deep-link behavior is required.
- Separate least-privileged Work/Intake BFF, origin, service identity and route
  registry; it may reuse identity UI but never the Remote Session gateway.
- Host/Origin/CSRF, opaque sessions, rotation/revocation, limits, immutable
  actor audit and recent-auth/step-up for ratification/waiver/publication.
- Prove stale/forged authority and backend outage fail closed.
Depends on: SQL-0, NSI-6, OWEB-5 and OWEB-6.

OWEB-8 — Unified shell and Fleet Manager integration
- Common navigation with separate origins/credentials and WFM client.
- Exception board, read-only runs/evidence, candidate-bound review feedback.
- Typed controls only when matching WFM/Fleet handlers are qualified.
- Prove Web shutdown does not affect Fleet execution/recovery.
Depends on: OWEB-4; WFM-3/5 for fixtures; WFM-7/FLEET-8 for live read-only;
WFM-8/10/11 and FLEET-12 for corresponding controls.

OWEB-9 — Cross-platform hardening and release qualification
- Windows/macOS/Linux startup/upgrade/rollback.
- Version skew, crash/reconnect, backpressure/large content and hostile input.
- Remote revocation/outage, privacy, mobile, accessibility and runbooks.
- Prove CLI/TUI remains complete when Web is absent or disabled.
This is one umbrella item with independently closable local, private-remote,
Intake and Fleet lanes; an unavailable later backend cannot block a qualified
earlier local release.
Depends on: OWEB-4 for local; OWEB-5/6 for private remote; OWEB-7/8 for their
backend-specific qualifications.

DEPENDENCY AND PROMOTION GATES

SQL-0 + OWEB-1 -> OWEB-2, OWEB-3
OWEB-2 + OWEB-3 -> OWEB-4
OWEB-1 + OWEB-3 -> OWEB-5
OWEB-3 + OWEB-4 + OWEB-5 -> OWEB-6
SQL-0 + NSI-6 + OWEB-5 + OWEB-6 -> OWEB-7
NSI-E3 + OWEB-4 -> local Explore alternatives client fixtures
NSI-E4 + local client fixtures -> manual local exploration canary
N4 + OWEB-4 local client -> normal local Explore alternatives
N4 + OWEB-7 -> OWEB-7 Explore alternatives capability
OWEB-4 + WFM-3 + WFM-5 -> OWEB-8 fixtures
OWEB-8 + WFM-7 + FLEET-8 -> OWEB-8 live read-only Fleet
OWEB-8 + WFM-8/10/11 + FLEET-12 -> corresponding Fleet controls
OWEB-4 -> OWEB-9 local lane
OWEB-5 + OWEB-6 -> OWEB-9 private-remote lane
OWEB-7 -> OWEB-9 Intake lane
OWEB-8 -> OWEB-9 Fleet lane

The authority chain remains SQL-0 -> NSI-1..6 -> FLEET-1..15. OWEB is a
product-surface track and cannot bypass that chain.

Promote through:

1. OWEB-F0 fixture/development — no remote listener or WorkService mutation.
2. OWEB-L1 native local canary — loopback `omp web` and exact `/web` handoff.
3. OWEB-R1 private remote read-only — identity/revocation, no mutation.
4. OWEB-R2 private Needs You canary — exact reply, safe cancel, notifications.
5. OWEB-N1 remote intake canary — only after NSI-6; no direct eligibility.
   The optional Explore alternatives action remains disabled until N4.
6. OWEB-F1 live read-only Fleet — only after FLEET-8/WFM-7.
7. OWEB-F2 typed Fleet controls — only after matching handlers/qualification.
8. OWEB-P1 public exposure decision — separate evidence and threat review.

MANDATORY QUALIFICATION

Distribution/session:
- clean install, asset integrity and explicit version mismatch behavior;
- loopback default, exact `/web` session, driver-lease conflicts and staleness;
- disconnect, cancel, worker/daemon crash, unknown side effects and replay;
- duplicate/out-of-order/gap events and absolute cross-session isolation;
- cache deletion/rebuild without loss of OMP truth.

UX/accessibility:
- truthful Open/Needs You/Done state, exact resume and bounded large content;
- path/symlink/workspace boundaries;
- keyboard, screen reader, contrast, reduced motion, touch, safe area, virtual
  keyboard, reconnect and authenticated deep links.
- exploration currency-or-resource disclosure, no usage-consuming auto-run, exact phase/count
  progress, leave/reconnect, cancel while calls are in flight, partial/synthesis
  failure, Outdated state and selection disabled on any target revision drift;
- neutral options before any advisory analysis, exact-answer confirmation,
  Use this option/Combine options/Write my own answer/None of these fit/Decide
  later, no numeric confidence/raw reasoning and
  hostile content in options/watch-outs/full disclosure;

Remote security:
- remote gateway cannot reach file/Git/provider/PTY/raw-RPC routes;
- browser cannot choose backend/path/workspace;
- cross-principal/device/session/repository access attempts;
- Host/Origin/CSRF, fixation, rotation, theft and immediate revocation;
- stale/double/replayed attention answers and cancellation;
- remote generic prompt absent by default and unable to bypass tool policy;
- XSS/injection through Markdown, ANSI, diff, logs, filenames, links, HTML,
  SVG and artifacts; payload/render/decompression bombs;
- remote/identity/network outage never reports guessed success.

NSI/Fleet:
- Web draft is collecting, not eligible; model/browser cannot forge owner,
  ratification, readiness or publication;
- stale source/claim/ontology/rule/contract/receipt actions fail;
- WorkService outage cannot assert success;
- Work/Intake origin/service identity cannot call Remote Session, Fleet,
  GitHub or local privileged routes, and credentials do not bridge origins;
- missing/forged Host, Origin, CSRF, recent-auth/step-up, expected revision,
  contract hash or MutationEnvelope idempotency identity fails closed;
- review feedback rejects stale candidate SHA/diff and creates revalidation;
- forged/duplicate exploration start, preview/limit mismatch, budget exhaustion,
  late result, cross-principal start/read/cancel/deepen/select and direct-answer
  races fail closed; selection records only the confirmed owner answer;
- prove Work/Intake browser/BFF cannot send raw prompts, choose provider/frame,
  invoke model/tool runners or reach their credentials; Fleet/Remote Session
  origins cannot mutate exploration;
- Fleet origin cannot call Chat routes; Chat state cannot advance Fleet;
- controller continues/restarts with all Web processes terminated.

ROLLBACK AND OBSERVABILITY

Preserve CLI/TUI as a complete supported path. Keep the standalone development
workflow until bundled release and rollback are proven, but never require it of
normal users. Record version/readiness/failure, session lifecycle/reconnect,
attention/notification/answer latency and sanitized codes without collecting
raw prompts, secrets or source merely for analytics. A remote incident can
revoke devices and stop the restricted gateway without stopping loopback OMP or
Fleet. Preserve all v5 WorkService, NSI, Fleet and WFM receipts/contracts.

EXPLICIT NON-GOALS

- no copied Kimi branding, proprietary assets or unlicensed frontend bundle;
- no required repository merger and no browser-hosted agent/model loop;
- no second session/work source of truth and no WebUI SQLite authority;
- no replacement of PostgreSQL/WorkService, controller or GitHub broker;
- no shared service identity or privileged route registry across Remote Session,
  Work/Intake and Fleet gateways;
- no full local daemon/public listener, raw remote RPC, PTY, provider credential,
  arbitrary host-file/Git API or hidden-button authorization;
- no remote intake bypass of NSI and no Fleet command bypass of WFM/controller;
- no worker self-report, model voting or UI status as correctness evidence;
- no exploration option, score, consensus, watch-out or recommendation as owner
  intent, admitted evidence, readiness, proof, plan approval or Fleet command;
- no generic remote brainstorming shell, raw branch steering or private
  reasoning display;
- no weakening of SQL-0, NSI, Fleet evidence/audit/fencing/containment or exact-
  candidate gates.

END-OF-INTAKE OUTPUT

Return:
1. exact live repository/release/protocol baseline;
2. capability/reuse inventory and Kimi/Orca/AO disposition;
3. corrected process/authority diagram and user journeys;
4. material questions and owner answers;
5. ratified packaging, session, security and compatibility contracts;
6. parent/child manifest, repository owners and cross-program dependencies;
7. publication result or precise BLOCKED reason;
8. safe first implementation set;
9. first useful local target: bundled `omp web` plus exact `/web` handoff; and
10. first useful remote target: private read-only, one Needs You answer and safe
    cancel.
```
