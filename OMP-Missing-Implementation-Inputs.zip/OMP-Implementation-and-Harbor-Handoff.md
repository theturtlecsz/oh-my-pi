# OMP implementation continuation and Harbor evaluation handoff

Prepared September 6, 2026 for Chris Zimmerman's local implementation agent.

## 1. The assignment

Continue the existing OMP reliability and instruction work, and implement a small Harbor evaluation integration that exercises the real OMP workflow. Deliver reviewable code and executable evidence. Reuse the previous work; do not restart with another general architecture or instruction audit.

The intended architecture remains OMP plus its native extensions and PostgreSQL WorkService. Models interpret requests and propose changes. Deterministic code controls authorization, workflow transitions, evidence, and delivery. Harbor operates outside that production path, running controlled experiments against it.

The first useful outcome is a qualified local implementation and a working evaluation path with two real task fixtures. A full benchmark campaign, automatic production model switching, fleet expansion, and live deployment are later milestones.

This document is a handoff, not a claim that the new code or Harbor integration has already been implemented. The accompanying reliability patch is actual prior implementation. The bundled v2 instruction patches are earlier proposals requiring the corrections below.

### Working instructions

- Carry authorized implementation through relevant verification. Make routine reversible decisions and record consequential assumptions.
- Reuse authorization already present in the owner's session and Work Ledger. Do not repeatedly ask for permission to perform covered work. If publication or a contract change needs an additional approval, finish the unaffected local work and prepare the exact proposed change first.
- Work from a stable controller installation against an isolated development worktree. Preserve unrelated edits. Do not use the running controller's mutable checkout as the test sandbox.
- Follow the actual repository and local instruction hierarchy. Inspect applicable instructions outside Git as described below; absence from this bundle does not establish absence from the installation.
- Implement to observable contracts. A successful edit, rendered prompt, catalog match, or model saying PASS is not behavioral verification.
- Preserve Advisor, Task Observer, independent audit, grant limits, and required owner gates. This handoff does not propose removing them.
- If a skill or instruction blocks one action, identify its path and relevant rule, distinguish requirement from interpretation, and continue all unaffected authorized work.

## 2. What exists and what needs reconciliation

| Input | Verified identity or status | How to use it |
| --- | --- | --- |
| Remote OMP main | `9b4a0c2b7146fb739d8be2d04cd5736212bfd867`, checked September 6 | Re-read the current remote and local branch before implementation. |
| Historical source base | `ad580d7df10bb25937ed55a9a32674384a8ddfc7` | Base of the prior reliability implementation. |
| Prior reliability implementation | Commit `7311e035760cd9783d1da65f424fed85fe1756b1`, branch `codex/workflow-reliability-2026-09-05` | Included as a patch and Git bundle under `prior/workflow-reliability/`. Inspect and integrate any missing changes. |
| Remote change since that base | Comparison returned only `.github/workflows/ci.yml` | Preserve the newer package-version native download fix when reconciling the reliability patch's CI edits. Do not overwrite CI wholesale. |
| v2 instruction review | `prior/OMP-v2-implementation-brief.md` | Continue all specific corrections; the present handoff adds implementation sequencing and Harbor. |
| Original v2 patches | `prior/v2-patches/` | Historical candidate patches with bases and proposed outputs. Apply only after reconciling the corrections and current source. |
| Prior evaluation charter | `prior/OMP-Assumption-Validation-Plan.md` | Retain qualification controls and evidence standards. The initial experiment order is updated below to prioritize model routing. |
| Live local deployment and Work Ledger | Not accessible in this review | Establish effective installations, native issue revisions, approved scopes, and current grants locally. |

The reliability patch previously passed 310 TypeScript tests and 34 Python tests; 109 PostgreSQL cases were skipped. Its README contains exact historical checks and limitations. Those results are not evidence for a newly integrated candidate. No Harbor trials or current-model comparisons were run during preparation of this handoff.

Do not assume the prior commit is available remotely. Its original delivery records a GitHub write-permission failure; the included Git bundle preserves the commit independently. Check whether equivalent changes have subsequently landed. Import the bundle only into an isolated checkout and inspect the diff before applying it to the new base. Follow current commit/push authorization rather than executing historical README commands automatically.

The local v2 backlog evidence file contains summaries of earlier native reads, despite its `FULL` filename. It does not carry the current complete records or revision identifiers. Use its issue keys as retrieval leads, not as publication authority.

## 3. Where each part belongs

Here, “native extension” means an extension using OMP's TypeScript `ExtensionAPI`. It does not mean a Rust native addon.

| Responsibility | Existing implementation surface | Continuation decision |
| --- | --- | --- |
| Workflow entry and command/tool registration | `session-system/extensions/work-now.ts`, `session-system/extensions/workflow/host.ts` | Extend the existing native host. It already registers `/execute`, `/now`, `/done`, and the `work` tool. |
| Intake model selection | `session-system/extensions/model-bookends.ts` | Use native model APIs and configured role selectors. Remove obsolete family assumptions when implementing the updated routing policy. |
| Skills and instruction wording | `session-system/skills/`, `session-system/agents/`, core prompt templates | Keep behavioral guidance here; enforce state and permission requirements in code. |
| Role resolution and provider execution | `packages/coding-agent/src/config/`, `src/extensibility/extensions/model-api.ts`, `src/task/executor.ts` | Reuse configured roles, registry, authentication, and provider implementations. Do not build another model registry in Harbor. |
| Independent acceptance auditor | `session-system/extensions/workflow/auditor-runner.ts` | Keep the native `discoverAgents` → `getAgent` → `runSubprocess` path and actual output schema. |
| Durable workflow authority | `packages/work-client/`, `python/omp-work/src/omp_work/v1/` | WorkService owns grants, revisions, candidates, evidence, and completion. Close authority gaps here. |
| Session message delivery and recovery | `packages/coding-agent/src/session/agent-session.ts`, extension delivery APIs | Fix the host/core boundary where needed; prefer extending existing delivery semantics. |
| Test orchestration | Proposed `evals/harbor/` | Separate Python evaluation dependency and OMP adapter. Ordinary OMP startup must not need Harbor or Docker. |

OMP already supports custom configured roles. `intake`, `audit`, and `deep` do not need to be added as hardcoded built-in roles merely to assign models. The model query facade uses the same role resolver and match preferences as core. Preserve that convergence.

Harbor supports custom installed or external agents without a Harbor fork. Use that integration seam for OMP; keep all model calls inside OMP's existing provider path. [Harbor agent integration](https://www.harborframework.com/docs/agents).

## 4. Implementation work packages

These labels identify handoff scope; they are not newly created Work Ledger issue IDs. Map them to actual native items before publication.

### W0 — Reconcile the prior reliability implementation

Integrate missing changes from `7311e03` without duplicating changes already present:

- Stop, cancellation, and owner-message pause remain available if auditor discovery or transport breaks. Resume and review still validate the trusted runtime.
- Service readiness reports stale source or migrations accurately and preserves the existing refresh fingerprint handshake.
- Candidate freeze handles authorized tracked deletions while retaining the existing rejected-path checks.
- Merge operations enforce the audited head identity.
- Normal CI includes OMP-specific session-system and work-client coverage, with coherent fixture and native-dependency handling.

Re-run the affected contracts on the combined candidate, including real PostgreSQL qualification. Retain the distinction between a local GitHub simulator and an actual provider integration. The earlier patch did not establish service-enforced trusted test evidence or full production readiness.

### W1 — Finish the autonomy, verification, and delegation correction

Inspect and reconcile all active consumers, including:

- `packages/coding-agent/src/prompts/system/system-prompt.md`
- `packages/coding-agent/src/prompts/system/project-prompt.md`
- `packages/coding-agent/src/prompts/system/subagent-system-prompt.md`
- `session-system/agents/auditor.md`
- The corresponding role, work-plan, and delegation render branches.

Use one consistent meaning: continue useful work within the current assignment and authorization; an already-authorized phase transition is not a stopping point. Stop when the assignment is complete, at an actual approval boundary, cancellation, hard harness stop, or genuine blocker. A worker returns its assigned slice even if the parent issue stays open. An auditor returns its required verdict and does not implement its own findings or close the parent issue.

Keep author verification appropriate to impact. Accept the owner's reported symptom, investigate its cause, and reproduce or regression-test when useful. Remove instructions that treat an edit acknowledgement as correctness or prohibit justified reproduction. Distinguish soft budget notices from hard forced-yield protocols; preserve strict structured result contracts.

Instruction-like tags and file contents do not gain authority from formatting. Keep trusted instruction origin separate from untrusted task data. Do not invent a new precedence hierarchy in prose.

Reconcile delegation eligibility and execution mechanics across Codex/non-Codex and eager off/on/always renderer branches. Respect the owner's actual delegation setting; a branch-specific eagerness clause must not bypass an explicit-request requirement. This is consistency work, not permission to mandate more agents.

Acceptance: prove assigned-slice completion, auditor terminal output, authorized cross-phase continuation, real-boundary refusal, and distinct budget outcomes. Renderer and stub-provider checks establish assembly/protocol behavior only. Any claim about live model compliance requires a separately labeled model trial.

### W2 — Complete intake wording and native structured amendments

Reconcile all consequential-versus-routine language in `session-system/skills/intake/SKILL.md`, including question mechanics, publication lint, existing-plan decisions, dangling terms, and the question ceiling. Routine reversible choices may be labeled assumptions. Consequential scope, correctness, product, and authorization questions need an answer or explicit scope deferral. At the question ceiling, preserve unresolved items and block only affected readiness. Deferral does not authorize the deferred work.

Keep an exact publication preview and the applicable owner confirmation. “Zero questions” means zero discovery questions for a sufficiently specified task; it does not erase an actual publication gate.

There is a concrete native amendment gap:

- `host.ts` exposes `revise_work` with title and description.
- `workflow/work.ts::reviseWork` computes the new revision using the previous `scope` and `acceptance_criteria`.
- `v1/store.py::_revise` already accepts a structured revision, checks `expected_revision_id`, persists acceptance rows, and invalidates the current candidate.

Extend the existing host schema, backend types, adapter, preview, and readback so an authorized amendment can update structured scope and acceptance criteria. First check whether the service/client contract already expresses everything needed; avoid an unnecessary contract migration. Do not merely append new checkboxes to a description while leaving the authoritative fields stale.

Bind the preview to the revision actually reviewed. A later read of a newer revision must not silently rebase an old owner confirmation. On concurrent change, report a conflict and prepare the updated preview. Preserve revision invalidation and check downstream plan packet, sealed execution criteria, candidate, and grant behavior after an amendment. If an active grant is bound to the old revision, follow the existing replan/restart rules rather than silently expanding it.

Acceptance: an amended acceptance criterion becomes visible through native readback and the next valid plan/audit path; a stale preview cannot overwrite a concurrent change; unchanged fields are preserved; prior candidate/evidence cannot certify the new revision.

### W3 — Consolidate observations and instruction presentation

Apply the v2 corrections across `omp-AGENTS.md` and `task-observer/references/session-start.md`. An OPEN observation is evidence to assess. Its status alone does not establish a command rule or amend authorization. A standing constraint must identify its canonical source and approval provenance. Keep the narrow digest-read hook and defer the broader observation-to-policy machinery to its existing work item.

Keep `/execute`'s native independent-audit exception explicit. Do not turn bookend language into a prohibition on the audit already authorized by an execution grant. Preserve the current boundary for `@deep`: planning/adjudication uses outside execution remain valid; adding it inside a grant is a separate routing decision.

Use the supported OMP-scoped configuration to make Ponytail optional in normal owner-facing output. Preserve explicit opt-in. Do not edit installed plugin caches. Record cross-tool impact for Copilot/Cursor changes and preserve strict auditor/result schemas.

The earlier prompt probe stopped before `before_agent_start`. Capture an isolated dynamic before/after event if claiming the Ponytail interaction is verified. Do not describe base prompt assembly as proof of all dynamic instructions being present simultaneously.

### W4 — Make model routing coherent and measurable

Keep role responsibilities stable while model assignments remain configurable. The following is a provisional evaluation profile, not a production switch or a proven ranking:

| Role or function | Initial candidate | Policy |
| --- | --- | --- |
| `intake`, `plan` | Astra, high | Requirements and plans; use existing owner decisions. |
| `default`, `task` | Gemini 3.8 Flash, medium | Routine implementation and bounded subtasks. Verify both routes; changing `task` alone does not route the parent execution turn. |
| `slow` | Astra, high | Difficult implementation; use directly when the task warrants it, without requiring a failed Flash attempt. |
| `audit` | Fable 5.1, high where supported | Fresh-context review of the frozen candidate. Keep independent from its implementer. |
| `smol` | Flash 3.8, low where supported | Bounded discovery and inexpensive mechanical work. |
| `advisor` | Preserve baseline for the first worker comparison | Measure separately later; a Flash candidate is reasonable but not established here. |
| `deep`, `commit`, `tiny`, other specialized roles | Preserve existing qualified choices initially | No change merely to keep every model in use. |

Fable remains an implementation candidate. If it implements, select an independent reviewer such as Astra. This handoff treats independent context as mandatory and cross-family review as the preferred experimental policy; preserve any stricter current ratified requirement.

Implement phase routing in native code at actual launch/transition points, not through a prompt asking the model to switch itself. Reuse `ctx.models`, `pi.setModel`, effective settings, and the task executor. `model-bookends.ts` currently resolves `@intake` but pins high effort and retains Fable-specific comments; reconcile that policy deliberately. `prepareNativeAuditRunner` pre-resolves `@audit`, while the subprocess also receives `agent.model` and `modelRole: audit`; prove preflight and launch use the same effective route.

Keep Astra on the owner's intended OpenAI route. Do not add Zenmux or another gateway because fuzzy lookup selected an entry there. Validate exact provider/model identity after resolution, supported transport, tools, structured output, cancellation, and effort. Repair existing provider/catalog source mechanisms if required; do not hand-edit generated `models.json`. Provider model IDs and availability must be verified against the configured installation.

Record requested role/selector, resolved provider/model, requested and effective effort, launch result, fallback events, and provider-reported model when available. Mark unavailable serving identity explicitly. A nonempty credential is `credential_resolved`, not proof of entitlement or successful serving. A response's reported model is not necessarily an independently attested backend identity.

For a controlled model comparison, disable cross-model fallback in the isolated experiment profile or classify it as a distinct configuration result. Do not count an Astra fallback as Flash success. Production fallback policy remains a separate owner-configured decision.

Current vendor references for validating routes: [Astra](https://developers.openai.com/api/docs/models/gpt-6-astra), [Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/generate-content/latest-model), [Claude release notes](https://platform.claude.com/docs/en/release-notes/overview). These document models, not entitlement through the owner's particular OMP provider.

### W5 — Repair continuation acknowledgement and crash recovery

Source evidence at the inspected revision:

- `host.ts::deliverExecutionMessage` appends a pending outbox entry, calls fire-and-forget `pi.sendMessage(..., { deliverAs: "nextTurn", triggerTurn: true })`, then appends `delivered`.
- The `ExtensionAPI.sendMessage` return type is `void`.
- `AgentSession.#pendingNextTurnMessages` holds queued messages in memory.
- Startup recovery distinguishes pending entries and delivered reservation versions.

Therefore enqueue acknowledgement must not be treated as a durable or consumed continuation. Prove the exact lost-work window through a controlled crash before prescribing the final storage change.

OMP already exposes `pi.deliverMessage(...)`, implemented through `AgentSession.queueExtensionDelivery`, with a receipt after actual injection. Inspect and reuse this mechanism where appropriate. It does not automatically prove crash-safe persistence or completion of the resulting model turn. Also check that awaiting a receipt inside the current handler cannot deadlock the turn/yield boundary.

Required contract:

- Persist continuation intent before handing work to an asynchronous queue.
- Give intent a stable identity bound to the owning session, grant, item/revision, and reservation/version as appropriate.
- Define precisely what each acknowledgement proves: queued, durably injected, or consumed. Do not use one ambiguous `delivered` state for all three.
- Reconcile on restart against the existing WorkService grant and operation journal. Cancelled, terminal, expired, or superseded work cannot be revived by an old queue entry.
- Replaying the same intent cannot reserve another continuation or duplicate its externally visible effect. Do not promise global exactly-once model execution; use durable intent, deduplication, idempotent operations, and outcome reconciliation.
- Scope session switches and shutdown behavior explicitly. Preserve soft/hard stop behavior and keep owner stop/cancel usable during unrelated auditor failures.

Use the existing session journal and service ownership model; add a narrowly scoped persistence/API capability only if the current mechanisms cannot satisfy the contract. Do not introduce a second workflow scheduler in Harbor.

Acceptance: controlled crashes before enqueue, after enqueue/before durable injection, after injection/before acknowledgement, and after an external effect/before its receipt produce either correct recovery or an explicit actionable state without duplicate effects. Include an old continuation replayed after cancellation and a session switch during delivery.

### W6 — Enforce trustworthy verification and delivery at the service boundary

The existing native auditor and host merge check are valuable but do not alone prove that every service client must supply valid verification and delivery evidence. Trace both `_complete_work` and `_complete_execution_item` in `v1/store.py`, the shared `completion_blockers` logic in `v1/semantics.py`, relevant client commands, and the approved contract.

Define typed evidence for the actual runner identity, tested candidate/tree, work revision, check definition/version, result, and artifact references. Bind delivery to the audited candidate and intended target. Reject missing, stale, unrelated, incomplete, or merely self-asserted evidence through the same service boundary used by ordinary clients. Authentication of a caller alone does not make arbitrary PASS text trustworthy.

Prefer current contract fields and provenance facilities where adequate. If a contract/migration change is necessary, prepare the exact candidate, compatibility plan, approval digest procedure, and tests before the required owner approval. Do not manufacture contract approval files from chat authorization.

Harbor's final grade must remain independent of the candidate. It must not become an automatic operational audit receipt or grant approval. If a future trusted runner issues WorkService receipts, define and qualify that authority separately. Until then, label what is externally verified versus what the production service actually enforces.

Acceptance: bypassing the OMP UI through a normal authorized service client still cannot complete work with a fake test report, another candidate's evidence, an unmerged execution branch, or stale reviewed head. A valid, complete candidate can pass. Keep local Git qualification and actual GitHub delivery qualification distinct.

### W7 — Resolve the instruction-loader uncertainty narrowly

The v2 claim that normal startup drops all context/skills after five seconds was not established: SDK startup resolves several inputs before passing them to the prompt builder. Follow the actual `sdk.ts` → prompt builder call graph and inject a delay into the specific suspected loader. Identify what is awaited, omitted, retried, or warned.

Only implement degraded-instruction visibility or enforcement for a reproduced path. Separate required project/workflow inputs from optional presentation content. Restore the missing render probe source or replace it with a reproducible fixture. Respect relative import resolution when placing that fixture. A stub serialization probe and a live model response demonstrate different properties.

### W8 — Prepare a complete promotion and rollback result

Treat the CLI/core, native addon, deployed extensions/skills, project instructions, auditor, WorkService code, contract, and database migrations as separately identifiable parts of one qualified installation. `install.sh` alone does not install all core template changes. Its extension swap does not make the entire multi-file instruction installation atomic.

Inventory active reads: loaded modules may remain cached while hooks and skills resolve changed paths later. Prepare a controlled cutover with relevant work quiesced, explicit process restart/reload boundaries, protected unmanaged content, before/after manifests, and a tested rollback. Preserve applicable live-link/mapped-code checks. Do not assume starting a new conversation in an old process loads new extensions. Database rollback is not a source-directory switch.

This work package produces the candidate and promotion procedure; follow any existing authorization for actual deployment. No production cutover is performed by this handoff itself.

## 5. Harbor integration to implement

### H0 — Dependency boundary and experiment layout

Create an isolated evaluation package under `evals/harbor/` unless the current repository has a more appropriate existing evaluation location. Pin Harbor and its dependencies in that package. Pin the container backend/toolchain and record image digests. Keep the dependency out of normal OMP runtime imports and installation requirements.

Proposed files to implement, not existing runnable commands:

| Path | Purpose |
| --- | --- |
| `evals/harbor/pyproject.toml` and lockfile | Pinned evaluation dependencies and entry points. |
| `evals/harbor/src/omp_harbor/agent.py` | Harbor custom agent integration. |
| `evals/harbor/src/omp_harbor/rpc.py` | OMP process lifecycle and protocol driver. Reuse existing compatible clients where practical. |
| `evals/harbor/src/omp_harbor/report.py` | Run normalization, outcome classification, comparison reports. |
| `evals/harbor/tasks/` | Versioned task instructions, environments, reference solutions, and independent graders. |
| `evals/harbor/profiles/` | Explicit experiment overlays over the recorded OMP baseline. |
| `evals/harbor/tests/` | Adapter protocol, lifecycle, isolation, evidence, and control tests. |
| `docs/omp-harbor-evaluation.md` | Verified local commands, limitations, cost controls, and interpretation. |

Do not add an `/eval` command: OMP already has an unrelated code-evaluation tool surface. No new OMP command is needed for the first milestone. A later native extension may expose evaluation status/results if useful, delegating to the external runner and introducing no new workflow authority.

### H1 — Drive the actual OMP command path

Prefer the existing RPC mode for the first adapter. Relevant code: `docs/rpc.md`, `src/modes/rpc/rpc-mode.ts`, `rpc-types.ts`, and `AgentSession.prompt`. The protocol can submit prompts, inspect state/commands, abort, switch sessions, and receive streamed events. RPC setup provides extension UI interactions. Validate the exact capabilities and framing of the pinned OMP version rather than assuming line-oriented success responses mean a task is complete.

Adapter responsibilities:

1. Start the pinned candidate OMP installation with the recorded extensions, rules, skills, provider routes, and isolated persistent session storage. Use structured subprocess arguments, clean stdout protocol handling, separate stderr, and bounded lifecycle timeouts.
2. Check startup readiness, required command discovery, WorkService contract/readiness, and effective configuration before a live model request.
3. Submit the task through the normal command path appropriate to its scenario. Workflow trials use `/execute <fixture-key>`; manual bookend tests use their explicit owner-scripted command sequence. Do not replace this with a raw model prompt or a custom Python agent loop.
4. Treat a successful RPC command acknowledgement as request acceptance only. Track the resulting agent/extension events and authoritative workflow state until the scenario's terminal condition. Do not stop at the first `agent_end` when a continuation remains scheduled.
5. Poll through read-only protocol/service calls. Do not inject casual progress prompts: the workflow input hook can pause an active grant on an owner interjection. Repeatedly sending “continue” would alter the behavior being measured and conceal a broken execution loop.
6. Handle extension UI requests using the scenario's explicit answer/authorization script for disposable fixtures. Record every answer. Missing or unexpected interaction must block or fail visibly; never auto-approve everything. A scripted owner is a test fixture, not proof of human usability or permission for real owner actions.
7. Support cancellation, timeout, crash/restart with the same session identity, and cleanup of agent/subagent processes. Scope cleanup to this trial. Persist evidence before teardown.
8. Collect observable transcripts/tool events, model metadata, usage, candidate identity, and workflow events. Preserve raw observable events even if a normalized trajectory format is incomplete. Exclude private reasoning and hidden provider instructions.

Prove two parity cases through the normal interactive/extension or existing contract-test path and through the adapter. The same command should have the same authorization, model routing, state transitions, and result. If RPC cannot expose a required interaction, identify the precise missing capability and implement a narrow reusable fix; do not bypass the gate in the evaluator.

### H2 — Isolated WorkService and repeatable task fixtures

Each trial needs a clean repository baseline, unique work/session/grant namespace, fresh database and operation journals, fixture project marker, and controlled credentials. Reuse the bootstrap knowledge in `session-system/tests/execute-cycle-smoke.ts` and `python/omp-work/tests/pg_native.py`; those are starting points, not proof of full CLI workflow coverage. Existing smoke code sends several service operations directly.

The client in `workflow/config.ts` explicitly refuses non-loopback URLs. A naive Compose endpoint such as `http://work-service:8000` will fail. Preserve this production restriction. Qualify a local topology with a protected WorkService process/container reachable over the worker's loopback interface, for example a shared network namespace with separate filesystems. Validate that topology against the chosen Harbor Docker backend before relying on it. If necessary, use a test-only localhost transport bridge to the isolated service, without changing the production allowlist or turning the bridge into an authorization mechanism.

Keep PostgreSQL admin/migration credentials, capability administration, final grader code, and authoritative evidence files unavailable to the worker's filesystem. A shared network namespace must not imply shared writable service storage. Do not mount the Docker socket into the worker. Configure a supported nonroot PostgreSQL 18 environment and verify native dependencies.

Snapshot a representational, sanitized instruction environment rather than copying the owner's entire home directory. Include relevant home/ancestor/repository instructions, skills, extensions, dynamic hooks, role config, and tool settings. Record paths, resolved source identities, hashes, load order, scope, and observed activation. Keep credentials out of manifests. Distinguish configured, discovered, loaded, and observed behavior. The local agent must explicitly list anything it could not inspect.

For self-development tasks, identify three separate revisions: the OMP harness executing the task, the target repository the worker edits, and the trusted evaluator. Editing the target must not silently replace the controlling extension, service, or grader. Changing the controlling harness is an intentional experiment factor.

Keep expected solutions, private tests, previous trial outputs, and future solution commits outside worker-accessible history/remotes. Use local Git remotes and controlled provider fixtures initially. Actual GitHub delivery tests require a separately designated disposable target and authorized credentials.

### H3 — Independent verification and evidence completeness

Configure a separate verifier environment. Harbor's default shares the agent container. Its separate mode transfers declared artifacts; task authors supply the grading program. Use this to grade the candidate against an immutable baseline and independent checks. [Task/verifier documentation](https://www.harborframework.com/docs/tasks).

Capture service/database evidence through protected service-side collection before teardown. Harbor artifact collection is best-effort, and source-path collisions can skip artifacts. Our grader must explicitly reject missing required evidence and validate its expected origin. Use distinct paths for worker deliverables and trusted snapshots. [Artifact collection](https://www.harborframework.com/docs/run-jobs/results-and-artifacts).

Require the grader to check exact work/revision/candidate identities and independently observed effects. Worker logs and exported patches are untrusted inputs. Do not accept a worker-written reward file, rewritten tests, or a forged service dump. Apply submitted changes in a clean verifier checkout with declared path handling; verify deletions, renames, binary exclusions, and untracked additions as appropriate. Never execute an arbitrary worker-supplied verification script as the grading authority.

Classify missing evidence as an invalid or incomplete evaluation, with a reason, rather than success. Report infrastructure failures separately from task failures but retain both in attempt counts; a configuration-caused infrastructure failure counts against that configuration.

Validate every grader using a known correct result, an unchanged/broken result, and at least one relevant tampered or mismatched result. The purpose is to prove that the grader distinguishes outcomes before spending on model trials.

Harbor's configured network behavior must also be checked on the selected backend. Give task execution only the task's required provider/dependency access; keep grading access explicit. Record cleanup failures and retained trial resources. Do not assume a declared policy is enforced identically by every backend.

### H4 — First fixtures and invariant controls

Implement two fully qualified task fixtures first:

| Fixture | Agent assignment | External success evidence |
| --- | --- | --- |
| Structured acceptance amendment | Fix the description-only native amendment path so the approved acceptance change reaches structured state and the next valid planning path | Real service readback, stale-preview rejection, revision invalidation, and independent tests. |
| Durable execution continuation | Fix a seeded continuation acknowledgement/recovery bug | Controlled process termination at the reproduced boundary, resumed work, no duplicate effects, and correct terminal service state. |

A task asking the agent to repair a seeded bug and a test that injects a crash into an already-built harness are different experiments. Package both as needed, but label which is being scored. Do not attribute a harness defect to an implementation model.

Reuse existing deterministic regressions for the following controls. Add coverage only for missing observable contracts:

| Control | Required observation |
| --- | --- |
| Authorized tracked deletion | Candidate retains the deletion and passes the applicable freeze rules. |
| Audited head changes before merge | Delivery refuses without merging the unaudited candidate. |
| Receipt names another candidate/revision | Completion refuses with a stale/mismatched-evidence reason. |
| Caller submits PASS prose | It cannot replace required trusted runner evidence. |
| Branch pushed but delivery incomplete | Work remains incomplete. |
| Worker changes verifier or forges evidence export | External grading rejects the attempt. |
| Crash after an effect before acknowledgement | Recovery reconciles the same operation without duplicating the effect. |
| Old continuation after cancel/expiry | No new unauthorized effect starts. |
| Competing claims or repeated operation IDs | Real PostgreSQL transactions preserve ownership and idempotency. |
| Missing RPC approval interaction | No inferred approval; actionable blocked/error state. |
| Broken auditor during owner stop | Stop/cancel remains usable; resume/review still validates prerequisites. |
| Ordinary subtask or auditor finishes | It returns its required result while the parent issue may remain open. |

Critical failing controls block promotion and comparative model claims. Expected failures used to demonstrate a bug must be labeled as such; they do not qualify a release.

### H5 — Controlled model and workflow experiments

First establish one repaired baseline containing identical reliability fixes in every comparison arm. Freeze instructions, tools, environment, reviewer, budgets, and non-worker role assignments for a worker comparison. Record actual effective effort; the same effort name need not mean equivalent compute across providers.

There is a review-confounding issue if we compare Astra, Flash, and Fable while requiring a different-family auditor. Use paired comparisons:

- Pair A: Flash implementation versus Astra implementation, with the same Fable auditor and other roles fixed.
- Pair B: Flash implementation versus Fable implementation, with the same Astra auditor and other roles fixed.

Analyze each pair within its own setup. Do not combine them into a three-way model ranking as though the reviewer never changed. A separate implementation-only experiment with fixed external grading can compare all three, but it measures a narrower task than complete OMP delivery.

After worker comparisons, compare explicit routing policies: all-Astra implementation versus Flash for routine work with Astra for predefined difficult cases or escalation. Keep the initial task classification and escalation triggers reviewable; distinguish transport retries from capability escalation and genuine authorization blockers. A stronger model cannot repair an unavailable service or grant permission.

Then evaluate revised instructions against baseline instructions with the same model configuration. Optional narrator/Advisor/Observer ablations from the old charter remain later isolated experiments. They are not part of this first implementation or a reason to disable supervision now.

Use a small metered subset first, followed by representative tasks from actual OMP issues. The prior 12-task, three-repeat, two-arm proposal equals 72 runs for one comparison; it is a candidate development batch, not an executed or mandatory initial run count. Preserve any applicable v9.1 qualification gate separately. Hold out tasks for final qualification; once a task informs tuning, move it into development/regression.

No paid experiment starts without an explicit total budget and per-trial time/usage limits under the owner's existing authorization. If no budget exists, complete the adapter, local fixtures, deterministic/stub checks, exact live-run plan, and cost estimate first. Do not invent a dollar cap or silently execute the whole matrix. Limit concurrency during the initial metered subset.

Report quality by task family, then latency, total cost, and human effort. Include failed attempts, retries, planning, Advisor, audit, escalation, and sandbox usage in cost per accepted outcome. Preserve autonomous success, rescued success, correct refusal, ordinary incompletion, incorrect completion, and infrastructure failure as distinct outcomes. If all attempts fail, cost per success is undefined, not zero. Avoid treating repeated runs of the same task as independent evidence of general coding capability.

## 6. Sequencing and completion gates

| Milestone | Deliverable | Exit condition |
| --- | --- | --- |
| M0: establish the candidate | Current source/deployment map, existing-issue mapping, reconciled W0 patch | No ambiguity about controlling code versus edited code; existing changes preserved. |
| M1: finish local corrections | W1–W5 changes, targeted W7 result, and native amendment support | Relevant observable contracts pass; unresolved service/contract work is explicitly tracked. |
| M2: executable evaluation path | H0–H3 integration plus H4's two task fixtures and grader controls | Known-good/bad controls and actual OMP RPC workflow pass locally without real model spending. Stub execution is labeled; remaining H4 invariant controls have explicit M3 ownership. |
| M3: authority and recovery qualification | W6 and remaining H4 critical controls through real PostgreSQL | Direct clients cannot bypass completion evidence; crash recovery and control paths pass. |
| M4: bounded model pilot | Qualified routes and approved metered experiment | Report per-task results and limits; no unsupported “optimal” assignment claim. |
| M5: promotion | W8 candidate manifest, required gates, canary, rollback | Apply the actual owner-approved deployment procedure; no skipped critical checks represented as passes. |

M2 preparation can proceed while a consequential contract decision in M3 waits. Do not block all authorized local implementation on a later live-run or deployment approval. Conversely, a mock-only M2 run does not establish production readiness.

M0's identity and ledger mapping can finish before W0, but the full M0 exit remains partial until the prior reliability implementation is reconciled. Distinguish Harbor section H5 (model/workflow experiments) from the existing ledger's OMP-202/H5 (observation-to-policy work). Deferring the latter does not remove the former's experiment preparation and reporting scope.

## 7. Verification commands and evidence

Resolve current package scripts and prerequisites before running. These commands exist in the inspected reliability candidate:

```sh
bun test session-system/tests packages/work-client
bun test scripts/ci-test-ts.test.ts
bun check
uv run --project python/omp-work --extra dev pytest python/omp-work/tests
bun run test:py:work-ledger:integration
bun run test:session:smoke
OMP_WORK_POSTGRES_INTEGRATION=1 bun run session-system/tests/execute-cycle-smoke.ts
```

Run focused subsets during implementation and the required candidate gates before promotion. Follow the repository's current compiler/native test conventions, avoiding source-text tests and global mocking that contaminates other suites. Record test counts, skips, exit codes, environment, and logs. A script that exits zero because its opt-in integration variable is absent is skipped, not verified.

The local agent must provide exact working Harbor install, validation, local-control, single-task, and metered-comparison commands after pinning and testing the integration. This handoff intentionally does not present an unimplemented adapter module or assumed Harbor flags as a runnable command.

## 8. Native issue amendments

Read complete current native Work Ledger records and revisions before preparing changes. Preserve approved acceptance criteria and relationships. Use exact IDs; do not create duplicate issues from title matches or use GitHub Issues as a substitute.

| Existing lead from the audit | Candidate scope to reconcile |
| --- | --- |
| OMP-241 | Replace stale model-specific wording with configurable phase routing and current candidate profiles; add effective-route evidence and comparison criteria. |
| OMP-211 | Auditor preflight/launch parity, actual schema/transport qualification, and requested/resolved/launched/fallback metadata. |
| OMP-234 and related OMP-233/235/236/239/240 | Re-read each; map pause/stop/resume/continuation fixes only where its actual scope matches. |
| OMP-202/H5 | Retain observation-to-policy promotion scope there; keep interim wording corrections distinct. |
| Existing reliability and deployment items | Map W0, W6, and W8 after checking the full ledger. |
| Harbor integration and model evaluations | Amend an existing evaluation item if one exists; otherwise prepare a scoped new item with dependencies and the M2/M3/M4 split. |

The structured amendment correction is an enabling dependency if the available native edit tool cannot update authoritative scope/criteria. In that case prepare previews now, implement W2, and publish through the corrected authorized path. Do not claim to have amended an issue until native readback confirms the exact structured revision.

## 9. Report back to Chris and the reviewing assistant

Provide the implementation work product and evidence, with the following concise summary:

1. **Result:** implemented, partially implemented, or blocked, with the completed milestone(s).
2. **Source identity:** base/head/diff, branch or patch, dirty-state treatment, controlling installation, extension/skill/project context revisions, service/contract/native versions. Separate observed running identity from intended configuration.
3. **Changes:** work-package labels mapped to actual issue IDs and source paths. For each of the eight original v2 patches, report retained, corrected, superseded, or deferred with a reason.
4. **Actual checks:** command, environment, count, result, skips, and evidence file. Keep historical results separate. Include the fail-before/pass-after evidence for reproduced bugs where feasible.
5. **Harbor state:** pinned version/backend; implemented adapter entrypoint; the two task IDs; parity results; known-good/bad grader results; required artifact completeness; exact reproduction commands.
6. **Model routes:** requested/resolved/launched/provider-reported identities, effective effort, fallback, and whether only a credential-presence check, stub call, or real call was performed.
7. **Issue readback:** actual revision and structured scope/criteria if published; otherwise the exact staged preview and the gate still needed.
8. **Remaining uncertainty:** missing global instructions, untested provider/OS/network paths, unsupported UI interactions, service authority gaps, or unknown effect outcomes. State concrete impact and next resolving action.
9. **Promotion:** reviewed candidate manifest, remaining gates, expected restart/cutover behavior, and rollback status.

Attach a reviewable diff/branch or patch bundle and the minimum evidence required to reproduce the result. Do not attach raw credentials, private reasoning, or a wholesale home directory. Do not substitute another broad audit ZIP for implementation. A compact implementation/evaluation evidence bundle is appropriate.

For each trial, retain a machine-readable record with task/run/config IDs; pinned source and instruction identities; model/role/effort/fallback data; session/grant/work/revision/candidate IDs; independently graded acceptance outcomes; trusted artifact origins and hashes; usage, wall time and intervention data; failure classification; required skips; and cleanup outcome. Use null with a reason for unknown facts.

For behavior we could not observe remotely, send the smallest decisive evidence: the complete relevant local instruction clause and activation source, a sanitized effective-config delta, an actual state/receipt readback, or a minimal failure transcript and reproduction. Distinguish a source-code inference from a reproduced failure and from live deployment confirmation.

## 10. Paste into the local agent

```text
Continue the OMP implementation using OMP-Implementation-and-Harbor-Handoff.md and its accompanying inputs. This is an implementation task, not another general audit.

Reconcile the included reliability patch and corrected v2 brief against our actual checkout, native Work Ledger issues, and effective local instructions. Reuse work already completed. Implement the remaining native OMP/core/WorkService corrections and the external Harbor adapter with two qualified task fixtures, following the milestone boundaries in the handoff.

Preserve existing authorization and approval requirements; continue all covered local work without repeatedly asking. Keep the controlling installation isolated from the candidate. Prepare structured native issue amendments and publish only through the applicable authorized revision path. Finish the code, local verification, run plan, and deployment preparation before asking for any genuinely missing budget or promotion approval.

Use current model routes through OMP's native resolver. Treat Astra, Fable 5.1, and Gemini Flash 3.8 as candidates to evaluate, not a fixed ranking. Preserve independent auditing and existing Advisor/Observer behavior for the baseline.

Return the implementation diff/branch, actual verification and Harbor results, issue readbacks or exact previews, and the report requested in section 9. Identify any local instruction, runtime, or service state unavailable to the remote reviewer. Clearly label unimplemented, stubbed, skipped, and unverified work.
```
