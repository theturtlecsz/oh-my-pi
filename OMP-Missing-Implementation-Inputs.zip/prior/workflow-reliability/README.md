# OMP workflow reliability patch — September 5, 2026

Repository: https://github.com/theturtlecsz/oh-my-pi

Base: `ad580d7df10bb25937ed55a9a32674384a8ddfc7`

Local commit: `7311e035760cd9783d1da65f424fed85fe1756b1`

Local branch: `codex/workflow-reliability-2026-09-05`

The GitHub connector rejected creation of the commit tree with HTTP 403,
`Resource not accessible by integration`. No remote branch, commit, or PR was
created by this work. The patch and Git bundle preserve the completed changes.
GitHub Plugin Management confirms the plugin is installed; its permission tools
control ChatGPT approval behavior, not GitHub repository/OAuth write scopes.

## Changes

- Pause, cancel, and stop remain available when auditor discovery/loading fails.
  Resume and review retain trusted-runtime validation.
- WorkService readiness reports stale source or migrations rather than claiming
  it is ready while normal writes are refused. Existing refresh fingerprint
  semantics remain unchanged.
- Execution freeze accepts legitimate tracked deletions while retaining secret,
  binary, and unreadable-path rejection.
- Delivery merges require the audited head SHA using GitHub CLI's
  [documented expected-head option](https://cli.github.com/manual/gh_pr_merge).
- Execution lint guidance matches the freeze gate's handling of excluded files.
- Normal test dispatch includes session-system and work-client. Auditor fixtures
  and PID namespace assertions are repaired. CI runs Work Ledger unit tests,
  retains native artifacts seven days, and requires PostgreSQL integration
  before release.
- A production-readiness runbook explains stable runtime versus development
  worktree boundaries and remaining qualification work.

## Actual verification

| Check | Result |
| --- | --- |
| Session-system + work-client + CI dispatcher tests | 310 passed, 0 failed; 1,536 assertions across 24 files |
| Work Ledger Python tests | 34 passed, 109 PostgreSQL cases skipped |
| `bun check` | Passed; Rust check skipped by repository change detector |
| Session extension type check | Passed using repository tsgo |
| New halt-test dependency graph type check | Passed |
| Whitespace and bundle verification | Passed |

New halt regressions reproduced three failures before the fix; afterward all
four cases passed, including refusal to resume with a broken auditor. Git tests
use real temporary repositories and a local-only GitHub simulator: they prove
the helper sends its expected-head condition and a modeled head race leaves the
local default branch unchanged. They do not establish a live GitHub merge.
Readiness tests exercise the real HTTP routes with controlled runtime edits and
database health, without PostgreSQL.

The final combined test invocation supplied Bun on PATH. An initial combined run
omitted it and failed the test that spawns `bun`; the corrected run passed all
310 cases. No production code was changed for that environment issue.

Runtime: Bun 1.4.0, Python 3.12.13, pinned published pi-natives Linux x64 18.0.6
addon. The fork's Rust sources were not rebuilt. PostgreSQL integration and CLI
daemon smoke remain unqualified in this root-only, Unix-socket-restricted
environment. No live model calls, production database mutations, deployment,
release, or GitHub merge occurred.

CI coverage still needs a qualified execution-cycle smoke and crash/recovery
tests. A stable deployment/promotion boundary, service-enforced test and delivery
evidence, and a real canary remain production prerequisites. This patch does not
claim production readiness or explain every installed-session failure.

## Apply from a normal authenticated checkout

Choose either the patch or bundle route, not both. Preserve existing local edits
and create the branch from the listed base.

Patch route (replace the archive directory with its extracted absolute path):

```sh
git switch -c codex/workflow-reliability-2026-09-05 ad580d7df10bb25937ed55a9a32674384a8ddfc7
git am /absolute/path/workflow-reliability-delivery/workflow-reliability.patch
git push -u origin codex/workflow-reliability-2026-09-05
```

The Git bundle preserves the exact local commit:

```sh
git bundle verify /absolute/path/workflow-reliability-delivery/workflow-reliability.bundle
git fetch /absolute/path/workflow-reliability-delivery/workflow-reliability.bundle HEAD:refs/heads/codex/workflow-reliability-2026-09-05
git switch codex/workflow-reliability-2026-09-05
git push -u origin codex/workflow-reliability-2026-09-05
```

The repository must already contain the listed base commit. Run the documented
qualification gates on a supported host before merging and promoting this branch.
