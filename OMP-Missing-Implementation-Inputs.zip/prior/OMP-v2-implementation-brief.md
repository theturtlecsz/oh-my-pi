# OMP v2: implementation brief and remaining corrections

## Outcome

The audit is sufficiently grounded to move into a focused implementation task. Reuse v2's source inventory, real auditor role text, prompt assembly, and proposed patches. Resolve the concrete gaps below as part of preparing and verifying the implementation; another general audit is unnecessary.

Remote review verified all **38 manifest-listed files** against their hashes and sizes. All **eight supplied patches** apply to their bundled bases and produce exactly the bundled new files. This establishes package integrity and patch mechanics, not behavioral correctness or compatibility with a newer deployment. No live installation, model assignment, or WorkService record was changed during review.

Adopt the direction of the corrected author-verification rule, complete tag-authority replacement, manual/native audit carve-out, scoped weekly-review wait, role-based model doctrine, and candidate-observation framing. Several related clauses remain contradictory; complete each change across its actual consumers.

## 1. Persistence: complete authorized work without manufacturing new stopping points

V2 changes only `system-prompt.md`. These additional active instructions remain:

- `packages/coding-agent/src/prompts/system/project-prompt.md`: “completion only stopping condition.”
- `packages/coding-agent/src/prompts/system/subagent-system-prompt.md`: continue with another tool call while work remains, and “You MUST keep going until this ticket is closed.”

The latter is inappropriate for an auditor or a worker assigned one slice. Ticket closure belongs to the authorized workflow. Conversely, v2's replacement saying that grant/phase boundaries end the run can make an agent stop at planning → implementation → audit transitions already authorized by `/execute`.

Use the following semantics consistently in default, project, and subagent templates, adapted to the existing role/output contracts:

> Continue while useful work remains within the current assignment and authorization. A substep, todo update, or transition already authorized by the current grant is not a reason to stop. Continue to the next phase when the existing grant authorizes that transition. Stop at a completed assignment, an actual approval or permission boundary, cancellation, a hard harness stop, or a genuine blocker. Preserve state and report through the role's required result contract.

For the subagent completion clause, use:

> Complete your assigned slice and return its required terminal yield. Do not keep working solely because the parent issue remains open. Independent auditors return their verdict; they do not implement fixes or close the issue. If blocked, use the existing error/result protocol and state the missing prerequisite.

Budget messages require precise treatment: a soft budget notice can permit finishing the current step and wrapping up; a hard stop requires the forced-yield protocol. Follow the notice's actual semantics. Do not turn every notice into an immediate stop, ignore notices, or add conversational text outside strict result schemas.

Keep v2's author-verification clause. Also reconcile the existing engineering instruction that forbids rechecking user-reported observations: accept the reported symptom and investigate its cause; reproduction and regression verification remain appropriate when useful. A successful edit operation does not establish behavioral correctness.

Acceptance must include an ordinary task returning while its parent issue remains open, an auditor returning the required verdict, authorized execution continuing across a phase transition, refusal at a genuine authority boundary, and distinct soft-budget/hard-stop outcomes. These are bounded workflow/fixture checks; a broad paid model campaign is not a prerequisite for preparing the patch.

## 2. Intake: finish the remaining contradictory clauses

V2 introduces a routine-assumption lane, but the same proposed file still says:

- Question mechanics: “judgment calls never self-answered.”
- Pre-publication lint: “Figured-out-myself: facts only.”
- Existing-plan seam: draft judgment calls enter as confirm-or-overturn, without the consequential/routine distinction.
- Dangling-edge rule: an open noun blocks stopping, despite the new explicit question ceiling.

Reconcile these in `session-system/skills/intake/SKILL.md`:

> Explore factual questions using available evidence. Record routine reversible decisions as labeled assumptions; ask consequential scope, product, correctness, or authorization questions. Existing draft decisions need confirmation only when consequential and not already decided by the owner.

> The scan distinguishes sourced facts, labeled routine assumptions, consequential questions, and deferred work. Publication lint accepts sourced facts and labeled routine assumptions in the self-resolved lane. It refuses concealed consequential decisions.

> Unresolved consequential questions and dangling terms block readiness for the affected scope, not compliance with the interview's question ceiling. At the ceiling, preserve unresolved items and report them. An owner deferral must explicitly remove or postpone the affected scope, or leave it blocked; deferral is not implementation authorization.

Keep publication preview and explicit owner confirmation. “Zero questions” in acceptance means zero discovery questions, not bypassing publication approval. Inspect corresponding host/lint enforcement if it validates these categories; do not change prose while leaving an incompatible enforced rule.

## 3. Observation and model doctrine: complete the consolidation

V2 correctly stops observation status from creating authority. However, `session-system/skills/task-observer/references/session-start.md` still makes any OPEN observation prescribing command construction a mandatory working-note rule before a tool call. Reconcile that paragraph:

> Apply command constraints established by applicable standing instructions and the approved plan. OPEN observations are candidate evidence; inspect their relevance and supporting facts, but their status alone does not impose a command rule or amend authorization. A promoted standing constraint must identify its canonical source and approval provenance.

Preserve the narrow digest-read hook. Do not fold the full observation-promotion machinery into this wording patch; map that design to the existing OMP-202/H5 work where appropriate. Automated skill installation and policy promotion are distinct questions.

The new `omp-AGENTS.md` model paragraph still recommends `@deep` during long-running work/adjudication and then excludes it from the execution cycle. It also retains K3 assumptions and hardcodes an imperfect precedence chain. Fix it as follows:

- Describe role responsibilities and when escalation is appropriate, without embedding model names or provider-specific effort behavior.
- Use the actual resolver's effective selector, effort, and provenance; alias expansion and candidate precedence are separate stages, so avoid a simplified hand-maintained hierarchy.
- Preserve the existing bookend separation explicitly: use `@deep` in authorized planning/adjudication contexts outside execution where applicable; do not reinterpret this wording change as authority to insert it into a grant. If a broader execution role is desired, make that a deliberate routing change.
- Independent native auditing remains authorized within a valid execution grant; “audit stays out of execution” must not contradict that existing exception. The implementation worker does not become its own final auditor.

Complete the delegation WHEN/HOW reconciliation across renderer branches too. V2 places the new doctrine sentence only inside the non-Codex branch, while the Codex eager branch can still override explicit-request gates and eager-always still mandates broad delegation. Establish one applicable policy across the section, make branch-specific eagerness conditional on that policy, and preserve decomposition/concurrency safeguards. Check Codex/non-Codex and eager off/on/always with representative configured inputs; do not silently change the owner's delegation preference.

## 4. Models: preserve the owner's available routes

V2's probe found a Fable 5.1 catalog match with a credential value resolved, and an Astra match under Zenmux without a resolved credential. Neither model was launched. These are useful but limited results:

- The probe manually expands a role and calls `parseModelPattern` over a bare registry with no preferences. It does not include the full configured CLI/session registry, extension-contributed providers, or all request/agent overrides.
- `isAuthenticated` tests whether a nonempty credential value exists; it does not demonstrate server authentication or model entitlement. Label this `credential_resolved`, with serving and server authorization unmeasured.
- Even the input `openai/gpt-6-astra` matched the Zenmux entry in this probe. Do not treat that as a verified OpenAI route or silently provision an aggregator because a fuzzy match selected it.

Resolve the owner's intended Astra route through the configured CLI/session path first, including contributed providers. Pin and verify the exact provider/model pair, transport, supported effort, and fallback behavior. Preserve the owner's statement that Astra is available; local OMP route configuration is what remains unresolved. Fable 5.1 is a candidate for a bounded trial, not a proven replacement assignment. Keep economical workers and independent acceptance review as goals.

Use a side-effect-free configured-auth check where only presence is needed. Resolving API keys can refresh OAuth or invoke configured commands; no raw credential value should be exported. Do not change live assignments or provision credentials as part of this correction task.

## 5. Style and prompt evidence: keep claims precise

Ponytail's corrected OMP source is its installed OMP plugin, with its own default-mode behavior. The Claude flag-file explanation from v1 is superseded. Retire the stale inventory rows that still assert the old mechanism.

The v2 assembly manifests have `ponytail: false` in every block because the probe stops before `before_agent_start`. They establish the base assembly, not simultaneous capture of the dynamic Ponytail block. Capture one isolated before/after event with full/off modes if this is needed to verify the style change. Do not label four-style co-presence as mechanically captured until that event is exercised.

Recommend an OMP-scoped Ponytail-off setting for normal owner-facing work, preserving explicit opt-in and the owner's other harness configuration. Document the chosen supported setting; do not edit plugin caches. The proposed `.cursor/rules/caveman.mdc` change affects Cursor as well as OMP, so record that scope rather than describing it as OMP-only. Preserve strict auditor/result schemas.

The auditor fixture now uses the real role text, which supports the instruction-conflict finding. Its `outputSchema: true` field merely records that frontmatter contains a schema: the probe did not pass all actual executor schema/options. For verification, use the real normalized output schema and executor settings/tool restrictions. Capture only user-managed code/configuration and observable messages, never hidden provider instructions or private reasoning.

Restore the missing `.audit-render.tmp.ts` source cited by `EV2-PATCH-RENDER.json`, or replace it with a reproducible check. Include correct setup: relative `./src/...` imports resolve from the probe file's location, not merely the shell cwd. Separate a stub-provider serialization test from a live-model response test; they establish different things.

## 6. Re-scope the deadline proposal before implementing it

`buildSystemPrompt` has timeout fallbacks, but normal SDK startup awaits primary context files and skills before passing them into the builder. Rebuild also supplies resolved custom/append/context/skills/rules. Therefore v2's blanket claim that normal startup loses all those instructions after five seconds is not established. Cursor rules travel through a separate rules path too.

Use an isolated delayed-loader fixture through the actual SDK call graph. Establish whether the affected path is direct builder use, additional-root discovery, capability SYSTEM discovery, or another asynchronous input. Demonstrate what is awaited, omitted, warned, or retried. Then propose appropriate visibility or enforcement for that proven path. Keep this as targeted validation until reproduced; do not classify every decorative discovery step as required or bundle it into a deployment maintenance issue.

## 7. Deployment: revise the operational plan before cutover

The correction from `update.sh` to inspecting `install.sh` is sound. The v2 plan still needs these repairs:

- **Define the complete candidate.** Installing `session-system` from a deploy worktree does not install the core `system-prompt.md`, the project/subagent templates, or repo-local Copilot/Cursor changes into the active launcher/worktree. Identify the core launch target, deployed extension/skill target, and project context revision separately. Use immutable reviewed references, not the plan's inconsistent historical “current main” assertion.
- **Account for live reads.** Hooks execute on subsequent tool calls and skill bodies can be read on demand. Repointing links can affect an existing session even while its extension modules remain cached. “Only new sessions are affected” is false for the whole installation. Use a controlled cutover with relevant work quiesced and verified restart/reload boundaries; a new conversation within an old process may not reload modules.
- **Inspect the complete installer mutation set.** It atomically swaps the extension directory, then sequentially updates other files/skills and removes retired artifacts. The whole instruction stack is not one atomic transaction. Preserve or back up unmanaged/copy-mode content that the actual plan would overwrite, compare before/after manifests with exclusions understood, and test rollback. Not every manifest row should resolve into the new tree: some are absent or preserved unmanaged entries.
- **Retain applicable fences and gates.** Follow the documented live-link/mapping discipline for operations that mutate checkouts or dependencies. Do not infer that symlink replacement makes the complete operation safe for active sessions. Prepare fresh-worktree dependencies/native prerequisites and use the actual required tests; record smoke tests as skipped if their prerequisites are absent.

Deployment approval belongs after the concrete target, checks, active-work treatment, and rollback are reviewable. Do not install during this task.

## Local-agent execution request

Use the existing Work Ledger workflow to prepare the corrected implementation. Reuse v2; complete the specific clause/fixture/plan corrections above. Produce an isolated review branch or exact corrected diff according to the current authorization gates, run the relevant isolated verification, and prepare amendments against the actual native issue scope and acceptance criteria. Do not publish duplicates from abbreviated title matches. Re-read revision/contract state immediately before any later authorized publication.

Keep serving-model metadata truthful: distinguish requested, resolved, launched, fallback, and provider-confirmed serving identity; record unavailable serving identity explicitly rather than inventing an attestation to satisfy acceptance criteria.

Return the corrected diff/branch, a short issue-amendment readback or staged preview, checks actually run with outcomes, and the revised deployment plan. For each original v2 patch, state retained, corrected, or deferred. Report only consequential decisions still needed. Do not produce another broad audit ZIP; deliver the implementation work product and its evidence. No live deployment, model switch, credential provisioning, or issue publication is authorized by this review alone.
