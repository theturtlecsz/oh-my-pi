# OMP assumption validation plan

Prepared September 5, 2026. Status: proposed experiment charter, not executed model evaluation or an amendment to v9.1. The prior runtime test results remain the measured baseline. This plan makes our architectural recommendations falsifiable.

## 1. Questions and decisions

| Hypothesis | Controlled comparison | Evidence that would change the plan |
| --- | --- | --- |
| Optional Session Ledger narration improves outcomes enough to justify its cost | Same repaired fork, narration component enabled versus disabled | Similar or better accepted results with materially lower total cost/rescue burden supports qualifying removal; worse orientation or correctness supports retaining or redesigning it |
| Advisor/Observer prevent meaningful defects | Subsequent isolated supervision ablations; same tasks, worker and final grading | Measure escaped defects and unsupported warnings; a warning count alone cannot establish prevention |
| Cheap implementation plus stronger oversight is economical | Same qualified harness and task set, different worker route; other roles fixed | Compare total cost per accepted outcome and human rescue time, including failed attempts |
| Typed intake improves requirements quality | Current intake, structured interviewer, then a minimal typed/rule-based prototype | Fewer false-ready decisions, critical omissions and downstream requirement errors without unacceptable owner burden |
| Context management preserves essential state | Same task interrupted or compacted at controlled boundaries | Current requirements, scope, blockers and evidence survive; superseded memory does not override current state |
| OMP is the best execution choice | Later supported OMP configuration versus one stock external worker under a common task/evaluation envelope | Better complete-system outcomes or lower maintenance burden may justify an adapter or migration; provider/model differences prevent attributing everything to the harness |
| Parallel Fleet improves delivery | One versus two workers on independent and conflicting task pairs | Accepted throughput improves without worse conflicts, escapes, recovery or human effort |

Do not run every comparison at once. v9.1 already prescribes phased ablations and a 30–50-task qualification corpus. This smaller pilot discovers large effects and setup problems; it does not replace those gates.

## 2. Stage zero: prove the environment and the checks

Use an isolated nonproduction runner with PostgreSQL 18 under a nonroot identity, Unix sockets, pinned Bun/toolchain, frozen dependencies, and compatible native artifacts. Candidate-native changes require candidate-built native evidence. The current ChatGPT execution environment could not provide full PostgreSQL or Unix-socket coverage, and the GitHub integration denied the previous Actions rerun with 403. Those blockers remain unresolved here.

Run existing work-client, session-system, PostgreSQL integration and CLI/candidate smoke suites. Correct incomplete test fixtures without weakening assertions, include custom harness suites explicitly in CI, and retain every original failure log.

Preserve the previously tested SHA ad580d7df10bb25937ed55a9a32674384a8ddfc7 as the historical reference. Establish a separately pinned repaired fork baseline before a paid comparison. Both experimental arms must contain identical repairs for deletion handling, expected-head delivery and service completion conditions. Do not attribute those repairs to the experimental intervention.

The trusted evaluator must accept a known-good solution and reject known-bad, no-op and tampered results. Core scenarios:

| Scenario | Required observable outcome |
| --- | --- |
| Authorized tracked deletion | Candidate can freeze and contains the intended deletion |
| Head advances after audit/precheck | Merge refuses before unaudited content is delivered |
| Test receipt names another candidate | Completion refuses with an actionable stale-evidence reason |
| Caller submits prose claiming PASS | Claim cannot substitute for authenticated runner evidence |
| Feature branch pushed, delivery incomplete | Service cannot declare the work complete |
| Candidate modifies verifier or policy | It cannot automatically certify itself with the changed authority |
| Crash after external effect, before acknowledgement | Outcome becomes unknown and is reconciled without duplicating the effect |
| Expired grant, canceled work or stale worker | New effects are refused at the boundary that performs them |
| Repeated operation or competing claims | Idempotency and ownership hold under real concurrent requests |
| Browser/editor lacks an approval interaction | Missing UI capability does not manufacture authorization |

Use real Git and disposable PostgreSQL with controlled concurrency barriers. Local simulated GitHub fixtures are useful fast tests, but provider-specific merge qualification also needs a scoped, disposable GitHub repository. Treat that as a distinct integration lane, not as already covered by our local reproduction.

A failing critical invariant stops promotion and the paid pilot. Zero failures in these finite cases is a release condition for the cases tested, not proof of universal safety.

## 3. Harbor, in practical terms

Harbor is an evaluation framework that packages a task, starting environment, agent invocation and verifier. For a task such as “fix this bug without changing the API,” it can start a clean environment, invoke an OMP adapter, collect the candidate and logs, and run separately controlled checks. Repeating that task with another configuration produces comparable evidence.

Harbor does not supply correct acceptance criteria automatically, choose a winning model, or become WorkService. We must provide meaningful tasks, an adapter that exercises the intended OMP workflow, and trustworthy graders. Configure a separate verifier environment and explicit artifact transfer; Harbor's shared default is insufficient for an evaluator the worker must not modify. Network policy and cleanup also require explicit configuration. [Harbor task documentation](https://www.harborframework.com/docs/tasks)

For the first two environment/control tasks, a small runner plus existing test tools is sufficient. Adopt Harbor if packaging environments, resets, multiple configurations and evidence collection would otherwise become substantial custom work. Record the selected Harbor version and backend when implemented.

## 4. First paid pilot: one optional component

Proposed arms:

- A: repaired fork baseline, including the optional Session Ledger narrator.
- B: identical repaired fork, with only that optional narration component disabled.

This narrator is separate from PostgreSQL WorkService and semantic Advisor/Observer. Preserve durable state, state-retrieval tools, Advisor, Observer, independent audit, grants, scope and delivery checks in both arms. Define the intervention precisely: disabling narration production, display and model injection measures the combined contribution of the component. It does not identify which of those subeffects caused the result.

The inspected host registers Session Ledger directly; no independent toggle was found. An experiment-only switch and verification that it changes no other mechanism are prerequisites. They are not implemented by this document. If isolating the component requires a broad refactor, instrument the current system first instead. Merely hiding the injected note while still generating it is a different experiment and cannot demonstrate savings in narrator generation cost.

Proposed development corpus: 12 tasks, two from each of six families:

1. Localized bug fixes and edge cases.
2. Cross-file compatibility changes.
3. Refactoring including deletion or rename.
4. Interrupted/resumed work with changed or stale context.
5. Ambiguous requirements with fixed underlying owner intent.
6. Database or workflow changes needing integration evidence.

Select cases from actual OMP and another repository Chris uses. Include routine work as well as frustrating cases. These are task-selection slots; complete task fixtures and graders must still be authored and qualified.

Run three independent trials per task and arm: 12 × 3 × 2 = 72 runs, after a small environment pilot and a declared spending/time cap. This is a proposed batch size, not incurred usage or a statistical power guarantee. Begin with a small metered subset to estimate consumption before releasing the remaining batch.

## 5. Fairness and evidence

Pin task version, starting repository, model/provider/effort, role routes, tools, environment resources, time limits and task budgets. Interleave arm order within task blocks. Use fresh conversations, databases, worktrees and agent memory; remove prior outcomes and future solution commits from accessible history/remotes. Keep gold patches and held-out checks outside the worker environment. Keep dependency/network access comparable and sufficient for the task.

For tasks with questions, use a prewritten scenario and owner-answer facts consistently. Measure actual owner interaction separately; a scripted owner cannot establish human usability. Grade subjective results blind to the arm where practical, and use the same human rubric.

Each run records:

- Task/arm/trial IDs and exact configuration and source identities.
- Candidate identity and trusted test results, including test counts, skips, exit status and logs.
- Acceptance-criterion outcomes and independent audit findings.
- Valid delivery evidence when the task claims delivered completion.
- Worker, planner, narrator, Advisor and auditor usage; retries and sandbox compute.
- Wall time, intervention count, human minutes and reasons.
- Failure classification: environment, implementation, requirements, policy, context or unresolved.

Separate autonomous success, success after rescue, legitimate blocked completion, and incorrect completion. A blocked result can be correct for a negative-control task; a runnable coding task that remains blocked is still incomplete. Preserve all attempts. Predefine permissible infrastructure retries and retain their frequency. Arm-caused infrastructure failures count against the arm.

Evaluate final artifacts and environment outcomes, not just transcripts or an LLM's verdict. Combine deterministic checks with calibrated human/semantic grading when the criterion requires it. [Anthropic evaluation guidance](https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents)

## 6. Decisions and statistical limits

Primary outcome: the specified task outcome is satisfied within the budget, with the required verification/delivery evidence and no disallowed effects. Report cost and human effort alongside quality; a single blended score must not hide critical errors.

Treat the pilot as 12 paired tasks with repeated observations. The 72 runs are not 72 independent examples of general coding ability. Show each task's arm outcomes, all-three-success consistency, costs and failure explanations. Analyze uncertainty at task level. A nonsignificant difference does not establish equivalence.

Before qualification, choose the smallest useful cost/time improvement and acceptable quality margin using pilot variance and Chris's priorities. Preserve existing v9.1 critical-case requirements. Stop on critical violations; advance promising changes to a separate untouched 30–50-task qualification corpus; retain baseline when results are inconclusive. Once a held-out case informs tuning, move it into development/regression and replace it.

Later experiments change one factor at a time: worker route, supervision policy, intake representation, external runtime, then Fleet concurrency. Intake evaluation should include fixed-intent omission/contradiction cases and subsequent implementation outcomes. For external runtimes, distinguish same-model harness experiments from comparisons of each platform's supported complete configuration.

## 7. Concrete preparation and execution boundary

The first deliverable should be an executable environment, ten invariant/control scenarios, two fully qualified task fixtures, an exact experiment configuration/diff, and an evidence report template. The next deliverable expands to the proposed development corpus and metered trials. All are still preparation work; this charter alone is not an evaluation harness.

Before paid runs: select an available nonroot runner, confirm actual provider/model routes, and set a total spending cap and per-task time limit. Before live GitHub integration: identify the disposable target and narrowly scoped credentials. No credentials should be placed in task files or exposed to worker-readable verifier configuration.

The research recommendation to retain OMP is itself provisional. Results favoring a simpler OMP configuration or an external worker should change the implementation plan.
