# Missing OMP implementation inputs recovered

This package supplies the files reported missing by the local agent. They are byte-identical to the prior inputs in the original handoff archive. The updated main handoff also clarifies M0 and the Harbor H4/M2/M3 mapping.

## Files

- `prior/workflow-reliability/workflow-reliability.bundle`: preserves commit `7311e035760cd9783d1da65f424fed85fe1756b1`; requires base `ad580d7df10bb25937ed55a9a32674384a8ddfc7` in the repository.
- `prior/workflow-reliability/workflow-reliability.patch`: same implementation as a patch. Use one integration route, not both.
- `prior/workflow-reliability/README.md` and logs: historical verification and limitations. Historical command examples are not current publication or deployment authorization.
- `prior/OMP-v2-implementation-brief.md`: specific corrections to the v2 proposals already available locally.
- `prior/OMP-Assumption-Validation-Plan.md`: earlier qualification charter; current handoff updates initial experiment order.
- `OMP-Implementation-and-Harbor-Handoff.md`: updated continuation handoff.

Extract into a fresh directory. From that directory, `sha256sum -c RECOVERY-SHA256SUMS` verifies all included files. From a repository containing the historical base, run `git bundle verify /absolute/path/to/prior/workflow-reliability/workflow-reliability.bundle`. Resolve the actual extraction path; do not search every worktree again.

## Continue from the local report

1. Preserve OMP-237's reported closed state and landed CI fix. It does not need reopening for this work. Reconcile W0 against current main and existing issue ownership; retain the native download fix and avoid duplicating pause/stop work. W0 also covers readiness/fingerprint behavior, tracked deletions, audited-head merge enforcement, and OMP-specific test coverage.
2. Report identity/ledger mapping complete but full M0/W0 partial until reconciliation is done. Import/apply missing changes only through the applicable authorized isolated development workflow.
3. Ensure the Harbor child explicitly owns both H4 task fixtures (structured acceptance amendment and durable continuation), grader positive/negative controls, and M2 integration. Allocate remaining H4 invariant tests to M3 owners and record dependencies on W2/W5/W6 where needed.
4. Keep Harbor H5 model-comparison preparation and reporting tracked for later. It is unrelated to OMP-202/H5's deferred observation-to-policy work. Zero model spend remains the initial implementation boundary.
5. Keep W4 structured amendments to OMP-241/OMP-211 staged behind W2 as reported. Do not replace authoritative criteria updates with description checkboxes.
6. Re-display the exact current native publication preview if scope or dependencies change. The reported confirmation ID cf-5ce88aff656f is not an approval; do not reuse its confirmation for a changed batch. Reuse any actual owner authorization already present, and follow the native publication gate otherwise. The remote reviewer has seen only the report, not that exact preview.
7. After authorized publication, report created IDs and dependencies. Use individual child execution as required by the reported OMP-219 constraint; do not assume parent --queue is supported. Continue unaffected work already authorized while any later gate is pending.

Return the W0 disposition by contract/file, corrected issue ownership/dependencies, current preview or publication readback, and the next executable child. Do not restart the broad audit.
